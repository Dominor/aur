    ROSA Media Player
    Copyright (C) 2006-2010 Ricardo Villalba <rvm@escomposlinux.org>
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2011-2012 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    -------------------------------------------------------------------------

ROSA Media Player (ROMP) is an unusual videoplayer which differs from similar
products due to combination of functionality and easy control. We are trying 
to refine our product, following the way of simplifying interface and refusing
useless elements. On the other hand we are increasing program's potential, 
adding new instruments which haven't been presented yet.

ROMP is based on MPlayer and SMPlayer technologies.
ROMP intends to be a complete front-end for MPlayer, from basic
features like playing videos, DVDs, and VCDs to more advanced features
like support for MPlayer filters and more. You can also capture desktop, trim
video, extract audio track.

...

To the point:

To know how to compile and install rosa-media-player please read Install.txt.

Visit the web for updates:
http://abf.rosalinux.ru/downloads/rosa2012lts/repository/i586/main/release/

    -------------------------------------------------------------------------

Third-party:

 * QuaZIP (a library to open Zip files) by Sergey A. Tachenov
   url: http://quazip.sourceforge.net/
   license: GPL (see src/findsubtitles/quazip/COPYING.readme for details)
   This library also includes code by Gilles Vollant, with the same
   license as zlib. See src/findsubtitles/quazip/zip.h for details.
