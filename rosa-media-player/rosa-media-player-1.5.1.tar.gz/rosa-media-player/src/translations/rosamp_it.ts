<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="it">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>The following people have contributed with translations:</source>
        <translation>Le seguenti persone hanno contribuito con le traduzioni:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="174"/>
        <source>German</source>
        <translation>Tedesco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="175"/>
        <source>Slovak</source>
        <translation>Slovacco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>French</source>
        <translation>Francese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="249"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 e %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="183"/>
        <source>Simplified-Chinese</source>
        <translation>Cinese semplificato</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="246"/>
        <source>%1 and %2</source>
        <translation>%1 e %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="185"/>
        <source>Hungarian</source>
        <translation>Ungherese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="93"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="99"/>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Polish</source>
        <translation>Polacco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="191"/>
        <source>Japanese</source>
        <translation>Giapponese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Dutch</source>
        <translation>Olandese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Ukrainian</source>
        <translation>Ucraino</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="199"/>
        <source>Portuguese - Brazil</source>
        <translation>Portoghese (Brasile)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="200"/>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Czech</source>
        <translation>Ceco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Bulgarian</source>
        <translation>Bulgaro</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Swedish</source>
        <translation>Svedese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Serbian</source>
        <translation>Serbo</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Traditional Chinese</source>
        <translation>Cinese tradizionale</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Portuguese - Portugal</source>
        <translation>Portoghese (Portogallo)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Greek</source>
        <translation>Greco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="214"/>
        <source>Finnish</source>
        <translation>Finlandese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="267"/>
        <location filename="../about.cpp" line="279"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="303"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>About ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="84"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="215"/>
        <source>Korean</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="216"/>
        <source>Macedonian</source>
        <translation>Macedone</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="217"/>
        <source>Basque</source>
        <translation>Basco</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>Using MPlayer %1</source>
        <translation>MPlayer %1 in uso</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="100"/>
        <source>terms of use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="122"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="218"/>
        <source>Catalan</source>
        <translation>Catalano</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="219"/>
        <source>Slovenian</source>
        <translation>Sloveno</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="220"/>
        <source>Arabic</source>
        <translation>Arabo</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="221"/>
        <source>Kurdish</source>
        <translation>Curdo</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="222"/>
        <source>Galician</source>
        <translation>Galiziano</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="252"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 e %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 e %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="223"/>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="224"/>
        <source>Estonian</source>
        <translation>Estone</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="225"/>
        <source>Lithuanian</source>
        <translation>Lituano</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Shortcut</source>
        <translation>Scorciatoia</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="219"/>
        <source>&amp;Save</source>
        <translation>&amp;Salva</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="222"/>
        <source>&amp;Load</source>
        <translation>&amp;Apri</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="470"/>
        <location filename="../actionseditor.cpp" line="529"/>
        <source>Key files</source>
        <translation>File chiave</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="468"/>
        <source>Choose a filename</source>
        <translation>Scegli il nome del file</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="482"/>
        <source>Confirm overwrite?</source>
        <translation>Confermi sovrascrittura?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="483"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Il file  %1 esiste già.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="528"/>
        <source>Choose a file</source>
        <translation>Scegli un file</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="497"/>
        <location filename="../actionseditor.cpp" line="537"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="498"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Non è stato possibile salvare il file</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="538"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Non è stato possibile caricare il file</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="226"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Cambia scorciatoia...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="74"/>
        <source>Audio Equalizer</source>
        <translation>Equalizzatore Audio</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="77"/>
        <source>31.25 Hz</source>
        <translation>31,25 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>62.50 Hz</source>
        <translation>62,50 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="79"/>
        <source>125.0 Hz</source>
        <translation>125,0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="80"/>
        <source>250.0 Hz</source>
        <translation>250,0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>500.0 Hz</source>
        <translation>500,0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>1.000 kHz</source>
        <translation>1,000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>2.000 kHz</source>
        <translation>2,000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>4.000 kHz</source>
        <translation>4,000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>8.000 kHz</source>
        <translation>8,000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>16.00 kHz</source>
        <translation>16,00 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>&amp;Apply</source>
        <translation>&amp;Applica</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Salva come valori predefiniti</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Usa i valori correnti come valori predefiniti per i nuovi video.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="96"/>
        <source>Set all controls to zero.</source>
        <translation>Metti a zero tutti i controlli.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="117"/>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="118"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>I valori correnti sono stati salvati come predefiniti.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1413"/>
        <source>&amp;File...</source>
        <translation>&amp;File...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1414"/>
        <source>D&amp;irectory...</source>
        <translation>C&amp;artella...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1415"/>
        <source>&amp;Playlist...</source>
        <translation>Lista di riprodu&amp;zione...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1418"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD dall&apos;unità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1419"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD da una cartella...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1420"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1435"/>
        <source>P&amp;lay</source>
        <translation>&amp;Riproduci</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1442"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pausa</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1444"/>
        <source>&amp;Frame step</source>
        <translation>Avanza per &amp;fotogramma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1461"/>
        <source>&amp;Normal speed</source>
        <translation>Velocità &amp;normale</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1462"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Dimezza velocità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Raddoppia velocità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>Speed &amp;-10%</source>
        <translation>Velocità &amp;-10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>Speed &amp;+10%</source>
        <translation>Velocità &amp;+10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1609"/>
        <source>Sp&amp;eed</source>
        <translation>V&amp;elocità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1472"/>
        <source>&amp;Fullscreen</source>
        <translation>T&amp;utto schermo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1473"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizzatore</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Screenshot</source>
        <translation>&amp;Schermata</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1484"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1485"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetect della fase</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>Add n&amp;oise</source>
        <translation>Aggiungi r&amp;umore</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1631"/>
        <source>F&amp;ilters</source>
        <translation>&amp;Filtri</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1496"/>
        <source>&amp;Mute</source>
        <translation>&amp;Muto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Play list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1497"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1498"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1499"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Ritardo -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1500"/>
        <source>D&amp;elay +</source>
        <translation>R&amp;itardo +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1688"/>
        <source>&amp;Filters</source>
        <translation>&amp;Filtri</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Load...</source>
        <translation>&amp;Apri...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>Show / Hide right panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista di riproduzione</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1530"/>
        <source>Help &amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>&amp;Open</source>
        <translation>A&amp;pri</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Sottotitoli</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1590"/>
        <source>&amp;Browse</source>
        <translation>S&amp;foglia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Op&amp;tions</source>
        <translation>&amp;Opzioni</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>&amp;Help</source>
        <translation>A&amp;iuto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1595"/>
        <source>&amp;Recent files</source>
        <translation>File &amp;recenti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Clear</source>
        <translation>&amp;Pulisci</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1618"/>
        <source>Si&amp;ze</source>
        <translation>Grande&amp;zza</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1627"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlaccia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1662"/>
        <location filename="../basegui.cpp" line="2868"/>
        <source>&amp;None</source>
        <translation>&amp;Nessuno</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1663"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1666"/>
        <source>Linear &amp;Blend</source>
        <translation>&amp;Blend lineare</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1692"/>
        <source>&amp;Channels</source>
        <translation>&amp;Canali</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1697"/>
        <source>&amp;Stereo</source>
        <translation>Stere&amp;o</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1699"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Select</source>
        <translation>&amp;Seleziona</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Title</source>
        <translation>&amp;Titolo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1711"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Capitolo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1715"/>
        <source>&amp;Angle</source>
        <translation>&amp;Angolo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2213"/>
        <source>Capture desktop...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4834"/>
        <source>Video capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4835"/>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4836"/>
        <source>Start capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4837"/>
        <source>Cancel</source>
        <translation type="unfinished">Annulla</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Disabilitato</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2884"/>
        <location filename="../basegui.cpp" line="2904"/>
        <location filename="../basegui.cpp" line="2924"/>
        <location filename="../basegui.cpp" line="2943"/>
        <location filename="../basegui.cpp" line="2972"/>
        <location filename="../basegui.cpp" line="3004"/>
        <location filename="../basegui.cpp" line="3031"/>
        <location filename="../basegui.cpp" line="3074"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;vuoto&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3444"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3445"/>
        <location filename="../basegui.cpp" line="3674"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3446"/>
        <source>Playlists</source>
        <translation>Liste di riproduzione</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3447"/>
        <location filename="../basegui.cpp" line="3652"/>
        <location filename="../basegui.cpp" line="3675"/>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3442"/>
        <location filename="../basegui.cpp" line="3649"/>
        <location filename="../basegui.cpp" line="3672"/>
        <source>Choose a file</source>
        <translation>Scegli un file</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3507"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Le unità CDROM / DVD non sono ancora configurate.
Si aprirà ora il dialogo di configurazione, in modo che tu possa farlo.
</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3607"/>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3651"/>
        <source>Subtitles</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4244"/>
        <source>Playing %1</source>
        <translation>In riproduzione %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4247"/>
        <source>Pause</source>
        <translation>Pausa</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4250"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1446"/>
        <source>Play / Pause</source>
        <translation>Riproduci / Pausa</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1458"/>
        <source>Pause / Frame step</source>
        <translation>Pausa / Per fotogramma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <location filename="../basegui.cpp" line="1512"/>
        <source>U&amp;nload</source>
        <translation>&amp;Rimuovi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1416"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>C&amp;lose</source>
        <translation>C&amp;hiudi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>View &amp;info and properties...</source>
        <translation>&amp;Informazioni e proprietà...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1527"/>
        <source>P&amp;references...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1552"/>
        <source>Dec volume (2)</source>
        <translation>Abbassa volume (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1553"/>
        <source>Inc volume (2)</source>
        <translation>Alza volume (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1556"/>
        <source>Exit fullscreen</source>
        <translation>Esci da tutto schermo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1558"/>
        <source>OSD - Next level</source>
        <translation>OSD - Livello successivo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1559"/>
        <source>Dec contrast</source>
        <translation>Diminuisci contrasto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1560"/>
        <source>Inc contrast</source>
        <translation>Aumenta contrasto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1561"/>
        <source>Dec brightness</source>
        <translation>Diminuisci luminosità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Inc brightness</source>
        <translation>Aumenta luminosità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Dec hue</source>
        <translation>Diminuisci tonalità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1564"/>
        <source>Inc hue</source>
        <translation>Aumenta tonalità</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1565"/>
        <source>Dec saturation</source>
        <translation>Diminuisci saturazione</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1567"/>
        <source>Dec gamma</source>
        <translation>Diminuisci gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Next audio</source>
        <translation>Audio successivo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Next subtitle</source>
        <translation>Sottotitoli successivi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Next chapter</source>
        <translation>Capitolo successivo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Previous chapter</source>
        <translation>Capitolo precedente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4034"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4253"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Inc saturation</source>
        <translation>Aumenta saturazione</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>Inc gamma</source>
        <translation>Aumenta gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>&amp;Load external file...</source>
        <translation>Apri file &amp;esterno...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1667"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1664"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normale)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1665"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (framerate doppio)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1534"/>
        <source>&amp;Next</source>
        <translation>&amp;Prossimo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>Pre&amp;vious</source>
        <translation>P&amp;recedente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Normalizzazione volume</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1417"/>
        <source>&amp;Audio CD</source>
        <translation>CD &amp;Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Denoise nor&amp;male</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1671"/>
        <source>Denoise &amp;soft</source>
        <translation>Denoise &amp;moderato</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1669"/>
        <source>Denoise o&amp;ff</source>
        <translation>&amp;Nessun denoise</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1515"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>&amp;Usa la libreria SSA/ASS</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Grandezza doppia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>S&amp;ize -</source>
        <translation>Gran&amp;dezza -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1514"/>
        <source>Si&amp;ze +</source>
        <translation>Grande&amp;zza +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>Add &amp;black borders</source>
        <translation>Aggiungi &amp;bordi neri</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="259"/>
        <source>Trim video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="260"/>
        <source>Extract audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Ridimensionamento soft&amp;ware</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>Enable &amp;closed caption</source>
        <translation>Abilita i so&amp;ttotitoli forzati</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1517"/>
        <source>&amp;Forced subtitles only</source>
        <translation>Solo sottotitoli &amp;forzati</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Reset video equalizer</source>
        <translation>Reinizializza equalizzatore video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4660"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>MPlayer si è fermato inaspettatamente.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4661"/>
        <source>Exit code: %1</source>
        <translation>Codice di uscita: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4682"/>
        <source>MPlayer failed to start.</source>
        <translation>MPlayer non è riuscito a partire.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4683"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Controlla il percorso dell&apos;eseguibile MPlayer nelle preferenze.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4687"/>
        <source>MPlayer has crashed.</source>
        <translation>MPlayer è andato in crash.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4688"/>
        <source>See the log for more info.</source>
        <translation>Controlla i registri per maggiori informazioni.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1635"/>
        <source>&amp;Rotate</source>
        <translation>&amp;Ruota</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Off</source>
        <translation>&amp;Inattivo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>&amp;Ruota di 90° in senso orario e ribalta</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>R&amp;uota di 90° in senso orario</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>Ru&amp;ota di 90° in senso antiorario</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>Ruo&amp;ta di 90° in senso antiorario e ribalta</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Show context menu</source>
        <translation>Mostra menù contestuale</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3443"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1493"/>
        <source>E&amp;qualizer</source>
        <translation>E&amp;qualizzatore</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Reset audio equalizer</source>
        <translation>Reinizializza equalizzatore audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>Trova sottotitoli su &amp;Opensubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1522"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Invia sottotitoli a O&amp;pensubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>&amp;Auto</source>
        <translation>&amp;Automatico</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed -&amp;4%</source>
        <translation>Velocità -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>&amp;Speed +4%</source>
        <translation>Velocità +&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;1%</source>
        <translation>Velocità -&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>S&amp;peed +1%</source>
        <translation>Velocità &amp;+1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1640"/>
        <source>Scree&amp;n</source>
        <translation>Sche&amp;rmo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>&amp;Default</source>
        <translation>&amp;Predefinito</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Next video</source>
        <translation>Prossimo video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Traccia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Traccia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3506"/>
        <source>ROSA Media Player - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3728"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4033"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Attenzione - Vecchio MPlayer in uso</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4039"/>
        <source>Please, update your MPlayer.</source>
        <translation>Per favore, aggiorna MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4041"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Questo avviso non sarà mostrato di nuovo)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Next aspect ratio</source>
        <translation>Successivo rapporto d&apos;aspetto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>Pre&amp;view...</source>
        <translation>A&amp;nteprima...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1731"/>
        <source>DVD &amp;menu</source>
        <translation>&amp;Menu DVD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>DVD &amp;previous menu</source>
        <translation>DVD menu &amp;precedente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>DVD menu, move up</source>
        <translation>Menu DVD, vai su</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>DVD menu, move down</source>
        <translation>Menu DVD, vai giù</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1729"/>
        <source>DVD menu, move left</source>
        <translation>Menu DVD, vai a sinistra</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1730"/>
        <source>DVD menu, move right</source>
        <translation>Menu DVD, vai a destra</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1732"/>
        <source>DVD menu, select option</source>
        <translation>Menu DVD, seleziona opzione</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1734"/>
        <source>DVD menu, mouse click</source>
        <translation>Menu DVD, clic del mouse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>Set dela&amp;y...</source>
        <translation>Imposta ritar&amp;do...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3729"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Ritardo audio (in millisecondi):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4395"/>
        <source>Jump to %1</source>
        <translation>Salta a %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Subtitle &amp;visibility</source>
        <translation>&amp;Visualizza sottotitolo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next wheel function</source>
        <translation>Funzione successiva della rotellina</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>P&amp;rogramma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Modifica...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>Next TV channel</source>
        <translation>Canale TV seguente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>Previous TV channel</source>
        <translation>Canale TV precedente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1430"/>
        <source>Next radio channel</source>
        <translation>Canale radio seguente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1431"/>
        <source>Previous radio channel</source>
        <translation>Canale radio precedente</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1531"/>
        <source>About &amp;ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;TV</source>
        <translation>&amp;TV</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1604"/>
        <source>Radi&amp;o</source>
        <translation>Radi&amp;o</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <location filename="../basegui.cpp" line="1427"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Salta a...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1366"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>I filtri video vengono disabilitati se si usa vdpau</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>Fli&amp;p image</source>
        <translation>Rib&amp;alta l&apos;immagine</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Show filename on OSD</source>
        <translation>Mostra il nome del file su OSD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Toggle deinterlacing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Nascondi</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Ripristina</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>&amp;Esci</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Lista di riproduzione</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation type="unfinished">00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="76"/>
        <source>Volume</source>
        <translation type="unfinished">Volume</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3078"/>
        <source>Brightness: %1</source>
        <translation>Luminosità: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3095"/>
        <source>Contrast: %1</source>
        <translation>Contrasto: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3111"/>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3127"/>
        <source>Hue: %1</source>
        <translation>Tonalità: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3143"/>
        <source>Saturation: %1</source>
        <translation>Saturazione: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3295"/>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4261"/>
        <source>Zoom: %1</source>
        <translation>Zoom %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3433"/>
        <location filename="../core.cpp" line="3451"/>
        <source>Font scale: %1</source>
        <translation>Dimensione carattere: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4115"/>
        <source>Aspect ratio: %1</source>
        <translation>Rapporto d&apos;aspetto: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4531"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Aggiornamento della cache dei font. Può richiedere alcuni secondi...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3344"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Ritardo sottotitoli: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3364"/>
        <source>Audio delay: %1 ms</source>
        <translation>Ritardo audio: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3208"/>
        <source>Speed: %1</source>
        <translation>Velocità: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3505"/>
        <source>Subtitles on</source>
        <translation>Sottotitoli attivi</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3507"/>
        <source>Subtitles off</source>
        <translation>Sottotitoli disabilitati</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4166"/>
        <source>Mouse wheel seeks now</source>
        <translation>Ora la rotellina fa la ricerca</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4169"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Ora la rotellina cambia il volume</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4172"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Ora la rotellina cambia l&apos;ingrandimento</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4175"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Ora la rotellina cambia la velocità</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1149"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1165"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2798"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2817"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2835"/>
        <source>A-B markers cleared</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation type="unfinished">Informazioni</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation type="unfinished">Annulla</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="362"/>
        <source>Welcome to ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="414"/>
        <source>A:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="419"/>
        <source>B:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="389"/>
        <source>&amp;Video info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="390"/>
        <source>&amp;Frame counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="429"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>icona</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>&amp;Nascondi registro</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>&amp;Mostra registro</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>Errore MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>icona</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation>Icona</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation>Editor preferito</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation>Lista preferiti</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Qui si possono modificare, eliminare, ordinare o aggiungere nuovi elementi. Fare doppio click su una cella per modificarne i contenuti.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation>Seleziona un file di icona</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation>Immagini</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>icona</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation>&amp;Nuovo</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>&amp;Elimina</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation>Elimina &amp;tutto</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation>S&amp;u</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation>&amp;Giù</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation>Salta a</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Inserisci il numero dell&apos;elemento della lista che vuoi riprodurre:</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Scaricamento...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Scaricamento %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Informazioni</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp; Selezionare il demuxer che sarà usato per questo file:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>Codec &amp;video</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Selezionare il codec video:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>Codec a&amp;udio</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Selezionare il codec audio:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>Opzioni &amp;MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Opzioni addizionali per MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Qui si possono passare opzioni extra a MPlayer.
Scriverle separate da spazi.
Esempio: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Opzioni:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Puoi attivare filtri video addizionali.
Separali con &quot;,&quot;. Non usare spazi!
Esempio: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>Filtri v&amp;ideo:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>E per finire, i filtri audio. Stesse regole che per i filtri video.
Esempio: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>&amp;Filtri audio:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="137"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation>Aggiungi rumore</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation>deblock</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation>denoise normale</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation>denoise moderato</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation>normalizzazione volume</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation>Http</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Abilita/disabilita l&apos;uso del proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation>Il nome host del proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation>La porta del proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Se il proxy richiede l&apos;autenticazione, qui si può impostare il nome utente.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>La password per il proxy. &lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; la password verrà salvata come testo semplice nel file di configurazione.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation>Seleziona il tipo di proxy da usare.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation>Opzioni avanzate</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Abilita proxy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation>&amp;Host:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation>&amp;Porta:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation>&amp;Nome utente:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation>Pa&amp;ssword:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation>&amp;Tipo:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Files</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Caricato da</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Tutti</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Scarica</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Copia link negli appunti</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>Scaricamento fallito: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>Connessione a  %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>Scaricamento...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Fatto.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 file disponibili</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Lettura dei dati ricevuti fallita.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Trova sottotitoli</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Sottotitoli per</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Lingua:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>Aggio&amp;rna</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Sottotitoli salvati come %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation>
            <numerusform>%1 sottotitolo estratto</numerusform>
            <numerusform>%1 sottotitoli estratti</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Sovrascrivi?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>Il file %1 esiste già, sovrascrivere?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Errore durante il salvataggio del file</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Non è stato possibile salvare il file scaricato
nella directory %1
Controllarne i relativi permessi.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation>Download fallito</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation>File temporaneo %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Opzioni</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Durata</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Artista</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Autore</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Genere</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Traccia</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Commento</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Risoluzione</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Rapporto d&apos;aspetto</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Frame al secondo</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Codec Selezionato</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Flusso Audio Iniziale</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Frequenza campionamento</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Canali</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Flussi Audio</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Lingua</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>vuoto</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Sottotitoli</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Tipo</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>N°</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Titolo flusso</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>URL flusso</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>File</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Si può riprodurre un dvd direttamente dal disco. Selezionare semplicemente la cartella che contiene VIDEO_TS e AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Scegli una cartella...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>MPlayer riporta la versione:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>&amp;Selezionare la versione corretta:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 o precedente</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 o successiva</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;URL:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>È una &amp;lista di riproduzione</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="33"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Selezionando questa opzione, l&apos;URL sarà trattata come una lista di riproduzione: sarà aperto come testo e verranno riprodotti gli URL contenuti.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Abcaso</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Aramaico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Arabo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Assamese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Aymara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Azerbaigiano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Baškira</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Bulgaro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Bengalese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Tibetano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Bretone</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Catalano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Corso</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Ceco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Scozzese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Danese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>Tedesco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Greco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Inglese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Spagnolo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Estone</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Basco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Persiano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Finlandese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Faroese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>Francese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Frisone</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Irlandese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Galiziano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Guaraní</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Ebreo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Croato</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Ungherese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Armeno</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Indonesiano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Occidental / Interlingue</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Islandese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Italiano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Giapponese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Giavanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Georgiano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Kazaco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Groenlandese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Coreano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Kashmiro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Curdo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Kirghiso</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Latino</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Lituano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Lettone</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Malgascia</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Māori</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Macedone</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Mongolo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Moldavo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Malay</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Maltese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Birmana</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Nauruana</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Nepalese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Olandese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Norvegese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Occitano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Polacco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Portoghese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Romeno</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Russo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Sanscrito</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Slovacco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Sloveno</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Samoano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Somalo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Albanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Serbo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Sudanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Svedese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Tajik</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Tailandese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Tigrinya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Turkmeno</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Turco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Tatar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Uighur</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Ucraino</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Uzbeko</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Yiddish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Yoruba</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Cinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Portoghese (Brasile)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Portoghese (Portogallo)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Cinese semplificato</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Cinese tradizionale</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Lingue Europa Occidentale</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Lingue Europa Occidentale con Euro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Slavo/Lingue Europa Centrale</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galiziano, Maltese, Turco</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Vecchio set di caratteri Baltico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Cirillico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Greco Moderno</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Baltico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Cetico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Set di caratteri Ebraico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Ucraino, Bielorusso</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Set di caratteri Cinese Semplificato</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Set di caratteri Cinese Tradizionale</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Set di caratteri Giapponese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Set di caratteri Coreano</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Set di Caratteri Thai</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Cirillico per Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Slavo/Lingue Europa Centrale per Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Arabo per Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation>Avestan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation>Akan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation>Aragonese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation>Avarico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation>Bielorusso</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation>Bambara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation>Bosniaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation>Ceceno</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation>Cree</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation>Church</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation>Chuvash</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation>Divehi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation>Dzongkha</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation>Fulah</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation>Fijian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation>Gaelico</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation>Manx</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation>Hiri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation>Haitian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation>Herero</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation>Chamorro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation>Sichuan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation>Inupiaq</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation>Ido</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation>Kikuyu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation>Kuanyama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation>Kanuri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation>Komi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation>Cornish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation>Lussemburghese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation>Ganda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation>Limburgan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation>Lao</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation>Luba-Katanga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation>Marshallese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation>Ndebele</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation>Ndonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation>Navajo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation>Chichewa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation>Ojibwa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation>Oromo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation>Ossetian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation>Panjabi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation>Pali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation>Pushto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation>Romansh</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation>Rundi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation>Sardo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation>Sami</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation>Sango</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation>Sinhala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation>Swati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation>Sotho</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation>Tswana</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation>Tahitian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation>Venda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation>Walloon</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Bokmål</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation>Volapük</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Scegli il nome del file</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Confermi sovrascrittura?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>il file esiste già.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Errore durante il salvataggio del file</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Non è stato possibile salvare il registro</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Registri</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Finestra registro</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Salva</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Copia negli appunti</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Chiudi</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Name</source>
        <translation>Nome</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Length</source>
        <translation>Durata</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="815"/>
        <source>Choose a file</source>
        <translation>Scegli un file</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="835"/>
        <source>Choose a filename</source>
        <translation>Scegli il nome del file</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="849"/>
        <source>Confirm overwrite?</source>
        <translation>Confermi sovrascrittura?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1075"/>
        <source>Select one or more files to open</source>
        <translation>Selezionare uno o più file da aprire</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1077"/>
        <source>Multimedia</source>
        <translation type="unfinished">Multimedia</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1139"/>
        <source>Choose a directory</source>
        <translation>Scegli una cartella</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="850"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Il file  %1 esiste già.
Vuoi sovrascriverlo?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1364"/>
        <source>Edit name</source>
        <translation>Modifica nome</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1365"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Inserisci il nome per questo file che sarà visualizzato nella lista di riproduzione:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Play</source>
        <translation>&amp;Riproduci</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>&amp;Edit</source>
        <translation>&amp;Modifica</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="393"/>
        <source>ROSA Media Player - Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="817"/>
        <location filename="../playlist.cpp" line="837"/>
        <source>Playlists</source>
        <translation>Liste di riproduzione</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>All files</source>
        <translation>Tutti i file</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>&amp;Load</source>
        <translation>&amp;Apri</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="345"/>
        <source>&amp;Save</source>
        <translation>&amp;Salva</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Next</source>
        <translation>Prossi&amp;mo</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="350"/>
        <source>Pre&amp;vious</source>
        <translation>Precede&amp;nte</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="365"/>
        <source>Move &amp;up</source>
        <translation>Manda &amp;su</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="366"/>
        <source>Move &amp;down</source>
        <translation>Manda &amp;giù</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Ripeti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>S&amp;huffle</source>
        <translation>R&amp;iproduzione Casuale</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Add &amp;current file</source>
        <translation>Aggiungi il file &amp;corrente</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="375"/>
        <source>Add &amp;file(s)</source>
        <translation>Aggiungi &amp;file</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="376"/>
        <source>Add &amp;directory</source>
        <translation>Aggiungi c&amp;artella</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Remove &amp;selected</source>
        <translation>R&amp;imuovi selezionati</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="380"/>
        <source>Remove &amp;all</source>
        <translation>Ri&amp;muovi tutti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="387"/>
        <source>Add...</source>
        <translation>Aggiungi...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="389"/>
        <source>Remove...</source>
        <translation>Rimuovi...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="879"/>
        <source>Playlist modified</source>
        <translation>Lista di riproduzione modificata</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="880"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Ci sono modifiche non salvate. Vuoi salvare la lista di riproduzione?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>Preferences</source>
        <translation>Preferenze</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Lista di riproduzione - Preferenze</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Selezionare questa opzione se si vuole che, aggiungendo una cartella, vengano aggiunti ricorsivamente anche i file presenti nelle sottocartelle. Altrimenti solo i file presenti nella cartella saranno aggiunti.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>&amp;Aggiungi ricorsivamente i file nelle cartelle</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Selezionare questa opzione per estrarre alcune informazioni dai file aggiunti alla lista di riproduzione. Questo permette di visualizzare il titolo (se disponibile) e la durata dei file, altrimenti le stesse informazioni non saranno disponibili fino al momento dell&apos;effettiva riproduzione dei file stessi. &lt;br&gt;&lt;B&gt;Attenzione:&lt;/B&gt; questa opzione può rivelarsi molto lenta, soprattutto aggiungendo molti file.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>&amp;Estrarre automaticamente informazioni dai file aggiunti </translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>&amp;Salva una copia della lista di riproduzione in uscita</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>&amp;Riproduci file dall&apos;inizio</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Non tutti i file sono stati associati. Controlla i permessi e riprova.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Tipi di file</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Seleziona tutti</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Seleziona tutti i tipi di file della lista </translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Deseleziona tutti i tipi di file della lista </translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Lista dei tipi di file</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Tipi di file</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Seleziona tutti</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Nessuna selezione</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Nessuna selezione</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation>&lt;b&gt;Nota:&lt;/b&gt; (Non funziona in Windows Vista).</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <source>Drives</source>
        <translation type="obsolete">Dispositivi</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">icona</translation>
    </message>
    <message>
        <source>CD device</source>
        <translation type="obsolete">Dispositivo CD</translation>
    </message>
    <message>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation type="obsolete">Scegli il dispositivo CDROM. Sarà usato per riprodurre VCD e CD audio.</translation>
    </message>
    <message>
        <source>DVD device</source>
        <translation type="obsolete">Dispositivo DVD</translation>
    </message>
    <message>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation type="obsolete">Scegli il dispositivo DVD. Sarà usato per riprodurre DVD.</translation>
    </message>
    <message>
        <source>Select your &amp;CD device:</source>
        <translation type="obsolete">Seleziona il dispositivo &amp;CD:</translation>
    </message>
    <message>
        <source>Select your &amp;DVD device:</source>
        <translation type="obsolete">Seleziona il dispositivo &amp;DVD:</translation>
    </message>
    <message>
        <source>Enable DVD menus</source>
        <translation type="obsolete">Abilita menu DVD</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note 1&lt;/b&gt;: cache will be disabled, this can affect performance.</source>
        <translation type="obsolete">&lt;b&gt;Nota 1&lt;/b&gt;: la cache verrà disattivata, perciò le prestazioni potrebbero risentirne.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note 2&lt;/b&gt;: you may want to assign the action &quot;activate option in DVD menus&quot; to one of the mouse buttons.</source>
        <translation type="obsolete">&lt;b&gt;Nota 2&lt;/b&gt;: potrebbe essere utile assegnare l&apos;azione &quot;attiva l&apos;opzione evidenziata nei menù DVD&quot; ad uno dei pulsanti del mouse.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note 3&lt;/b&gt;: this feature is under development, expect a lot of issues with it.</source>
        <translation type="obsolete">&lt;b&gt;Nota 3&lt;/b&gt;: questa funzionalità è in fase di sviluppo, aspettati alcune sorprese.</translation>
    </message>
    <message>
        <source>&amp;Enable DVD menus (experimental)</source>
        <translation type="obsolete">A&amp;bilita menu DVD (sperimentale)</translation>
    </message>
    <message>
        <source>&amp;Scan for CD/DVD drives</source>
        <translation type="obsolete">Con&amp;trolla CD/DVD</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="76"/>
        <source>General</source>
        <translation>Generale</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="obsolete">&amp;Generale</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="318"/>
        <source>Media settings</source>
        <translation>Impostazioni media</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="65"/>
        <source>&amp;Disable screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="94"/>
        <source>Cha&amp;nnels by default:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="125"/>
        <location filename="../prefgeneral.cpp" line="375"/>
        <source>Main window</source>
        <translation type="unfinished">Finestra principale</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="133"/>
        <source>A&amp;utoresize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="193"/>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>Instances</source>
        <translation type="unfinished">Istanze</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="202"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="221"/>
        <source>&amp;Volume normalization by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">&amp;Ridimensionamento automatico:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="150"/>
        <source>Never</source>
        <translation type="unfinished">Mai</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="155"/>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished">Quando è necessario</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="160"/>
        <source>Only after loading a new video</source>
        <translation type="unfinished">Solo dopo aver aperto in nuovo video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="183"/>
        <source>R&amp;emember position and size</source>
        <translation type="unfinished">Ricorda posizione &amp;e dimensione</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation type="obsolete">Audio e sottotitoli preferiti</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation type="obsolete">Riproduci video a tutto schermo</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Disable screensaver</source>
        <translation>Disabilita salvaschermo</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="212"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Audio</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">AC3/DTS in uscita su S/PDIF</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation type="obsolete">Seleziona eseguibile mplayer</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation type="obsolete">Eseguibili</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="obsolete">Tutti i file</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation type="obsolete">Seleziona una cartella</translation>
    </message>
    <message>
        <source>MPlayer executable</source>
        <translation type="obsolete">Eseguibile MPlayer</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="321"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screenshots folder</source>
        <translation type="obsolete">Cartella per il salvataggio schermate</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="334"/>
        <source>Automatically add files to playlist</source>
        <translation type="unfinished">Aggiungi automaticamente file alla lista di riproduzione</translation>
    </message>
    <message>
        <source>Video output driver</source>
        <translation type="obsolete">Driver di uscita video</translation>
    </message>
    <message>
        <source>Audio output driver</source>
        <translation type="obsolete">Driver di uscita audio</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation type="obsolete">Seleziona il driver di uscita audio.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="320"/>
        <source>Remember settings</source>
        <translation>Ricorda opzioni</translation>
    </message>
    <message>
        <source>Software video equalizer</source>
        <translation type="obsolete">Equalizzatore video software</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="obsolete">Seleziona questa opzione se l&apos;equalizzatore video non è supportato dalla scheda grafica o dal driver video selezionato.&lt;br&gt;&lt;b&gt;Nota:&lt;/b&gt; questa opzione può essere incompatibile con alcuni driver video.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation type="obsolete">Se selezioni questa opzione, tutti i video partiranno a tutto schermo.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="348"/>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Software volume control</source>
        <translation type="obsolete">Controllo volume software</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="obsolete">Seleziona questa opzione  per usare il mixer software, invece di quello della scheda audio.</translation>
    </message>
    <message>
        <source>Postprocessing quality</source>
        <translation type="obsolete">Qualità di postprocessing</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="obsolete">Cambia dinamicamente il livello di postprocessing a seconda del tempo di CPU disponibile. Il numero che specifichi sarà il massimo livello usato. Normalmente si possono usare numeri molto grandi.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="51"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>&amp;Ricorda le impostazioni per tutti i file (traccia audio, sottotitoli...)</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Lista di riproduzione</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="72"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation type="unfinished">&amp;Aggiungi automaticamente file alla lista di riproduzione</translation>
    </message>
    <message>
        <source>&amp;Quality:</source>
        <translation type="obsolete">&amp;Qualità:</translation>
    </message>
    <message>
        <source>Start videos in &amp;fullscreen</source>
        <translation type="obsolete">&amp;Riproduci video a tutto schermo</translation>
    </message>
    <message>
        <source>Disable &amp;screensaver</source>
        <translation type="obsolete">Disabilita &amp;salvaschermo</translation>
    </message>
    <message>
        <source>Use s&amp;oftware volume control</source>
        <translation type="obsolete">Usa controllo del volume s&amp;oftware</translation>
    </message>
    <message>
        <source>Ma&amp;x. Amplification:</source>
        <translation type="obsolete">Ma&amp;ssima amplificazione:</translation>
    </message>
    <message>
        <source>&amp;AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">&amp;AC3/DTS in uscita su S/PDIF</translation>
    </message>
    <message>
        <source>Direct rendering</source>
        <translation type="obsolete">Rendering diretto</translation>
    </message>
    <message>
        <source>Double buffering</source>
        <translation type="obsolete">Doppio buffering</translation>
    </message>
    <message>
        <source>D&amp;irect rendering</source>
        <translation type="obsolete">Rendering d&amp;iretto</translation>
    </message>
    <message>
        <source>Dou&amp;ble buffering</source>
        <translation type="obsolete">Doppio &amp;buffering</translation>
    </message>
    <message>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation type="obsolete">Il doppio buffering previene lo sfarfallio salvando due frame in memoria e mostrandone uno mentre decodifica l&apos;altro. Se disabilitato può influenzare negativamente l&apos;OSD, ma spesso ne rimuove lo sfarfallio.</translation>
    </message>
    <message>
        <source>&amp;Enable postprocessing by default</source>
        <translation type="obsolete">Abilita il &amp;postprocessing</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Volume &amp;normalizzato in modo predefinito</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="325"/>
        <source>Close when finished</source>
        <translation>Chiudi alla fine</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="326"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Selezionando questa opzione, la finestra principale verrà chiusa alla fine del file/della lista di riproduzione.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="92"/>
        <source>2 (Stereo)</source>
        <translation>2 (Stereo)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="93"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 Surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="94"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 Surround)</translation>
    </message>
    <message>
        <source>C&amp;hannels by default:</source>
        <translation type="obsolete">C&amp;anali predefiniti:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="79"/>
        <source>&amp;Pause when minimized</source>
        <translation>&amp;Pausa se minimizzato</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="329"/>
        <source>Pause when minimized</source>
        <translation>Pausa se minimizzato</translation>
    </message>
    <message>
        <source>Enable postprocessing by default</source>
        <translation type="obsolete">Abilita postprocessing per default</translation>
    </message>
    <message>
        <source>Max. Amplification</source>
        <translation type="obsolete">Massima amplificazione</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="394"/>
        <source>Volume normalization by default</source>
        <translation type="unfinished">Volume normalizzato per default</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="unfinished">Massimizza il volume senza distorcere il suono.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="364"/>
        <source>Channels by default</source>
        <translation>Canali predefiniti</translation>
    </message>
    <message>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation type="obsolete">Massimo livello di amplificazione in percentuale (predefinito:110). Un valore di 200 permetterà di alzare il volume fino a un massimo del doppio del livello corrente. Con valori inferiori a 100 il volume iniziale (che è al 100%) sarà sotto il massimo, per cui, ad esempio, l&apos;OSD non verrà mostrato correttamente.</translation>
    </message>
    <message>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation type="obsolete">Il postprocessing sarà usato nei nuovi file aperti.</translation>
    </message>
    <message>
        <source>High speed &amp;playback without altering pitch</source>
        <translation type="obsolete">Ri&amp;produzione ad alta velocità senza alterazione del pitch</translation>
    </message>
    <message>
        <source>High speed playback without altering pitch</source>
        <translation type="obsolete">Riproduzione ad alta velocità senza alterazione del pitch</translation>
    </message>
    <message>
        <source>Allows to change the playback speed without altering pitch. Requires at least MPlayer dev-SVN-r24924.</source>
        <translation type="obsolete">Permette di cambiare la velocità di riproduzione senza alterare il pitch. Richiede almeno MPlayer dev-SVN-r24924.</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="obsolete">&amp;Video</translation>
    </message>
    <message>
        <source>Use s&amp;oftware video equalizer</source>
        <translation type="obsolete">Usa equalizzatore video s&amp;oftware</translation>
    </message>
    <message>
        <source>A&amp;udio</source>
        <translation type="obsolete">A&amp;udio</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">Volume</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nessuno</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">LowPass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normale)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (doppio frame rate)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Linear Blend</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Kerndeint</translation>
    </message>
    <message>
        <source>Deinterlace by default</source>
        <translation type="obsolete">Deinterlacciamento predefinito</translation>
    </message>
    <message>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation type="obsolete">Selezionare il filtro di deinterlacciamento predefinito. </translation>
    </message>
    <message>
        <source>Remember time position</source>
        <translation type="obsolete">Ricorda posizione temporale</translation>
    </message>
    <message>
        <source>Remember &amp;time position</source>
        <translation type="obsolete">Ricorda posizione &amp;temporale</translation>
    </message>
    <message>
        <source>Enable the audio equalizer</source>
        <translation type="obsolete">Abilita equalizzatore audio</translation>
    </message>
    <message>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation type="obsolete">Seleziona questa opzione se vuoi usare l&apos;equalizzatore audio.</translation>
    </message>
    <message>
        <source>&amp;Enable the audio equalizer</source>
        <translation type="obsolete">Abilita &amp;equalizzatore audio</translation>
    </message>
    <message>
        <source>Draw video using slices</source>
        <translation type="obsolete">Disegno del video a strisce</translation>
    </message>
    <message>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation type="obsolete">Abilita/disabilita il disegno del video a strisce/bande alte 16 pixel. Quando disabilitato l&apos;intero fotogramma viene disegnato tutto in una volta, ciò può essere più veloce o più lento, a secondo della scheda video e della cache disponibile. Ha effetto solo con i codec libmpeg2 e libavcodec.</translation>
    </message>
    <message>
        <source>Dra&amp;w video using slices</source>
        <translation type="obsolete">&amp;Disegno del video a strisce</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="58"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Chiudi quando termina la riproduzione</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="obsolete">veloce</translation>
    </message>
    <message>
        <source>slow</source>
        <translation type="obsolete">lento</translation>
    </message>
    <message>
        <source>fast - ATI cards</source>
        <translation type="obsolete">veloce - schede ATI</translation>
    </message>
    <message>
        <source>User defined...</source>
        <translation type="obsolete">Definito dall&apos;utente...</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="335"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default zoom</source>
        <translation type="obsolete">Zoom predefinito</translation>
    </message>
    <message>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation type="obsolete">Questa opzione imposta lo zoom predefinito che sarà usato per i nuovi video.</translation>
    </message>
    <message>
        <source>Default &amp;zoom:</source>
        <translation type="obsolete">&amp;Zoom predefinito:</translation>
    </message>
    <message>
        <source>Select the video output driver. %1 provides the best performance.</source>
        <translation type="obsolete">Seleziona il driver di uscita video. %1 dà prestazioni migliori.</translation>
    </message>
    <message>
        <source>%1 is the recommended one. Try to avoid %2 and %3, they are slow and can have an impact on performance.</source>
        <translation type="obsolete">%1 è quello raccomandato. Cerca di evitare %2 e %3, sono lenti e possono influenzare le prestazioni.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="330"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Con questa opzione abilitata, la riproduzione andrà in pausa quando la finestra è minimizzata. La riproduzione riprenderà ripristinando la finestra.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="377"/>
        <source>Autoresize</source>
        <translation type="unfinished">Ridimensionamento automatico</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="378"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="unfinished">La finestra principale può essere ridimensionata automaticamente. Selezionare l&apos;opzione preferita.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="381"/>
        <source>Remember position and size</source>
        <translation type="unfinished">Ricorda posizione e dimensione</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Seleziona questa opzione per disabilitare lo screensaver.&lt;br&gt;Sarà poi riattivato alla fine della riproduzione.</translation>
    </message>
    <message>
        <source>Ou&amp;tput driver:</source>
        <translation type="obsolete">Driver di &amp;uscita:</translation>
    </message>
    <message>
        <source>Add black borders on fullscreen</source>
        <translation type="obsolete">Aggiungi bordi neri nella modalità a schermo intero</translation>
    </message>
    <message>
        <source>If this option is enabled, black borders will be added to the image in fullscreen mode. This allows subtitles to be displayed on the black borders.</source>
        <translation type="obsolete">Con questa opzione abilitata, dei bordi neri saranno aggiunti all&apos;immagine nella modalità a schermo.intero. Questo permette ai sottotitoli di venire visualizzati sui bordi neri.</translation>
    </message>
    <message>
        <source>&amp;Add black borders on fullscreen</source>
        <translation type="obsolete">&amp;Aggiungi bordi neri nella modalità a schermo intero</translation>
    </message>
    <message>
        <source>If checked, turns on direct rendering (not supported by all codecs and video outputs)&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; May cause OSD/SUB corruption!</source>
        <translation type="obsolete">Se abilitata, attiva il rendering diretto(non supportato da tutti i codec e uscite video)&lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; Potrebbe causare la corruzione di OSD/SUB!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="365"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Il numero dei canali audio di riproduzione richiesti. MPlayer chiede al decodificatore di decodificare l&apos;audio nel numero canali specificati. Quindi è il decodificatore che asseconda la richiesta. Solitamente questo è importante solo quando si riproducono video con audio AC3 (come i DVD). In quel caso liba52 gestisce la decodifica in modo predefinito e mixa l&apos;audio nel numero di canali richiesti. &lt;b&gt;Nota&lt;/b&gt;: Questa opzione viene rispettata da alcuni codec (solo AC3), filtri (surround) e driver di uscita audio (sicuramente OSS).</translation>
    </message>
    <message>
        <source>Enable screenshots</source>
        <translation type="obsolete">Abilita schermate</translation>
    </message>
    <message>
        <source>You can use this option to enable or disable the possibility to take screenshots.</source>
        <translation type="obsolete">Puoi usare questa opzione per abilitare o disabilitare la possibilità di catturare schermate.</translation>
    </message>
    <message>
        <source>&amp;MPlayer executable:</source>
        <translation type="obsolete">Eseguibile &amp;Mplayer:</translation>
    </message>
    <message>
        <source>Screenshots</source>
        <translation type="obsolete">Schermata</translation>
    </message>
    <message>
        <source>&amp;Enable screenshots</source>
        <translation type="obsolete">Abilita sch&amp;ermata</translation>
    </message>
    <message>
        <source>&amp;Folder:</source>
        <translation type="obsolete">Car&amp;tella:</translation>
    </message>
    <message>
        <source>Global volume</source>
        <translation type="obsolete">Volume globale</translation>
    </message>
    <message>
        <source>If this option is checked, the same volume will be used for all files you play. If the option is not checked each file uses its own volume.</source>
        <translation type="obsolete">Se l&apos;opzione è abilitata, lo stesso identico livello di volume sarà usato in tutti i file che riproduci. Se l&apos;opzione non è abilitata ciascun file userà il proprio livello di volume.</translation>
    </message>
    <message>
        <source>This option also applies for the mute control.</source>
        <translation type="obsolete">Questa opzione si applica anche al controllo di muto.</translation>
    </message>
    <message>
        <source>Glo&amp;bal volume</source>
        <translation type="obsolete">Volume glo&amp;bale</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Switch screensaver off</source>
        <translation>Disabilita salvaschermo</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="342"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation>Questa opzione disabilita il salvaschermo non appena comincia la riproduzione e lo riabilita quando termina. Se l&apos;opzione è attiva, il salvaschermo non si attiverà neppure quando si ascoltano file sonori o quando la riproduzione è in pausa.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="347"/>
        <source>Avoid screensaver</source>
        <translation>Evita salvaschermo</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation type="obsolete">Salvaschermo</translation>
    </message>
    <message>
        <source>Swit&amp;ch screensaver off</source>
        <translation type="obsolete">Disabilita salvas&amp;chermo</translation>
    </message>
    <message>
        <source>Avoid &amp;screensaver</source>
        <translation type="obsolete">Evita &amp;salvaschermo</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="360"/>
        <source>Audio/video auto synchronization</source>
        <translation>Sincronizzazione automatica Audio/Video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Aggiusta gradualmente la sincronia Audio/Video basandosi sulle misure del ritardo audio.</translation>
    </message>
    <message>
        <source>A-V sync correction</source>
        <translation type="obsolete">Correzione sincronia Audio-Video</translation>
    </message>
    <message>
        <source>Maximum A-V sync correction per frame (in seconds)</source>
        <translation type="obsolete">Correzione Audio-Video massima per frame (in secondi)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation type="obsolete">Sincronia</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="44"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>S&amp;incronizzazione automatica Audio/Video</translation>
    </message>
    <message>
        <source>&amp;Factor:</source>
        <translation type="obsolete">&amp;Fattore:</translation>
    </message>
    <message>
        <source>A-V sync &amp;correction</source>
        <translation type="obsolete">&amp;Correzione sincronia Audio/Video</translation>
    </message>
    <message>
        <source>&amp;Max. correction:</source>
        <translation type="obsolete">Correzione &amp;max.:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note:&lt;/b&gt; This option won&apos;t be used for TV channels.</source>
        <translation type="obsolete">&lt;b&gt;Nota:&lt;/b&gt; Questa opzione non sarà usata per i canali TV.</translation>
    </message>
    <message>
        <source>Dei&amp;nterlace by default (except for TV):</source>
        <translation type="obsolete">Dei&amp;nterlacciamento predefinito (tranne che per la TV):</translation>
    </message>
    <message>
        <source>Disable video filters when using vdpau</source>
        <translation type="obsolete">Disabilita i filtri video quando è in uso vdpau</translation>
    </message>
    <message>
        <source>Usually video filters won&apos;t work when using vdpau as video output driver, so it&apos;s wise to keep this option checked.</source>
        <translation type="obsolete">Normalmente i filtri video non funzioneranno quando vdpau è in uso come driver di uscita, quindi è saggio mantenere questa opzione abilitata.</translation>
    </message>
    <message>
        <source>Disable video filters when using vd&amp;pau</source>
        <translation type="obsolete">Disabilita i filtri video quando vd&amp;pau è in uso</translation>
    </message>
    <message>
        <source>Uses hardware AC3 passthrough.</source>
        <translation type="obsolete">Utilizza l&apos;hardware per riprodurre AC3.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note:&lt;/b&gt; none of the audio filters will be used when this option is enabled.</source>
        <translation type="obsolete">&lt;b&gt;Nota:&lt;/b&gt; nessun filtro audio verrà usato se l&apos;opzione è abilitata.</translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="obsolete">Tastiera e mouse</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="obsolete">&amp;Tastiera</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">icona</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Qui è possibile cambiare le scorciatoie da tastiera. Per farlo, fare doppio clic o scrivere nella cella corrispondente. Opzionalmente, salvare la lista per condividerla con altre persone o utilizzarla su un altro computer.</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="obsolete">&amp;Mouse</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation type="obsolete">Funzione pulsanti:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation type="obsolete">Ricerca nel file</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation type="obsolete">Controllo volume</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="obsolete">Zoom video</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nessuno</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Qui puoi cambiare le scorciatoie da tastiera. Per farlo, fai doppio click o scrivi nella cella corrispondente. Opzionalmente, puoi salvare la lista per condividerla con altre persone o utilizzarla su un altro computer.</translation>
    </message>
    <message>
        <source>&amp;Left click</source>
        <translation type="obsolete">Clic &amp;sinistro</translation>
    </message>
    <message>
        <source>&amp;Double click</source>
        <translation type="obsolete">&amp;Doppio clic</translation>
    </message>
    <message>
        <source>&amp;Wheel function:</source>
        <translation type="obsolete">Funzione della rotelli&amp;na del mouse:</translation>
    </message>
    <message>
        <source>Shortcut editor</source>
        <translation type="obsolete">Editor delle scorciatoie</translation>
    </message>
    <message>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation type="obsolete">Questa tabella permette di cambiare le scorciatoie da tastiera. Fare doppio click, premere Invio o premere il bottone &lt;b&gt;Cambia scorciatoia&lt;/b&gt; su un elemento per attivare il dialogo &lt;i&gt;Modifica scorciatoia&lt;/i&gt;. Ci sono due modi per modificare una scorciatoia: se il bottone &lt;b&gt;Cattura&lt;/b&gt; è attivato, basta premere il nuovo tasto (o combinazione di tasti) da assegnare all&apos;azione (sfortunatamente ciò non funziona con tutti i tasti). Se il bottone &lt;b&gt;Cattura&lt;/b&gt; è disattivato puoi inserire manualmente il nome del tasto.</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation type="obsolete">Clic sinistro</translation>
    </message>
    <message>
        <source>Select the action for left click on the mouse.</source>
        <translation type="obsolete">Selezionare l&apos;azione per il clic sinistro del mouse.</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation type="obsolete">Doppio clic</translation>
    </message>
    <message>
        <source>Select the action for double click on the mouse.</source>
        <translation type="obsolete">Selezionare l&apos;azione per il doppio clic del mouse.</translation>
    </message>
    <message>
        <source>Wheel function</source>
        <translation type="obsolete">Funzione rotellina</translation>
    </message>
    <message>
        <source>Select the action for the mouse wheel.</source>
        <translation type="obsolete">Selezionare l&apos;azione per la rotellina del mouse.</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="obsolete">Riproduci</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pausa</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="obsolete">Tutto schermo</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation type="obsolete">Compatto</translation>
    </message>
    <message>
        <source>Screenshot</source>
        <translation type="obsolete">Schermata</translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="obsolete">Muto</translation>
    </message>
    <message>
        <source>Frame counter</source>
        <translation type="obsolete">Contatore fotogrammi</translation>
    </message>
    <message>
        <source>Reset zoom</source>
        <translation type="obsolete">Reinizializza zoom</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="obsolete">Esci da tutto schermo</translation>
    </message>
    <message>
        <source>Double size</source>
        <translation type="obsolete">Grandezza doppia</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation type="obsolete">Riproduci / Pausa</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation type="obsolete">Pausa / Per fotogramma</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Lista di riproduzione</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Preferenze</translation>
    </message>
    <message>
        <source>No function</source>
        <translation type="obsolete">Nessuna funzione</translation>
    </message>
    <message>
        <source>Change speed</source>
        <translation type="obsolete">Cambia velocità</translation>
    </message>
    <message>
        <source>Normal speed</source>
        <translation type="obsolete">Velocità normale</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Tastiera</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Mouse</translation>
    </message>
    <message>
        <source>Middle click</source>
        <translation type="obsolete">Clic centrale</translation>
    </message>
    <message>
        <source>Select the action for middle click on the mouse.</source>
        <translation type="obsolete">Selezionare l&apos;azione per il clic centrale del mouse.</translation>
    </message>
    <message>
        <source>M&amp;iddle click</source>
        <translation type="obsolete">Cl&amp;ic centrale</translation>
    </message>
    <message>
        <source>X Button &amp;1</source>
        <translation type="obsolete">Pulsante X &amp;1</translation>
    </message>
    <message>
        <source>X Button &amp;2</source>
        <translation type="obsolete">Pulsante X &amp;2</translation>
    </message>
    <message>
        <source>Go backward (short)</source>
        <translation type="obsolete">Vai indietro (corto)</translation>
    </message>
    <message>
        <source>Go backward (medium)</source>
        <translation type="obsolete">Vai indietro (medio)</translation>
    </message>
    <message>
        <source>Go backward (long)</source>
        <translation type="obsolete">Vai indietro (lungo)</translation>
    </message>
    <message>
        <source>Go forward (short)</source>
        <translation type="obsolete">Vai avanti (corto)</translation>
    </message>
    <message>
        <source>Go forward (medium)</source>
        <translation type="obsolete">Vai avanti (medio)</translation>
    </message>
    <message>
        <source>Go forward (long)</source>
        <translation type="obsolete">Vai avanti (lungo)</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="obsolete">OSD - Livello successivo</translation>
    </message>
    <message>
        <source>Show context menu</source>
        <translation type="obsolete">Mostra menù contestuale</translation>
    </message>
    <message>
        <source>&amp;Right click</source>
        <translation type="obsolete">Clic dest&amp;ro</translation>
    </message>
    <message>
        <source>Increase volume</source>
        <translation type="obsolete">Alza volume</translation>
    </message>
    <message>
        <source>Decrease volume</source>
        <translation type="obsolete">Abbassa volume</translation>
    </message>
    <message>
        <source>X Button 1</source>
        <translation type="obsolete">Pulsante X 1</translation>
    </message>
    <message>
        <source>Select the action for the X button 1.</source>
        <translation type="obsolete">Scegli l&apos;azione per il pulsante X 1.</translation>
    </message>
    <message>
        <source>X Button 2</source>
        <translation type="obsolete">Pulsante X 2</translation>
    </message>
    <message>
        <source>Select the action for the X button 2.</source>
        <translation type="obsolete">Scegli l&apos;azione per il pulsante X 2.</translation>
    </message>
    <message>
        <source>Show video equalizer</source>
        <translation type="obsolete">Mostra equalizzatore video</translation>
    </message>
    <message>
        <source>Show audio equalizer</source>
        <translation type="obsolete">Mostra equalizzatore audio</translation>
    </message>
    <message>
        <source>Always on top</source>
        <translation type="obsolete">Sempre in primo piano</translation>
    </message>
    <message>
        <source>Never on top</source>
        <translation type="obsolete">Mai in primo piano</translation>
    </message>
    <message>
        <source>On top while playing</source>
        <translation type="obsolete">In primo piano durante la riproduzione</translation>
    </message>
    <message>
        <source>Activate option under mouse in DVD menus</source>
        <translation type="obsolete">Attiva l&apos;opzione sotto il mouse nei menu DVD</translation>
    </message>
    <message>
        <source>Return to main DVD menu</source>
        <translation type="obsolete">Ritorna al menu DVD principale</translation>
    </message>
    <message>
        <source>Return to previous menu in DVD menus</source>
        <translation type="obsolete">Ritorna al menu precedente nei menu DVD</translation>
    </message>
    <message>
        <source>Move cursor up in DVD menus</source>
        <translation type="obsolete">Muovi su il cursore nei menu DVD</translation>
    </message>
    <message>
        <source>Move cursor down in DVD menus</source>
        <translation type="obsolete">Muovi giù il cursore nei menu DVD</translation>
    </message>
    <message>
        <source>Move cursor left in DVD menus</source>
        <translation type="obsolete">Muovi a sinistra il cursore nei menu DVD</translation>
    </message>
    <message>
        <source>Move cursor right in DVD menus</source>
        <translation type="obsolete">Muovi a destra il cursore nei menu DVD</translation>
    </message>
    <message>
        <source>Activate highlighted option in DVD menus</source>
        <translation type="obsolete">Attiva l&apos;opzione evidenziata nei menu DVD</translation>
    </message>
    <message>
        <source>Change function of wheel</source>
        <translation type="obsolete">Cambia la funzione della rotellina</translation>
    </message>
    <message>
        <source>Reverse mouse wheel seeking</source>
        <translation type="obsolete">Funzione di ricerca con la rotella del mouse invertita</translation>
    </message>
    <message>
        <source>Check it to seek in the opposite direction.</source>
        <translation type="obsolete">Abilita per effettuare ricerche nella direzione opposta.</translation>
    </message>
    <message>
        <source>R&amp;everse wheel media seeking</source>
        <translation type="obsolete">Ric&amp;erca invertita con la rotellina</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <source>Interface</source>
        <translation type="obsolete">Interfaccia</translation>
    </message>
    <message>
        <source>Volume normalization by default</source>
        <translation type="obsolete">Volume normalizzato per default</translation>
    </message>
    <message>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="obsolete">Massimizza il volume senza distorcere il suono.</translation>
    </message>
    <message>
        <source>Default subtitle encoding</source>
        <translation type="obsolete">Codifica dei sottotitoli</translation>
    </message>
    <message>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="obsolete">Selezionare la codifica usata automaticamente per i sottotitoli.</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation type="obsolete">Apertura automatica</translation>
    </message>
    <message>
        <source>Select the subtitle autoload method.</source>
        <translation type="obsolete">Selezionare il metodo di caricamento automatico dei sottotitoli.</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation type="obsolete">&lt;Automatico&gt;</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="obsolete">Predefinito</translation>
    </message>
    <message>
        <source>&amp;Interface</source>
        <translation type="obsolete">&amp;Interfaccia</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Mai</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation type="obsolete">Quando è necessario</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation type="obsolete">Solo dopo aver aperto in nuovo video</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation type="obsolete">File recenti</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Lingua</translation>
    </message>
    <message>
        <source>Here you can change the language of the application.</source>
        <translation type="obsolete">Qui è possibile modificare la lingua dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>Instances</source>
        <translation type="obsolete">Istanze</translation>
    </message>
    <message>
        <source>Ma&amp;x. items</source>
        <translation type="obsolete">Numero massimo di &amp;elementi</translation>
    </message>
    <message>
        <source>St&amp;yle:</source>
        <translation type="obsolete">St&amp;ile:</translation>
    </message>
    <message>
        <source>L&amp;anguage:</source>
        <translation type="obsolete">Lingu&amp;a:</translation>
    </message>
    <message>
        <source>Main window</source>
        <translation type="obsolete">Finestra principale</translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">&amp;Ridimensionamento automatico:</translation>
    </message>
    <message>
        <source>R&amp;emember position and size</source>
        <translation type="obsolete">Ricorda posizione &amp;e dimensione</translation>
    </message>
    <message>
        <source>Default font:</source>
        <translation type="obsolete">Carattere predefinito:</translation>
    </message>
    <message>
        <source>&amp;Change...</source>
        <translation type="obsolete">&amp;Cambia...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">Etichetta testo</translation>
    </message>
    <message>
        <source>Ins&amp;tances</source>
        <translation type="obsolete">Is&amp;tanze</translation>
    </message>
    <message>
        <source>Autoresize</source>
        <translation type="obsolete">Ridimensionamento automatico</translation>
    </message>
    <message>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="obsolete">La finestra principale può essere ridimensionata automaticamente. Selezionare l&apos;opzione preferita.</translation>
    </message>
    <message>
        <source>Remember position and size</source>
        <translation type="obsolete">Ricorda posizione e dimensione</translation>
    </message>
    <message>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation type="obsolete">Selezionare il massimo numero di elementi che saranno mostrati nel sotto-menù &lt;b&gt;Apri -&gt; File recenti&lt;/b&gt;. Un valore di 0 disabiliterà tale sotto-menù.</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stile</translation>
    </message>
    <message>
        <source>Select the style you prefer for the application.</source>
        <translation type="obsolete">Selezionare lo stile preferito.</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation type="obsolete">Carattere predefinito</translation>
    </message>
    <message>
        <source>You can change here the application&apos;s font.</source>
        <translation type="obsolete">Qui puoi modificare il carattere dell&apos;applicazione.</translation>
    </message>
    <message>
        <source>Default GUI</source>
        <translation type="obsolete">Interfaccia predefinita</translation>
    </message>
    <message>
        <source>Automatic port</source>
        <translation type="obsolete">Porta automatica</translation>
    </message>
    <message>
        <source>Manual port</source>
        <translation type="obsolete">Porta manuale</translation>
    </message>
    <message>
        <source>Port to listen</source>
        <translation type="obsolete">Porta in ascolto</translation>
    </message>
    <message>
        <source>&amp;Automatic</source>
        <translation type="obsolete">&amp;Automatico</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="obsolete">&amp;Manuale</translation>
    </message>
    <message>
        <source>Floating control</source>
        <translation type="obsolete">Controllo fluttuante</translation>
    </message>
    <message>
        <source>Animated</source>
        <translation type="obsolete">Animato</translation>
    </message>
    <message>
        <source>If this option is enabled, the floating control will appear with an animation.</source>
        <translation type="obsolete">Con questa opzione attiva, il controllo fluttuante farà la sua comparsa con una animazione.</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">Larghezza</translation>
    </message>
    <message>
        <source>Specifies the width of the control (as a percentage).</source>
        <translation type="obsolete">Specifica la larghezza del controllo (in percentuale).</translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="obsolete">Margine</translation>
    </message>
    <message>
        <source>This option sets the number of pixels that the floating control will be away from the bottom of the screen. Useful when the screen is a TV, as the overscan might prevent the control to be visible.</source>
        <translation type="obsolete">L&apos;opzione imposta il numero di pixel che il controllo fluttuante sarà distante dal fondo dello schermo. Utile se lo schermo è una TV, dato che l&apos; overscan potrebbe impedire al controllo di rendersi visibile.</translation>
    </message>
    <message>
        <source>Bypass window manager</source>
        <translation type="obsolete">Bypassa il window manager</translation>
    </message>
    <message>
        <source>If this option is checked, the control is displayed bypassing the window manager. Disable this option if the floating control doesn&apos;t work well with your window manager.</source>
        <translation type="obsolete">Con questa opzione abilitata, il controllo è visualizzato bypassando il window manager. Disabilita questa opzione se il controllo fluttuante non lavora bene con il window manager usato.</translation>
    </message>
    <message>
        <source>&amp;Floating control</source>
        <translation type="obsolete">Controllo &amp;fluttuante</translation>
    </message>
    <message>
        <source>The floating control appears in fullscreen mode when the mouse is moved to the bottom of the screen.</source>
        <translation type="obsolete">Il controllo fluttuante compare nella modalità a schermo intero quando il mouse tocca il fondo dello schermo.</translation>
    </message>
    <message>
        <source>&amp;Animated</source>
        <translation type="obsolete">&amp;Animato</translation>
    </message>
    <message>
        <source>&amp;Width:</source>
        <translation type="obsolete">&amp;Larghezza:</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>&amp;Margin:</source>
        <translation type="obsolete">&amp;Margine:</translation>
    </message>
    <message>
        <source>&amp;Bypass window manager</source>
        <translation type="obsolete">&amp;Bypassa il window manager</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Sottotitoli</translation>
    </message>
    <message>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="obsolete">Au&amp;tocarica sottotitoli (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation type="obsolete">Stesso nome del video</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation type="obsolete">Tutti quelli che contengono il nome del video</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation type="obsolete">Tutti i sottotitoli della cartella</translation>
    </message>
    <message>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="obsolete">Co&amp;difica dei sottotitoli:</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="obsolete">Audio</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Volume &amp;normalizzato in modo predefinito</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <source>Performance</source>
        <translation type="obsolete">Prestazioni</translation>
    </message>
    <message>
        <source>&amp;Performance</source>
        <translation type="obsolete">&amp;Prestazioni</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="obsolete">Priorità</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="obsolete">Selezionare la priorità del processo MPlayer.</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="obsolete">tempo reale</translation>
    </message>
    <message>
        <source>high</source>
        <translation type="obsolete">alta</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="obsolete">sopra al normale</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="obsolete">normale</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="obsolete">sotto al normale</translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="obsolete">idle</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="obsolete">Cache</translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="obsolete">KB</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation type="obsolete">Usare una cache può migliorare il rendimento nei media lenti</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="obsolete">Permetti scarto fotogrammi</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation type="obsolete">Cambio rapido della traccia audio</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation type="obsolete">Selezione rapida dei capitoli nei DVD</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="obsolete">Salta alcuni frame per mantenere la sincronia Audio/Video su sistemi lenti.</translation>
    </message>
    <message>
        <source>Allow hard frame drop</source>
        <translation type="obsolete">Permetti alto scarto fotogrammi</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="obsolete">Salto di frame molto intenso. Causa immagini distorte!</translation>
    </message>
    <message>
        <source>Priorit&amp;y:</source>
        <translation type="obsolete">Priori&amp;tà:</translation>
    </message>
    <message>
        <source>&amp;Allow frame drop</source>
        <translation type="obsolete">Permetti sc&amp;arto fotogrammi</translation>
    </message>
    <message>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation type="obsolete">&amp;Permetti alto scarto fotogrammi (può corrompere l&apos;immagine)</translation>
    </message>
    <message>
        <source>&amp;Fast audio track switching</source>
        <translation type="obsolete">Cambio &amp;rapido della traccia audio</translation>
    </message>
    <message>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation type="obsolete">&amp;Selezione rapida dei capitoli nei DVD</translation>
    </message>
    <message>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation type="obsolete">Se selezionata, si proverà il metodo più veloce di ricerca dei capitoli, ma può non funzionare con alcuni dischi.</translation>
    </message>
    <message>
        <source>Skip loop filter</source>
        <translation type="obsolete">Salta filtro loop</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation type="obsolete">H.264</translation>
    </message>
    <message>
        <source>Cache for files</source>
        <translation type="obsolete">Cache per i file</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation type="obsolete">Questa opzione specifica quanta memoria (in kByte) usare in fase di precaching di un file.</translation>
    </message>
    <message>
        <source>Cache for streams</source>
        <translation type="obsolete">Cache per i flussi</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation type="obsolete">Questa opzione specifica quanta memoria (in kByte) usare in fase di precaching di una URL.</translation>
    </message>
    <message>
        <source>Cache for DVDs</source>
        <translation type="obsolete">Cache per i DVD</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation type="obsolete">Questa opzione specifica quanta memoria (in kByte) usare in fase di precaching di un DVD.&lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; La ricerca temporale potrebbe non funzionare correttamente (insieme al cambio capitolo) usando la cache per un DVD.</translation>
    </message>
    <message>
        <source>&amp;Cache</source>
        <translation type="obsolete">&amp;Cache</translation>
    </message>
    <message>
        <source>Cache for &amp;DVDs:</source>
        <translation type="obsolete">Cache per i &amp;DVD:</translation>
    </message>
    <message>
        <source>Cache for &amp;local files:</source>
        <translation type="obsolete">Cache per i file &amp;locali:</translation>
    </message>
    <message>
        <source>Cache for &amp;streams:</source>
        <translation type="obsolete">Cache per i flu&amp;ssi:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Abilitato</translation>
    </message>
    <message>
        <source>Skip (always)</source>
        <translation type="obsolete">Salta (sempre)</translation>
    </message>
    <message>
        <source>Skip only on HD videos</source>
        <translation type="obsolete">Salta solo per i video HD</translation>
    </message>
    <message>
        <source>Loop &amp;filter</source>
        <translation type="obsolete">&amp;Filtro loop</translation>
    </message>
    <message>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation type="obsolete">Questa opzione permette di saltare il filtro loop (conosciuto anche come deblocking) durante la riproduzione di file H.264. Dal momento che il frame filtrato è usato come riferimento per i frame che da esso dipendono, questo ha un brutto effetto sulla qualità, ad esempio nei video MPEG-2. Ma almeno su HDTV ad alto bitrate, si potrà avere maggiore velocità senza perdita visibile di qualità.</translation>
    </message>
    <message>
        <source>Possible values:</source>
        <translation type="obsolete">Possibili valori:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation type="obsolete">&lt;b&gt;Abilitato&lt;/b&gt;: il filtro loop non viene saltato</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation type="obsolete">&lt;b&gt;Salta (sempre)&lt;/b&gt;: il filtro loop viene saltato senza tener conto della risoluzione video</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation type="obsolete">&lt;b&gt;Salta solo per i video HD&lt;/b&gt;: il filtro loop viene saltato solo su video la cui altezza è maggiore o uguale  di %1.</translation>
    </message>
    <message>
        <source>Cache for audio CDs</source>
        <translation type="obsolete">Cache per i CD audio</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation type="obsolete">Questa opzione specifica quanta memoria (in kByte) usare in fase di precaching di un CD audio.</translation>
    </message>
    <message>
        <source>Cache for &amp;audio CDs:</source>
        <translation type="obsolete">Cache per i CD &amp;audio:</translation>
    </message>
    <message>
        <source>Cache for VCDs</source>
        <translation type="obsolete">Cache per i VCD</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation type="obsolete">Questa opzione specifica quanta memoria (in kByte) usare in fase di precaching di un VCD.</translation>
    </message>
    <message>
        <source>Cache for &amp;VCDs:</source>
        <translation type="obsolete">Cache per i &amp;VCD:</translation>
    </message>
    <message>
        <source>Threads for decoding</source>
        <translation type="obsolete">Thread per la decodifica</translation>
    </message>
    <message>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation type="obsolete">Imposta il numero di thread da usare per la decodifica. Solo per MPEG-1/2 e H.264</translation>
    </message>
    <message>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation type="obsolete">Numero di &amp;thread per la decodifica (solo MPEG-1/2 e H.264):</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation type="obsolete">Definisce la priorità del processo per mplayer a seconda delle priorità predefinite disponibili in Windows. &lt;br&gt;&lt;b&gt;Attenzione:&lt;/b&gt; Usare la priorità realtime può causare blocchi al sistema.</translation>
    </message>
    <message>
        <source>Use CoreAVC if no other codec specified</source>
        <translation type="obsolete">Usa CoreAVC se non è specificato un altro codec</translation>
    </message>
    <message>
        <source>Try to use non-free CoreAVC codec with no other codec is specified and non-VDPAU video output selected. Requires MPlayer build with CoreAVC support.</source>
        <translation type="obsolete">Prova ad usare il codec non libero CoreAVC quando nessun altro codec è specificato ed è selezionata un&apos;uscita video non-VDPAU. Richiede MPlayer con il supporto a CoreAVC.</translation>
    </message>
    <message>
        <source>&amp;Use CoreAVC if no other codec specified</source>
        <translation type="obsolete">&amp;Usa CoreAVC se non è specificato un altro codec</translation>
    </message>
    <message>
        <source>Cache for &amp;TV:</source>
        <translation type="obsolete">Cache per la &amp;TV:</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation type="unfinished">Sottotitoli</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished">Audio e sottotitoli preferiti</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation type="obsolete">Scegli un file TTF</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation type="obsolete">Caratteri Truetype</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="obsolete">&amp;Sottotitoli</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation type="unfinished">Apertura automatica</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="obsolete">Selezionare i primi sottotitoli disponibili</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation type="unfinished">Stesso nome del video</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation type="unfinished">Tutti quelli che contengono il nome del video</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation type="unfinished">Tutti i sottotitoli della cartella</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="obsolete">Posizione</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="obsolete">in alto</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="obsolete">in basso</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation type="obsolete">Includi sottotitoli nelle schermate</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="obsolete">Carattere</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation type="obsolete">Selezionare il tipo di carattere che si userà per i sottotitoli (e OSD):</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Dimensione</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation type="obsolete">Nessun ridimensionamento automatico</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation type="obsolete">Proporzionale all&apos;altezza del video</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation type="obsolete">Proporzionale alla larghezza del video</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation type="obsolete">Proporzionale alla diagonale del video</translation>
    </message>
    <message>
        <source>Subtitle position</source>
        <translation type="obsolete">Posizione dei sottotitoli</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="obsolete">Questa opzione specifica la posizione dei sottotitoli nella finestra. &lt;i&gt;100&lt;/i&gt; significa in basso, mentre  &lt;i&gt;0&lt;/i&gt; significa in alto.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished">Au&amp;tocarica sottotitoli (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>S&amp;elect first available subtitle</source>
        <translation type="obsolete">S&amp;eleziona i primi sottotitoli disponibili</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="unfinished">Co&amp;difica dei sottotitoli:</translation>
    </message>
    <message>
        <source>Default &amp;position of the subtitles on screen</source>
        <translation type="obsolete">Posizione &amp;predefinita dei sottotitoli</translation>
    </message>
    <message>
        <source>&amp;Include subtitles on screenshots</source>
        <translation type="obsolete">&amp;Includi sottotitoli nelle schermate</translation>
    </message>
    <message>
        <source>&amp;TTF font:</source>
        <translation type="obsolete">Font &amp;TTF: </translation>
    </message>
    <message>
        <source>S&amp;ystem font:</source>
        <translation type="obsolete">Font di s&amp;istema:</translation>
    </message>
    <message>
        <source>A&amp;utoscale:</source>
        <translation type="obsolete">Dimensione a&amp;utomatica:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation type="unfinished">Codifica dei sottotitoli</translation>
    </message>
    <message>
        <source>TTF font</source>
        <translation type="obsolete">Font TTF</translation>
    </message>
    <message>
        <source>System font</source>
        <translation type="obsolete">Font di sistema</translation>
    </message>
    <message>
        <source>Here you can select a system font to be used for the subtitles and OSD. &lt;b&gt;Note:&lt;/b&gt; requires a MPlayer with fontconfig support.</source>
        <translation type="obsolete">Qui si possono selezionare i caratteri di sistema da usare per i sottotitoli e l&apos;OSD. &lt;b&gt;Nota:&lt;/b&gt; richiede MPlayer con supporto a fontconfig.</translation>
    </message>
    <message>
        <source>Autoscale</source>
        <translation type="obsolete">Dimensione automatica</translation>
    </message>
    <message>
        <source>Text color</source>
        <translation type="obsolete">Colore del testo</translation>
    </message>
    <message>
        <source>Select the color for the text of the subtitles.</source>
        <translation type="obsolete">Selezionare il colore per il testo dei sottotitoli.</translation>
    </message>
    <message>
        <source>Border color</source>
        <translation type="obsolete">Colore del bordo</translation>
    </message>
    <message>
        <source>Select the color for the border of the subtitles.</source>
        <translation type="obsolete">Selezionare il colore per i bordi dei sottotitoli.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation type="unfinished">Selezionare il metodo di caricamento automatico dei sottotitoli.</translation>
    </message>
    <message>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation type="obsolete">Se ci sono una o più tracce di sottotitoli disponibili, una di esse sarà selezionata automaticamente, normalmente la prima. a meno che una di esse non corrisponda alla lingua preferita dall&apos;utente, nel qual caso sarà usata quella.</translation>
    </message>
    <message>
        <source>Select the subtitle autoscaling method.</source>
        <translation type="obsolete">Selezionare il metodo di ridimensionamento automatico dei sottotitoli.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="unfinished">Selezionare la codifica usata automaticamente per i sottotitoli.</translation>
    </message>
    <message>
        <source>Try to autodetect for this language</source>
        <translation type="obsolete">Cerca in automatico per questa lingua</translation>
    </message>
    <message>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a MPlayer compiled with ENCA support.</source>
        <translation type="obsolete">Quando l&apos;opzione è attiva, la codifica dei sottotitoli verrà riconosciuta automaticamente in base alla lingua selezionata. Se il riconoscimento automatico dovesse fallire verrà impostata alla codifica predefinita. Questa opzione richiede MPlayer compilato con il supporto a ENCA.</translation>
    </message>
    <message>
        <source>Subtitle language</source>
        <translation type="obsolete">Lingua sottotitoli</translation>
    </message>
    <message>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation type="obsolete">Scegli la lingua per cui vuoi che venga effettuato il riconoscimento automatico della codifica.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation type="unfinished">Codifica</translation>
    </message>
    <message>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation type="obsolete">Cerca in a&amp;utomatico per questa lingua:</translation>
    </message>
    <message>
        <source>Here you can select a ttf font to be used for the subtitles. Usually you&apos;ll find a lot of ttf fonts in %1</source>
        <translation type="obsolete">Qui si possono selezionare i caratteri TTF da usare per i sottotitoli. Normalmente in %1 si trovano molti font</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation type="obsolete">Contorno</translation>
    </message>
    <message>
        <source>Select the font for the subtitles.</source>
        <translation type="obsolete">Seleziona il carattere per i sottotitoli.</translation>
    </message>
    <message>
        <source>The size in pixels.</source>
        <translation type="obsolete">La dimensione in pixel.</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Grassetto</translation>
    </message>
    <message>
        <source>If checked, the text will be displayed in &lt;b&gt;bold&lt;/b&gt;.</source>
        <translation type="obsolete">Se attivato, il testo sarà visualizzato in &lt;b&gt;grassetto&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Corsivo</translation>
    </message>
    <message>
        <source>If checked, the text will be displayed in &lt;i&gt;italic&lt;/i&gt;.</source>
        <translation type="obsolete">Se attivato, il testo sarà visualizzato in &lt;i&gt;corsivo&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">Margine sinistro</translation>
    </message>
    <message>
        <source>Specifies the left margin in pixels.</source>
        <translation type="obsolete">Specifica il margine sinistro in numero di pixel.</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">Margine destro</translation>
    </message>
    <message>
        <source>Specifies the right margin in pixels.</source>
        <translation type="obsolete">Specifica il margine destro in numero di pixel.</translation>
    </message>
    <message>
        <source>Vertical margin</source>
        <translation type="obsolete">Margine verticale</translation>
    </message>
    <message>
        <source>Specifies the vertical margin in pixels.</source>
        <translation type="obsolete">Specifica il margine verticale in numero di pixel.</translation>
    </message>
    <message>
        <source>Horizontal alignment</source>
        <translation type="obsolete">Allineamento orizzontale</translation>
    </message>
    <message>
        <source>Specifies the horizontal alignment. Possible values are left, centered and right.</source>
        <translation type="obsolete">Specifica l&apos;allineamento orizzontale. Possibili valori: sinistra, centrato e destra.</translation>
    </message>
    <message>
        <source>Vertical alignment</source>
        <translation type="obsolete">Allineamento verticale</translation>
    </message>
    <message>
        <source>Specifies the vertical alignment. Possible values: bottom, middle and top.</source>
        <translation type="obsolete">Specifica l&apos;allineamento verticale. Possibili valori: in basso, al centro, in alto.</translation>
    </message>
    <message>
        <source>Border style</source>
        <translation type="obsolete">Stile del bordo</translation>
    </message>
    <message>
        <source>Specifies the border style. Possible values: outline and opaque box.</source>
        <translation type="obsolete">Imposta lo stile di bordo. Valori possibili: contorno e riquadro opaco.</translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation type="obsolete">Ombra</translation>
    </message>
    <message>
        <source>Si&amp;ze:</source>
        <translation type="obsolete">Grande&amp;zza:</translation>
    </message>
    <message>
        <source>Bol&amp;d</source>
        <translation type="obsolete">&amp;Grassetto</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation type="obsolete">Cors&amp;ivo</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation type="obsolete">Colori</translation>
    </message>
    <message>
        <source>&amp;Text:</source>
        <translation type="obsolete">&amp;Testo:</translation>
    </message>
    <message>
        <source>&amp;Border:</source>
        <translation type="obsolete">&amp;Bordo:</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation type="obsolete">Margini</translation>
    </message>
    <message>
        <source>L&amp;eft:</source>
        <translation type="obsolete">&amp;Sinistro:</translation>
    </message>
    <message>
        <source>&amp;Right:</source>
        <translation type="obsolete">&amp;Destro:</translation>
    </message>
    <message>
        <source>Verti&amp;cal:</source>
        <translation type="obsolete">&amp;Verticale:</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="obsolete">Allineamento</translation>
    </message>
    <message>
        <source>&amp;Horizontal:</source>
        <translation type="obsolete">&amp;Orizzontale:</translation>
    </message>
    <message>
        <source>&amp;Vertical:</source>
        <translation type="obsolete">&amp;Verticale:</translation>
    </message>
    <message>
        <source>Border st&amp;yle:</source>
        <translation type="obsolete">S&amp;tile bordo:</translation>
    </message>
    <message>
        <source>&amp;Outline:</source>
        <translation type="obsolete">C&amp;ontorno:</translation>
    </message>
    <message>
        <source>Shado&amp;w:</source>
        <translation type="obsolete">O&amp;mbra:</translation>
    </message>
    <message>
        <source>The following options allows you to define the style to be used for non-styled subtitles (srt, sub...).</source>
        <translation type="obsolete">Le opzioni seguenti ti permettono di definire lo stile da usare per i sottotitoli senza uno stile incorporato (srt, sub...).</translation>
    </message>
    <message>
        <source>Left</source>
        <comment>horizontal alignment</comment>
        <translation type="obsolete">a sinistra</translation>
    </message>
    <message>
        <source>Centered</source>
        <comment>horizontal alignment</comment>
        <translation type="obsolete">centrato</translation>
    </message>
    <message>
        <source>Right</source>
        <comment>horizontal alignment</comment>
        <translation type="obsolete">a destra</translation>
    </message>
    <message>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">in basso</translation>
    </message>
    <message>
        <source>Middle</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">medio</translation>
    </message>
    <message>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">in alto</translation>
    </message>
    <message>
        <source>Outline</source>
        <comment>border style</comment>
        <translation type="obsolete">Contorno</translation>
    </message>
    <message>
        <source>Opaque box</source>
        <comment>border style</comment>
        <translation type="obsolete">Riquadro opaco</translation>
    </message>
    <message>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the width of the outline around the text in pixels.</source>
        <translation type="obsolete">Se lo stile bordo è impostato su &lt;i&gt;contorno&lt;/i&gt;, questa opzione specifica lo spessore in pixel del contorno.</translation>
    </message>
    <message>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the depth of the drop shadow behind the text in pixels.</source>
        <translation type="obsolete">Se lo stile bordo è impostato su &lt;i&gt;contorno&lt;/i&gt;, questa opzione specifica la profondità in pixel dell&apos;ombra dietro il testo.</translation>
    </message>
    <message>
        <source>Enable normal subtitles</source>
        <translation type="obsolete">Abilita sottotitoli normali</translation>
    </message>
    <message>
        <source>Click this button to select the normal/traditional subtitles. This kind of subtitles can only display white subtitles.</source>
        <translation type="obsolete">Clicca il bottone per scegliere i sottotitoli normali/tradizionali. Questo tipo di sottotitoli viene mostrato solo con il colore bianco.</translation>
    </message>
    <message>
        <source>Enable SSA/ASS subtitles</source>
        <translation type="obsolete">Abilita sottotitoli SSA/ASS</translation>
    </message>
    <message>
        <source>Normal subtitles</source>
        <translation type="obsolete">Normali sottotitoli</translation>
    </message>
    <message>
        <source>This option does NOT change the size of the subtitles in the current video. To do so, use the options &lt;i&gt;Size+&lt;/i&gt; and &lt;i&gt;Size-&lt;/i&gt; in the subtitles menu.</source>
        <translation type="obsolete">Questa opzione NON cambia la dimensione dei sottotitoli nel video corrente, per farlo, usa l&apos;opzione &lt;i&gt;Grandezza+&lt;/i&gt; e &lt;i&gt;Grandezza-&lt;/i&gt; del menù sottotitoli.</translation>
    </message>
    <message>
        <source>Default scale</source>
        <translation type="obsolete">Dimensione predefinita</translation>
    </message>
    <message>
        <source>This option specifies the default font scale for normal subtitles which will be used for new opened files.</source>
        <translation type="obsolete">Questa opzione specifica la dimensione di carattere predefinita per i sottotitoli normali e verrà usata per i nuovi file aperti.</translation>
    </message>
    <message>
        <source>SSA/ASS subtitles</source>
        <translation type="obsolete">Sottotitoli SSA/ASS</translation>
    </message>
    <message>
        <source>This option specifies the default font scale for SSA/ASS subtitles which will be used for new opened files.</source>
        <translation type="obsolete">Questa opzione specifica la dimensione di carattere predefinita per i sottotitoli SSA/ASS e verrà usata per i nuovi file aperti.</translation>
    </message>
    <message>
        <source>Line spacing</source>
        <translation type="obsolete">Interlinea</translation>
    </message>
    <message>
        <source>This specifies the spacing that will be used to separate multiple lines. It can have negative values.</source>
        <translation type="obsolete">Imposta la spaziatura di interlinea. Può assumere anche valori negativi.</translation>
    </message>
    <message>
        <source>&amp;Font and colors</source>
        <translation type="obsolete">Ca&amp;ratteri e colori</translation>
    </message>
    <message>
        <source>Enable &amp;normal subtitles</source>
        <translation type="obsolete">Abilita &amp;normali sottotitoli</translation>
    </message>
    <message>
        <source>Enable SSA/&amp;ASS subtitles</source>
        <translation type="obsolete">&amp;Abilita sottotitoli SSA/ASS</translation>
    </message>
    <message>
        <source>Default s&amp;cale:</source>
        <translation type="obsolete">&amp;Dimensione predefinita:</translation>
    </message>
    <message>
        <source>Defa&amp;ult scale:</source>
        <translation type="obsolete">&amp;Dimensione predefinita:</translation>
    </message>
    <message>
        <source>&amp;Line spacing:</source>
        <translation type="obsolete">Inter&amp;linea:</translation>
    </message>
    <message>
        <source>Click this button to enable the new SSA/ASS library. This allows to display subtitles with multiple colors, fonts...</source>
        <translation type="obsolete">Premi il pulsante per abilitare la nuova libreria SSA/ASS. Permette di mostrare sottotitoli tramite l&apos;utilizzo di più colori, tipi di carattere...</translation>
    </message>
    <message>
        <source>Freetype support</source>
        <translation type="obsolete">Supporto Freetype</translation>
    </message>
    <message>
        <source>You should normally not disable this option. Do it only if your MPlayer is compiled without freetype support. &lt;b&gt;Disabling this option could make that subtitles won&apos;t work at all!&lt;/b&gt;</source>
        <translation type="obsolete">Normalmente non dovresti disabilitare questa opzione, a meno che la tua versione di MPlayer sia priva del supporto freetype. &lt;b&gt;Disabilitando questa opzione potresti rendere i sottotitoli totalmente non funzionanti!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Freet&amp;ype support</source>
        <translation type="obsolete">Supporto Freet&amp;ype</translation>
    </message>
    <message>
        <source>If this option is checked, the subtitles will appear in the screenshots. &lt;b&gt;Note:&lt;/b&gt; it may cause some troubles sometimes.</source>
        <translation type="obsolete">Con questa opzione abilitata, i sottotitoli appariranno nelle schermate. &lt;b&gt;Nota:&lt;/b&gt; può causare dei problemi a volte.</translation>
    </message>
    <message>
        <source>Customize SSA/ASS style</source>
        <translation type="obsolete">Personalizza sottotitoli SSA/ASS</translation>
    </message>
    <message>
        <source>Here you can enter your customized SSA/ASS style.</source>
        <translation type="obsolete">Inserisci qui il tuo stile SSA/ASS personalizzato.</translation>
    </message>
    <message>
        <source>Clear the edit line to disable the customized style.</source>
        <translation type="obsolete">Cancellane il contenuto per disabilitare lo stile personalizzato.</translation>
    </message>
    <message>
        <source>SSA/ASS style</source>
        <translation type="obsolete">Stile SSA/ASS</translation>
    </message>
    <message>
        <source>Shadow color</source>
        <translation type="obsolete">Colore ombra</translation>
    </message>
    <message>
        <source>This color will be used for the shadow of the subtitles.</source>
        <translation type="obsolete">Questo colore verrà usato per l&apos;ombra dei sottotitoli.</translation>
    </message>
    <message>
        <source>Shadow:</source>
        <translation type="obsolete">Ombra:</translation>
    </message>
    <message>
        <source>Custo&amp;mize...</source>
        <translation type="obsolete">Perso&amp;nalizza...</translation>
    </message>
    <message>
        <source>Apply style to ass files too</source>
        <translation type="obsolete">Applica lo stile anche ai file ass</translation>
    </message>
    <message>
        <source>If this option is checked, the style defined above will be applied to ass subtitles too.</source>
        <translation type="obsolete">Se l&apos;opzione è attiva, lo stile definito qua sopra verrà applicato anche ai sottotitoli ass.</translation>
    </message>
    <message>
        <source>A&amp;pply style to ass files too</source>
        <translation type="obsolete">A&amp;pplica lo stile anche ai file ass</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <source>TV and radio</source>
        <translation type="obsolete">TV e radio</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nessuno</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">LowPass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normale)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (doppio frame rate)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Linear Blend</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Kerndeint</translation>
    </message>
    <message>
        <source>Deinterlace by default for TV</source>
        <translation type="obsolete">Deinterlacciamento predefinito per la TV</translation>
    </message>
    <message>
        <source>Select the deinterlace filter that you want to be used for TV channels.</source>
        <translation type="obsolete">Seleziona il filtro di deinterlacciamento per i canali TV.</translation>
    </message>
    <message>
        <source>Rescan ~/.mplayer/channels.conf on startup</source>
        <translation type="obsolete">Rianalizza ~/.mplayer/channels.conf all&apos;avvio</translation>
    </message>
    <message>
        <source>&amp;TV and radio</source>
        <translation type="obsolete">&amp;TV e radio</translation>
    </message>
    <message>
        <source>Dei&amp;nterlace by default for TV:</source>
        <translation type="obsolete">Dei&amp;nterlacciamento predefinito per la TV:</translation>
    </message>
    <message>
        <source>&amp;Check for new channels on startup</source>
        <translation type="obsolete">&amp;Controlla se ci sono nuovi canali all&apos;avvio</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="97"/>
        <location filename="../preferencesdialog.cpp" line="172"/>
        <source>ROSA Media Player - Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="176"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="177"/>
        <source>Close</source>
        <translation type="unfinished">Chiudi</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Annulla</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="178"/>
        <source>Apply</source>
        <translation>Applica</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="179"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>mostrerà questo messaggio e uscirà.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>la finestra principale sarà chiusa alla fine della riproduzione del file/lista di riproduzione.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>prova a stabilire una connessione ad un altra istanza e a mandare il comando specificato. Esempio: -send-action pause Tutto il resto (se presente) verrà ignorato e l&apos;applicazione terminerà. Ritorna 0 in caso di successo o -1 in caso di fallimento.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>lista_di_azioni è una lista di opzioni separate da spazi. Le azioni saranno eseguite subito dopo il caricamento di un file (se richiesto), nello stesso ordine di immissione. Per le azioni a scelta si possono passare true o false come parametri. Esempio:  -actions &quot;fullscreen compact true&quot;. Le doppie virgolette sono necessarie in caso si passi più di una azione.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>Se è presente un altra istanza, il file sarà aggiunto alla lista di riproduzione di quella istanza, altrimenti questa opzione verrà ignorata e il file verrà aperto in una nuova istanza.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>la finestra principale non verrà chiusa alla fine della riproduzione.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>il video verrà riprodotto a schermo intero.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>il video verrà riprodotto nella finestra.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Ristabilisce la vecchie associazioni e ripulisce il registro.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Uso:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>cartella</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>nome_dell_azione</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>lista_di_azioni</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>apre l&apos;interfaccia predefinita.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>file_di_sottotitoli</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>specifica il file dei sottotitoli da caricare per il primo video.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation>
            <numerusform>%1 secondo</numerusform>
            <numerusform>%1 secondi</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation>
            <numerusform>%1 minuto</numerusform>
            <numerusform>%1 minuti</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 e %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>disabilitato</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>automatico</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>sconosciuto</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation>larghezza</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation>altezza</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>specifica le coordinate di posizione della finestra principale.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation>specifica la dimensione della finestra principale.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="444"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>Errore ZIP/UNZIP %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="94"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="97"/>
        <source>Unknown error in recording occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="100"/>
        <source>Sorry, recording crashed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="49"/>
        <source>/Screencast - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Information</source>
        <translation type="unfinished">Informazioni</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="86"/>
        <source>Length: %1
Size: %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>icona</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>etichetta</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Modifica scorciatoia</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Pulisci</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Esegui la combinazione che vuoi assegnare</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Cattura</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Cattura combinazione di tasti</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation type="unfinished">Informazioni</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished">Annulla</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Selezione sottotitoli</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Questo archivio contiene più di un file per i sottotitoli. Selezionarne uno per l&apos;estrazione.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Seleziona tutti</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Nessuna selezione</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="97"/>
        <source>Channel editor</source>
        <translation>Editor di canale</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="98"/>
        <source>TV/Radio list</source>
        <translation>Lista TV/radio</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Salta a:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Automatico</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Sì</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="74"/>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Contrast</source>
        <translation>Contrasto</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Brightness</source>
        <translation>Luminosità</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Hue</source>
        <translation>Tonalità</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Saturation</source>
        <translation>Saturazione</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Salva come valori predefiniti</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Usa i valori correnti come valori predefiniti per i nuovi video.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Metti a zero tutti i controlli.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="71"/>
        <source>Video Equalizer</source>
        <translation>Equalizzatore Video</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="122"/>
        <source>Information</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="123"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>I valori correnti sono stati salvati come predefiniti.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation>Anteprima video</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Annulla</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation>Creazione miniature...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation>Dimensione: %1 MB</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation>Durata: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation>Salva file</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation>Errore durante il salvataggio del file</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Non è stato possibile salvare il file</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation>Errore</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>L&apos;errore seguente si è verificato durante la creazione delle miniature:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>La directory temporanea (%1) non può essere creata</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>Nessun processo mplayer</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation>Risoluzione: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation>Formato video: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation>Fotogrammi al secondo: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation>Rapporto d&apos;aspetto: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>Il file %1 non può essere caricato</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation>Nessun nome file</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Il processo mplayer non è partito mentre si cercavano informazioni sul video</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation>La durata del video è 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>Il file %1 non esiste</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation>Immagini</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation>Nessuna informazione</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation>Bitrate video: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation>Bitrate audio: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation>Bitrate audio: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation>Predefinito</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation>Anteprima video</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation>&amp;File:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation>&amp;Colonne:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation>&amp;Righe:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation>Rapporto d&apos;&amp;aspetto:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation>&amp;Secondi da saltare all&apos;inizio:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation>&amp;Larghezza massima:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>L&apos;anteprima sarà creata per il video qui specificato.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Le miniature saranno disposte su una tabella.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Questa opzione specifica il numero di colonne della tabella.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Questa opzione specifica il numero di righe della tabella.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Se si abilita questa opzione, il tempo di riproduzione sarà mostrato sul fondo di ogni miniatura.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Se il rapporto d&apos;aspetto del video è errato, se ne può specificare un altro qui.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>In genere i primi fotogrammi sono neri, così è una buona idea saltare alcuni secondi all&apos;inizio del video. L&apos;opzione permette di specificare quanti secondi verranno saltati.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Questa opzione specifica la massima larghezza in pixel che l&apos;immagine d&apos;anteprima generata avrà.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Alcuni fotogrammi saranno estratti dal video per creare l&apos;anteprima. Il formato immagine per i fotogrammi estratti può essere scelto qui. PNG può fornire miglior qualità.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Aggiungi &amp;tempo di riproduzione nelle miniature</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation>&amp;Estrai fotogrammi come</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Inserire qui il dispositivo DVD o una cartella con l&apos;immagine del DVD.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation>&amp;Dispositivo DVD:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Ricorda la cartella usata per &amp;salvare l&apos;anteprima</translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
</context>
</TS>
