<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>The following people have contributed with translations:</source>
        <translation>Çevirileriyle katkıda bulunanlar:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="174"/>
        <source>German</source>
        <translation>Almanca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="175"/>
        <source>Slovak</source>
        <translation>Slovakça</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Italian</source>
        <translation>İtalyanca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>French</source>
        <translation>Fransızca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="249"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 ve %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="183"/>
        <source>Simplified-Chinese</source>
        <translation>Basitleştirilmiş Çince</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Russian</source>
        <translation>Rusça</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="246"/>
        <source>%1 and %2</source>
        <translation>%1 ve %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="185"/>
        <source>Hungarian</source>
        <translation>Macarca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="93"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="99"/>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Polish</source>
        <translation>Lehçe</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="191"/>
        <source>Japanese</source>
        <translation>Japonca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Dutch</source>
        <translation>Felemenkçe</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Ukrainian</source>
        <translation>Ukraynaca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="199"/>
        <source>Portuguese - Brazil</source>
        <translation>Brezilya Portegizcesi</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="200"/>
        <source>Georgian</source>
        <translation>Gürcüce</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Czech</source>
        <translation>Çekçe</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Bulgarian</source>
        <translation>Bulgarca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Turkish</source>
        <translation>Türkçe</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Swedish</source>
        <translation>İsveççe</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Serbian</source>
        <translation>Sırpça</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Traditional Chinese</source>
        <translation>Geleneksel Çince</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Romanian</source>
        <translation>Romence</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Portuguese - Portugal</source>
        <translation>Portekiz Portegizcesi</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Greek</source>
        <translation>Yunanca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="214"/>
        <source>Finnish</source>
        <translation>Fince</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="267"/>
        <location filename="../about.cpp" line="279"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="303"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>About ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="84"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="215"/>
        <source>Korean</source>
        <translation>Korece</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="216"/>
        <source>Macedonian</source>
        <translation>Makedonca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="217"/>
        <source>Basque</source>
        <translation>Baskça</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>Using MPlayer %1</source>
        <translation>Mplayer&apos;ı kullanıyor %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="100"/>
        <source>terms of use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="122"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="218"/>
        <source>Catalan</source>
        <translation>Katalanca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="219"/>
        <source>Slovenian</source>
        <translation>Slovence</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="220"/>
        <source>Arabic</source>
        <translation>Arapça</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="221"/>
        <source>Kurdish</source>
        <translation>Kürtçe</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="222"/>
        <source>Galician</source>
        <translation>Galiçyaca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="252"/>
        <source>%1, %2, %3 and %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="223"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="224"/>
        <source>Estonian</source>
        <translation type="unfinished">Estonca</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="225"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Litvanyaca</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Description</source>
        <translation>Tanım</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Shortcut</source>
        <translation>Kısayol</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="219"/>
        <source>&amp;Save</source>
        <translation>&amp;Kaydet</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="222"/>
        <source>&amp;Load</source>
        <translation>&amp;Yükle</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="470"/>
        <location filename="../actionseditor.cpp" line="529"/>
        <source>Key files</source>
        <translation>Anahtar dosyaları</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="468"/>
        <source>Choose a filename</source>
        <translation>Bir dosya ismi seçin</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="482"/>
        <source>Confirm overwrite?</source>
        <translation>Üstüne yazmayı onaylıyor musunuz?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="483"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1 dosyası zaten var. 
Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="497"/>
        <location filename="../actionseditor.cpp" line="537"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="498"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Dosya kaydedilemedi</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="528"/>
        <source>Choose a file</source>
        <translation>Bir dosya seçin</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="538"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Dosya yüklenemedi</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="226"/>
        <source>&amp;Change shortcut...</source>
        <translation>Kısa&amp;yolu değiştirin...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="74"/>
        <source>Audio Equalizer</source>
        <translation>Ses Dengeleyici</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="77"/>
        <source>31.25 Hz</source>
        <translation>31.25 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>62.50 Hz</source>
        <translation>62.50 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="79"/>
        <source>125.0 Hz</source>
        <translation>125.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="80"/>
        <source>250.0 Hz</source>
        <translation>250.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>500.0 Hz</source>
        <translation>500.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>1.000 kHz</source>
        <translation>1.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>2.000 kHz</source>
        <translation>2.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>4.000 kHz</source>
        <translation>4.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>8.000 kHz</source>
        <translation>8.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>16.00 kHz</source>
        <translation>16.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>&amp;Apply</source>
        <translation>&amp;Uygula</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırla</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Varsayılan yap</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Bu değerleri tüm yeni videolar için kullan.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="96"/>
        <source>Set all controls to zero.</source>
        <translation>Tüm kontrolleri sıfırla.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="117"/>
        <source>Information</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="118"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Hali hazırdaki değerler varsayılan değerler olarak kaydedildi.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1413"/>
        <source>&amp;File...</source>
        <translation>Dosy&amp;a...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1414"/>
        <source>D&amp;irectory...</source>
        <translation>&amp;Klasör...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1415"/>
        <source>&amp;Playlist...</source>
        <translation>Oynatma &amp;Listesi...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1416"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1418"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1419"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD&apos;yi klasörden aç...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1420"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>C&amp;lose</source>
        <translation>&amp;Kapat</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1435"/>
        <source>P&amp;lay</source>
        <translation>&amp;Oynat</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1442"/>
        <source>&amp;Pause</source>
        <translation>Du&amp;raklat</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>&amp;Stop</source>
        <translation>&amp;Durdur</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1444"/>
        <source>&amp;Frame step</source>
        <translation>&amp;Bir kare ilerle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1446"/>
        <source>Play / Pause</source>
        <translation>Oynat / Duraklat</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1458"/>
        <source>Pause / Frame step</source>
        <translation>Duraklat / Bir kare ilerle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1461"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normal Hızda</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1462"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Yarı Hızda</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Double speed</source>
        <translation>İki ka&amp;t hızlı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>Speed &amp;-10%</source>
        <translation>%10 Yava&amp;şlat</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>Speed &amp;+10%</source>
        <translation>%10 Hı&amp;zlandır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1527"/>
        <source>P&amp;references...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1609"/>
        <source>Sp&amp;eed</source>
        <translation>&amp;Hız</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1472"/>
        <source>&amp;Fullscreen</source>
        <translation>Tam &amp;ekran</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1473"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Eşitleyici</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Screenshot</source>
        <translation>Ekran görüntü&amp;sü</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1484"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Ardişlem</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1485"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Aşamayı otomatik olarak bul</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Döngü</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>Add n&amp;oise</source>
        <translation>N&amp;oise ekle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1631"/>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltreler</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1496"/>
        <source>&amp;Mute</source>
        <translation>&amp;Sessiz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Play list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1497"/>
        <source>Volume &amp;-</source>
        <translation>Ses &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1498"/>
        <source>Volume &amp;+</source>
        <translation>Ses &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1499"/>
        <source>&amp;Delay -</source>
        <translation>İler&amp;i al -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1500"/>
        <source>D&amp;elay +</source>
        <translation>&amp;Geri al +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1688"/>
        <source>&amp;Filters</source>
        <translation>&amp;Süzgeçler</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Load...</source>
        <translation>&amp;Yükle...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>Show / Hide right panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <location filename="../basegui.cpp" line="1512"/>
        <source>U&amp;nload</source>
        <translation>&amp;Kaldır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Oynatma listesi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>View &amp;info and properties...</source>
        <translation>&amp;Bilgi ve özelliklere bak...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1530"/>
        <source>Help &amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>&amp;Open</source>
        <translation>&amp;Aç</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>&amp;Video</source>
        <translation>V&amp;ideo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>&amp;Audio</source>
        <translation>&amp;Ses</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>&amp;Subtitles</source>
        <translation>Alt &amp;yazı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1590"/>
        <source>&amp;Browse</source>
        <translation>&amp;Gezin</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Op&amp;tions</source>
        <translation>S&amp;eçenekler</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>&amp;Help</source>
        <translation>&amp;Yardım</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1595"/>
        <source>&amp;Recent files</source>
        <translation>&amp;Son açılanlar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Clear</source>
        <translation>&amp;Temizle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1618"/>
        <source>Si&amp;ze</source>
        <translation>&amp;Boyut</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1627"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Görüntü ayrıştırma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1662"/>
        <location filename="../basegui.cpp" line="2868"/>
        <source>&amp;None</source>
        <translation>&amp;Hiçbiri</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1663"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1666"/>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1692"/>
        <source>&amp;Channels</source>
        <translation>&amp;Kanallar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1697"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Steryo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1699"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Select</source>
        <translation>&amp;Seç</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Title</source>
        <translation>&amp;Başlık</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1711"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Bölüm</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1715"/>
        <source>&amp;Angle</source>
        <translation>&amp;Açı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2213"/>
        <source>Capture desktop...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4834"/>
        <source>Video capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4835"/>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4836"/>
        <source>Start capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4837"/>
        <source>Cancel</source>
        <translation type="unfinished">İptal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Devredışı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2884"/>
        <location filename="../basegui.cpp" line="2904"/>
        <location filename="../basegui.cpp" line="2924"/>
        <location filename="../basegui.cpp" line="2943"/>
        <location filename="../basegui.cpp" line="2972"/>
        <location filename="../basegui.cpp" line="3004"/>
        <location filename="../basegui.cpp" line="3031"/>
        <location filename="../basegui.cpp" line="3074"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;boş&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3444"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3445"/>
        <location filename="../basegui.cpp" line="3674"/>
        <source>Audio</source>
        <translation>Ses</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3446"/>
        <source>Playlists</source>
        <translation>Oynatma listesi</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3447"/>
        <location filename="../basegui.cpp" line="3652"/>
        <location filename="../basegui.cpp" line="3675"/>
        <source>All files</source>
        <translation>Tüm dosyalar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3442"/>
        <location filename="../basegui.cpp" line="3649"/>
        <location filename="../basegui.cpp" line="3672"/>
        <source>Choose a file</source>
        <translation>Bir dosya seçin</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3507"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD cihazları henüz yapılandırılmadı.
Tamama bastığınızda ayarları yapabileceğiniz ekran açılacak.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3607"/>
        <source>Choose a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3651"/>
        <source>Subtitles</source>
        <translation>Alt yazılar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4244"/>
        <source>Playing %1</source>
        <translation>%1&apos;i oynatıyor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4247"/>
        <source>Pause</source>
        <translation>Duraklat</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4250"/>
        <source>Stop</source>
        <translation>Durdur</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1552"/>
        <source>Dec volume (2)</source>
        <translation>Sesi kıs (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1553"/>
        <source>Inc volume (2)</source>
        <translation>Sesi yükselt (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1556"/>
        <source>Exit fullscreen</source>
        <translation>Tam ekrandan çık</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1558"/>
        <source>OSD - Next level</source>
        <translation>OSD - Sonraki seviye</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1559"/>
        <source>Dec contrast</source>
        <translation>Zıtlığı azalt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1560"/>
        <source>Inc contrast</source>
        <translation>Zıtlığı arttır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1561"/>
        <source>Dec brightness</source>
        <translation>Parlaklığı azalt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Inc brightness</source>
        <translation>Barlaklığı arttır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Dec hue</source>
        <translation>Renk tonunu azalt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1564"/>
        <source>Inc hue</source>
        <translation>Renk tonunu arttır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1565"/>
        <source>Dec saturation</source>
        <translation>Doygunluğu azalt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1567"/>
        <source>Dec gamma</source>
        <translation>Gamayı azalt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Next audio</source>
        <translation>Bir sonraki ses</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Next subtitle</source>
        <translation>Bir sonraki alt yazı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Next chapter</source>
        <translation>Bir sonraki bölüm</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Previous chapter</source>
        <translation>Bir önceki bölüm</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Inc saturation</source>
        <translation>Doygunluğu arttır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>Inc gamma</source>
        <translation>Gamayı arttır</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>&amp;Load external file...</source>
        <translation>Harici dosya yük&amp;le...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1667"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1664"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1665"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>&amp;Yadif (kare sayısını ikiye katla)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1534"/>
        <source>&amp;Next</source>
        <translation>&amp;Sonraki</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>Pre&amp;vious</source>
        <translation>&amp;Önceki</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <source>Volume &amp;normalization</source>
        <translation>Ses &amp;normalleştirme</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1417"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Müzik CD&apos;si</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Nor&amp;mal denoise</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1671"/>
        <source>Denoise &amp;soft</source>
        <translation>Hafif denoi&amp;se</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1669"/>
        <source>Denoise o&amp;ff</source>
        <translation>Denois&amp;e kapalı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1515"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>SSA/&amp;ASS kütüphanesini kullan</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>&amp;Toggle double size</source>
        <translation>İ&amp;ki katı büyüt</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>S&amp;ize -</source>
        <translation>&amp;Boyut -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1514"/>
        <source>Si&amp;ze +</source>
        <translation>B&amp;oyut +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>Add &amp;black borders</source>
        <translation>&amp;Çerçeve ekle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="259"/>
        <source>Trim video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="260"/>
        <source>Extract audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Ya&amp;zılım derecelendirme</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>Enable &amp;closed caption</source>
        <translation>&amp;Closed caption&apos;ı etkinleştir</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1517"/>
        <source>&amp;Forced subtitles only</source>
        <translation>Sadece zorunlu alt yaz&amp;ılar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Reset video equalizer</source>
        <translation>Video eşitleyiciyi sıfırla</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4660"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>MPlayer beklenmeyen bir şekilde kapandı.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4661"/>
        <source>Exit code: %1</source>
        <translation>Çıkış kodu: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4682"/>
        <source>MPlayer failed to start.</source>
        <translation>MPlayer başlatılamadı.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4683"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Lütfen seçeneklerden MPlayer&apos;ın konumunu kontrol edin.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4687"/>
        <source>MPlayer has crashed.</source>
        <translation>MPlayer çöktü.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4688"/>
        <source>See the log for more info.</source>
        <translation>Daha fazla bilgi için kayıt dosyasına bakınız.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1635"/>
        <source>&amp;Rotate</source>
        <translation>Döndü&amp;r</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Off</source>
        <translation>&amp;Kapalı</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>Saat yönünde 90 derece döndür ve ters çevi&amp;r</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>Saat yönünde 90 dere&amp;ce döndür</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>Saat yönünün tersinde 90 derece d&amp;öndür</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>Saat yönünün tersinde 90 derece &amp;döndür ve ters çevir</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Show context menu</source>
        <translation>İçerik menüsünü göster</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3443"/>
        <source>Multimedia</source>
        <translation>Çoklu ortam</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1493"/>
        <source>E&amp;qualizer</source>
        <translation>Den&amp;geleyici</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Reset audio equalizer</source>
        <translation>Ses dengeleyiciyi sıfırla</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>&amp;OpenSubtitles.org&apos;dan alt yazı bul...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1522"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>&amp;OpenSubtitles.org&apos;a alt yazı yükle...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>&amp;Auto</source>
        <translation>Otom&amp;atik</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed -&amp;4%</source>
        <translation>Hız -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>&amp;Speed +4%</source>
        <translation>Hı&amp;z +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;1%</source>
        <translation>Hız -&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>S&amp;peed +1%</source>
        <translation>&amp;Hız +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1640"/>
        <source>Scree&amp;n</source>
        <translation>Ekra&amp;n</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>&amp;Default</source>
        <translation>Varsa&amp;yılan</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Next video</source>
        <translation>Bir sonraki video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;İz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;İz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3506"/>
        <source>ROSA Media Player - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3728"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4033"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Uyarı - MPlayer&apos;ın eski bir sürümünü kullanıyorsunuz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4039"/>
        <source>Please, update your MPlayer.</source>
        <translation>Lütfen MPlayer&apos;ı güncelleyiniz.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4041"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Bu uyarı bir daha gösterilmeyecektir)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Next aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>Pre&amp;view...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1731"/>
        <source>DVD &amp;menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>DVD &amp;previous menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>DVD menu, move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>DVD menu, move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1729"/>
        <source>DVD menu, move left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1730"/>
        <source>DVD menu, move right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1732"/>
        <source>DVD menu, select option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1734"/>
        <source>DVD menu, mouse click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>Set dela&amp;y...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3729"/>
        <source>Audio delay (in milliseconds):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4034"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4253"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4395"/>
        <source>Jump to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Subtitle &amp;visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next wheel function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>Next TV channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>Previous TV channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1430"/>
        <source>Next radio channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1431"/>
        <source>Previous radio channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1531"/>
        <source>About &amp;ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;TV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1604"/>
        <source>Radi&amp;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <location filename="../basegui.cpp" line="1427"/>
        <source>&amp;Jump...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1366"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>Fli&amp;p image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Show filename on OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Toggle deinterlacing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Gizle</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>Ge&amp;ri yükle</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>&amp;Çıkış</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Oynatma listesi</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation type="unfinished">00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="76"/>
        <source>Volume</source>
        <translation type="unfinished">Ses</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3078"/>
        <source>Brightness: %1</source>
        <translation>Parlaklık: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3095"/>
        <source>Contrast: %1</source>
        <translation>Zıtlık: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3111"/>
        <source>Gamma: %1</source>
        <translation>Gama: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3127"/>
        <source>Hue: %1</source>
        <translation>Renk tonu: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3143"/>
        <source>Saturation: %1</source>
        <translation>Doygunluk: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3295"/>
        <source>Volume: %1</source>
        <translation>Ses: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4261"/>
        <source>Zoom: %1</source>
        <translation>Yakınlık: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3433"/>
        <location filename="../core.cpp" line="3451"/>
        <source>Font scale: %1</source>
        <translation>Font ölçeği: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4115"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4531"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3344"/>
        <source>Subtitle delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3364"/>
        <source>Audio delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3208"/>
        <source>Speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3505"/>
        <source>Subtitles on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3507"/>
        <source>Subtitles off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4166"/>
        <source>Mouse wheel seeks now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4169"/>
        <source>Mouse wheel changes volume now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4172"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4175"/>
        <source>Mouse wheel changes speed now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1149"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1165"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2798"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2817"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2835"/>
        <source>A-B markers cleared</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation type="unfinished">Bilgi</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation type="unfinished">Tamam</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation type="unfinished">İptal</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="362"/>
        <source>Welcome to ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="414"/>
        <source>A:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="419"/>
        <source>B:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="389"/>
        <source>&amp;Video info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="390"/>
        <source>&amp;Frame counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="429"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>Simge</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Kaydı sakla</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Kaydı göster</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>MPlayer hatası</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>simge</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation type="unfinished">İsim</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation type="unfinished">Y&amp;ukarı</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation type="unfinished">A&amp;şağı</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>İndiriyor...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>%1&apos;i indiriyor</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="137"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>Cancel</source>
        <translation>İptal</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Apply</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Bilgi</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>Bu do&amp;sya için kullanılacak demuxer&apos;ı seçin:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırla</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Video kodlayıcısı</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>Video kodlayıcısını &amp;seçin:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>&amp;Ses kodlayıcısı</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Ses kodlayıcısını seçin:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer seçenekleri</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Mplayer için Ek Özellikler</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Burada mplayer&apos;a fazladan özellikler ekleyebilirsiniz.
Özellikler arasında boşluk bırakmayı unutmayın.
Örnek: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Seçenekler:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>İlave video süzgeçleri de ekleyebilirsiniz.
Süzgeçleri &quot;,&quot; ile ayırın. Boşluk kullanmayın!
Örnek: scale=512:-2,eq2=1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo süzgeçleri:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Ve son olarak ses süzgeçleri. Video süzgeçlerinde geçerli olan kurallar burada da geçerli.
Örnek: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Ses &amp;süzgeçleri:</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Dil</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Biçim</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Dosyalar</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Yükleyen</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Hepsi</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>İn&amp;dir</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>Bağlantıyı panoya &amp;kopyala</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Hata</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>İndirme başarısız: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>%1&apos;e bağlanıyor...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>İndiriyor...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Bitti.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 dosya kaldı</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Alınan bilgi ayrıştırılamadı.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Alt yazı Bul</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Bunun için bul</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>Di&amp;l:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>Yen&amp;ile</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Alt yazı %1 olarak kaydedildi</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation type="unfinished">
            <numerusform>%1 alt yazı genişletildi
        </numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>%1 zaten var, üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Dosyayı kaydederken hata oluştu</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>%1 klasörüne 
indirilen dosya kaydedilemedi
Lütfen bu klasöre yazma izniniz olup olmadığını kontrol edin.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Süre</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Oyuncu</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Yazar</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Albüm</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Tür</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Tarih</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Parça</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Telif Hakkı</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Yorum</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Yazılım</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Parça hakkında bilgi</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Çözünürlük</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>En/Boy Oranı</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Biçim</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>Saniyede %1 kb</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Kare/saniye </translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Seçilen kodlayıcı</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>İlk Ses Akışı</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Oran</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Kanallar</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Ses Akımları</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Dil</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>boş</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Alt yazılar</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Tür</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Yayının başlığı</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Yayının URL&apos;si</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>Dosya</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Sabit diskinizde bulunan bir DVD&apos;yi oynatabilirsiniz. VIDEO_TS ve AUDIO_TS klasörlerini içeren klasörü seçmeniz yeterli.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Bir klasör seçin...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>MPlayer tarafından bildirilen sürüm:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Lütfen doğru &amp;sürümü seçiniz:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 veya daha eski</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;URL:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>Bu bir oyna&amp;tma listesi</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="33"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Bu seçeneği işaretlerseniz, URL bir oynatma listesi olarak kabul edilecek: metin olarak açılacak ve içindeki URL&apos;leri oynatmak için kullanılacak.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Abhazca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Afrikaanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Habeşçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Arapça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Assamca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Aymaraca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Azerice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Başkırca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Bulgarca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Biharca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Bengalce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Tibetçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Bretonca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Katalanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Korsikaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Çekçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Galce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Danca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>Almanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Yunanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>İngilizce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>İspanyolca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Estonca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Baskça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Farsça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Fince</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Faroece</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>Fransızca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Frizce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>İrlandaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Galiçyaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Guaranice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Gujaratice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>İbranice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Hintçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Hırvatça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Macarca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Ermenice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Endonezce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>İzlandaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>İtalyanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Japonca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Cavaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Gürcüce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Kazakça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Grönlandca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Korece</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Kaşmirce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Kürtçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Kırgızca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Latince</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Litvanyaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Letonca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Malagasy</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Maorice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Makedonca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Moğolca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Moldovaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Malay</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Maltaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Birmanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Nepalce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Felemenkçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Norveççe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Occitan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Lehçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Portegizce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Romence</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Rusça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Sanskritçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Sintçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Slovakça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Slovence</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Samoaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Somalice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Arnavutça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Sırpça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Sundanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>İsveççe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Savahilice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Tamilce</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Tacikçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Tayca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Tigrinya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Türkmence</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Tongaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Türkçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Tatarca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Uygurca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Ukraynaca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Urduca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Özbekçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Vietnamca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Yiddiş</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Yoruba</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Çince</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Zuluca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Brezilya Portegizcesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Portekiz Portegizcesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Basitleştirilmiş Çince</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Geleneksel Çince</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Batı Avrupa Dilleri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Batı Avrupa Dilleri (€ içeren)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Slav/Orta Avrupa Dilleri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galiçyaca, Maltaca, Türkçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Eski Baltık Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Kiril Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Çağdaş Yunanca</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Baltık Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Keltçe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>İbranice</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukraynaca, Beyaz Rusça</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Basitleştirilmiş Çin Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Geleneksel Çin Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Japon Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Kore Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Tay Alfabesi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Kiril Alfabesi Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Slav/Orta Avrupa Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Arapça Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Kayıt dosyası için bir isim seçin</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Üstüne yazmayı onaylıyor musunuz?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Dosya zaten var.
Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Dosyayı kaydederken hata oluştu</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Kayıt bilgisi kaydedilemedi</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Kayıtlar</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Kayıt Penceresi</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Kaydet</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Panoya kopyala</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Kapat</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Name</source>
        <translation>İsim</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Length</source>
        <translation>Süre</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Play</source>
        <translation>&amp;Oynat</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>&amp;Edit</source>
        <translation>&amp;Düzelt</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="817"/>
        <location filename="../playlist.cpp" line="837"/>
        <source>Playlists</source>
        <translation>Oynatma Listeleri</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="815"/>
        <source>Choose a file</source>
        <translation>Bir dosya seçin</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="393"/>
        <source>ROSA Media Player - Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="835"/>
        <source>Choose a filename</source>
        <translation>Bir dosya ismi seçin</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="849"/>
        <source>Confirm overwrite?</source>
        <translation>Üstüne yazmayı onaylıyor musunuz?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="850"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>%1 dosyası zaten var. 
Üstüne yazmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1077"/>
        <source>Multimedia</source>
        <translation type="unfinished">Çoklu ortam</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>All files</source>
        <translation>Tüm dosyalar</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1075"/>
        <source>Select one or more files to open</source>
        <translation>Açmak üzere bir veya daha fazla dosya seçin</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1139"/>
        <source>Choose a directory</source>
        <translation>Bir klasör seçin</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1364"/>
        <source>Edit name</source>
        <translation>İsmi değiştirin</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1365"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Bu dosyanın oynatma listesinde gösterileceği ismi yazın:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>&amp;Load</source>
        <translation>&amp;Yükle</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="345"/>
        <source>&amp;Save</source>
        <translation>&amp;Kaydet</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Next</source>
        <translation>&amp;Sonraki</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="350"/>
        <source>Pre&amp;vious</source>
        <translation>&amp;Önceki</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="365"/>
        <source>Move &amp;up</source>
        <translation>&amp;Yukarı taşı</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="366"/>
        <source>Move &amp;down</source>
        <translation>&amp;Aşağı taşı</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Tekrarla</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>S&amp;huffle</source>
        <translation>&amp;Karışık</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Add &amp;current file</source>
        <translation>&amp;Hâlihazır dosyayı ekle</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="375"/>
        <source>Add &amp;file(s)</source>
        <translation>&amp;Dosya(ları) ekle</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="376"/>
        <source>Add &amp;directory</source>
        <translation>&amp;Klasör ekle</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Remove &amp;selected</source>
        <translation>&amp;Seçiliyi kaldır</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="380"/>
        <source>Remove &amp;all</source>
        <translation>&amp;Hepsini kaldır</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="387"/>
        <source>Add...</source>
        <translation>Ekle...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="389"/>
        <source>Remove...</source>
        <translation>Kaldır...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="879"/>
        <source>Playlist modified</source>
        <translation>Oynatma listesi değiştirildi</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="880"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Kaydedilmemiş değişiklikler var. Oynatma listesini kaydetmek ister misiniz?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>Preferences</source>
        <translation>Seçenekler</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Oynatma listesi - Seçenekler</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Eğer bir klasörü eklediğinizde alt klasörlerdeki dosyaların da özyinelice eklenmesini istiyorsanız bu seçeneği işaretleyin. Aksi halde sadece seçtiğiniz klasördeki dosyalar eklenecek.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>Bu klasördeki dosy&amp;aları özyinelice ekle</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Eğer SMPlayer&apos;ın eklenecek dosyalar hakkında bilgi edinmesini istiyorsanız işaretleyin. Bu seçenek -bulunuyorsa- dosyanın başlığını ve süresini göstermeye yarar. Aksi halde dosya oynatılmaya başlanmadan bu bilgiler edinilemeyecek. Uyarı: Özellikle çok dosya eklediğinizde bu özellik bilgisayarınızı yavaşlatabilir.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Eklenen dosyalar hakkında otomatik olarak bilgi ed&amp;in</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>Çıkışta oynatma liste&amp;sinin bir kopyasını kaydet</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>Videoyu oynatmaya &amp;baştan başla</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Tüm dosyalar ilişkilendirilemedi. Lütfen güvenlik izinlerinizi kontrol edip tekrar deneyin.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Dosya Türleri</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Hepsini seç</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Listedeki tüm dosya türlerini işaretle</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Listeki tüm dosyalardan işaretlemeyi kaldır</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Dosya türleri listesi</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Dosya türleri</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Hepsini Seç</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Hiçbirini Seçme</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Hiçbirini seçme</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation>(sp)&lt;b&gt;Not:&lt;/b&gt; (Eski haline getirme Windows Vista&apos;da çalışmaz).</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <source>Drives</source>
        <translation type="obsolete">Sürücüler</translation>
    </message>
    <message>
        <source>CD device</source>
        <translation type="obsolete">CD sürücü</translation>
    </message>
    <message>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation type="obsolete">CDROM sürücünüzü seçiniz. Bu sürücü VCD ve Müzik CD&apos;lerinin oynatılmasında kullanılacak.</translation>
    </message>
    <message>
        <source>DVD device</source>
        <translation type="obsolete">DVD sürücü</translation>
    </message>
    <message>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation type="obsolete">DVD sürücünüzü seçiniz. Bu sürücü DVD&apos;lerin oynatılmasında kullanılacak.</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">simge</translation>
    </message>
    <message>
        <source>Select your &amp;CD device:</source>
        <translation type="obsolete">&amp;CD sürücünüzü seçiniz:</translation>
    </message>
    <message>
        <source>Select your &amp;DVD device:</source>
        <translation type="obsolete">&amp;DVD sürücünüzü seçiniz:</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="76"/>
        <source>General</source>
        <translation>Genel</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation type="obsolete">Çalıştırılabilir mplayer dosyasını seçin</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation type="obsolete">Çalıştırılabilirler</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="obsolete">Tüm dosyalar</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation type="obsolete">Bir klasör seçin</translation>
    </message>
    <message>
        <source>MPlayer executable</source>
        <translation type="obsolete">Çalıştırılabilir MPlayer dosyası</translation>
    </message>
    <message>
        <source>Screenshots folder</source>
        <translation type="obsolete">Yakalanan ekran görüntülerinin klasörü</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="334"/>
        <source>Automatically add files to playlist</source>
        <translation type="unfinished">Dosyaları otomatik olarak oynatma listesine ekle</translation>
    </message>
    <message>
        <source>Video output driver</source>
        <translation type="obsolete">Video çıktısı sürücüsü</translation>
    </message>
    <message>
        <source>Audio output driver</source>
        <translation type="obsolete">Ses çıktısı sürücüsü</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation type="obsolete">Ses çıktısı içim sürücü seçin.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="320"/>
        <source>Remember settings</source>
        <translation>Ayarları hatırla</translation>
    </message>
    <message>
        <source>Software video equalizer</source>
        <translation type="obsolete">Yazılım video dengeleyici</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="obsolete">Eğer video eşitleyici özelliği ekran kartınız veya seçtiğiniz video çıktısı sürücüsü tarafından desteklenmiyorsa bu seçeneği işaretleyin.&lt;br&gt;&lt;b&gt;Not:&lt;/b&gt; Bu seçenek bazı video çıktısı sürücüleri ile uyumsuzluk gösterebilir.</translation>
    </message>
    <message>
        <source>Postprocessing quality</source>
        <translation type="obsolete">Ardişlem kalitesi</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="obsolete">Atıl işlemci gücüne bağlı olarak önişlem seviyesini değiştir. Belirlediğiniz sayı en yüksek seviye kabul edilecektir. Genellikle büyük bir sayı seçebilirsiniz.</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation type="obsolete">Videoları tam ekran başlat</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation type="obsolete">Bu seçeneği işaretlerseniz, videolar tam ekran olarak açılacak.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Disable screensaver</source>
        <translation>Ekran koruyucuyu devredışı bırak</translation>
    </message>
    <message>
        <source>Software volume control</source>
        <translation type="obsolete">Yazılım ses kontrolü</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="obsolete">Eğer ses kartı tabanlı değil yazılım tabanlı karıştırıcı (mixer) kullanıyorsanız bu seçeneği işaretleyin.</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="obsolete">&amp;Genel</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="318"/>
        <source>Media settings</source>
        <translation>Ortam ayarları</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="65"/>
        <source>&amp;Disable screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="94"/>
        <source>Cha&amp;nnels by default:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="125"/>
        <location filename="../prefgeneral.cpp" line="375"/>
        <source>Main window</source>
        <translation type="unfinished">Ana pencere</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="133"/>
        <source>A&amp;utoresize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="193"/>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>Instances</source>
        <translation type="unfinished">Oluşumlar</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="202"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="221"/>
        <source>&amp;Volume normalization by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">Otomatik boyutlandı&amp;rma:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="150"/>
        <source>Never</source>
        <translation type="unfinished">Asla</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="155"/>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished">Gerektiğinde</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="160"/>
        <source>Only after loading a new video</source>
        <translation type="unfinished">Sadece yeni bir video yüklendiğinde</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="183"/>
        <source>R&amp;emember position and size</source>
        <translation type="unfinished">Konumu ve boyutu hatırl&amp;a</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation type="obsolete">Tercih edilen ses ve alt yazılar</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="377"/>
        <source>Autoresize</source>
        <translation type="unfinished">Otomatik boyutlandırma</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="378"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="unfinished">Ana pencere otomatik olarak yeniden boyutlandırılır.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="381"/>
        <source>Remember position and size</source>
        <translation type="unfinished">Konumu ve boyutu hatırla</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="212"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Audio</source>
        <translation type="unfinished">Ses</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">AC3/DTS&apos;den S/PDIF&apos;ye düzgeçiş</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="51"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>&amp;Tüm dosyalar için ayarları hatırla (ses izi, alt yazı...)</translation>
    </message>
    <message>
        <source>&amp;Quality:</source>
        <translation type="obsolete">&amp;Kalite:</translation>
    </message>
    <message>
        <source>Start videos in &amp;fullscreen</source>
        <translation type="obsolete">Videoları tam ekran &amp;başlat</translation>
    </message>
    <message>
        <source>Disable &amp;screensaver</source>
        <translation type="obsolete">&amp;Ekran koruyucuyu devredışı bırak</translation>
    </message>
    <message>
        <source>Use s&amp;oftware volume control</source>
        <translation type="obsolete">Yazılıma bağlı ses kontr&amp;olü kullan</translation>
    </message>
    <message>
        <source>Ma&amp;x. Amplification:</source>
        <translation type="obsolete">Azami Ku&amp;vvetlendirme:</translation>
    </message>
    <message>
        <source>&amp;AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">&amp;AC3/DTS&apos;den S/PDIF&apos;ye düzgeçiş</translation>
    </message>
    <message>
        <source>Direct rendering</source>
        <translation type="obsolete">Doğrudan oluşturma</translation>
    </message>
    <message>
        <source>Double buffering</source>
        <translation type="obsolete">2 x ara belleğe alma</translation>
    </message>
    <message>
        <source>D&amp;irect rendering</source>
        <translation type="obsolete">&amp;Doğrudan kaplama</translation>
    </message>
    <message>
        <source>Dou&amp;ble buffering</source>
        <translation type="obsolete">2 x ara &amp;belleğe alma</translation>
    </message>
    <message>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation type="obsolete">2 x ara belleğe alma hafızada aynı anda iki kare tutarak titremeleri engeller ve bir kareyi gösterirken diğerinin kodunu çözer. Devredışı bırakılırsa OSD&apos;yi olumsuz etkileyebilir.</translation>
    </message>
    <message>
        <source>&amp;Enable postprocessing by default</source>
        <translation type="obsolete">Ardişl&amp;em her zaman uygulansın</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Ses &amp;normalleştirme her zaman uygulansın</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="325"/>
        <source>Close when finished</source>
        <translation>Bittiği zaman kapat</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="326"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Bunu seçerseniz, şu an oynatılan dosya/oynatma listesi bittiği zaman programın ana penceresi otomatik olarak kapatılacak.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="92"/>
        <source>2 (Stereo)</source>
        <translation>2 (Stereo)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="93"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 Surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="94"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 Surround)</translation>
    </message>
    <message>
        <source>C&amp;hannels by default:</source>
        <translation type="obsolete">Varsa&amp;yılı kanallar:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="79"/>
        <source>&amp;Pause when minimized</source>
        <translation>Simge durumuna küçültüldüğünde &amp;duraklat</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="329"/>
        <source>Pause when minimized</source>
        <translation>Simge durumuna küçültüldüğünde duraklat</translation>
    </message>
    <message>
        <source>Enable postprocessing by default</source>
        <translation type="obsolete">Ardişlem her zaman uygulansın</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="348"/>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Max. Amplification</source>
        <translation type="obsolete">Azami Kuvvetlendirme</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="394"/>
        <source>Volume normalization by default</source>
        <translation type="unfinished">Ses normalleştirme her zaman uygulansın</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="unfinished">Sesi bozmadan en yüksek seviyeye getirir.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="364"/>
        <source>Channels by default</source>
        <translation>Varsayılı kanallar</translation>
    </message>
    <message>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation type="obsolete">Azami kuvvetlendirme seviyesini belirler (varsayılan: 110). Seviyeyi 200&apos;e getirirseniz sesi şu andaki düzeyin 2 katına getirmeniz mümkün olacaktır. 100&apos;ün altındaki değerlerin seçilmesi başlangıçtaki sesin (%100) azami seviyenin üstünde kalmasına sebep olacaktır ve OSD bu durumda seviyeyi düzgün gösteremez.</translation>
    </message>
    <message>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation type="obsolete">Yeni açılan dosyalarda ardişlem varsayılı olarak uygulanır.</translation>
    </message>
    <message>
        <source>High speed &amp;playback without altering pitch</source>
        <translation type="obsolete">Ses perdesini &amp;değiştirmeden hızlı oynatma</translation>
    </message>
    <message>
        <source>High speed playback without altering pitch</source>
        <translation type="obsolete">Ses perdesini değiştirmeden hızlı oynatma</translation>
    </message>
    <message>
        <source>Allows to change the playback speed without altering pitch. Requires at least MPlayer dev-SVN-r24924.</source>
        <translation type="obsolete">Oynatma hızının ses perdesi aynıyken değiştirilmesini sağlar.En az MPlayer dev-SVN-r24924 sürümünü gerektirir.</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="obsolete">V&amp;ideo</translation>
    </message>
    <message>
        <source>Use s&amp;oftware video equalizer</source>
        <translation type="obsolete">Yazılım tabanlı vide&amp;o dengeleyici kullan</translation>
    </message>
    <message>
        <source>A&amp;udio</source>
        <translation type="obsolete">S&amp;es</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">Ses</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Hiçbiri</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">Lowpass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normal)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (2 x kare sayısı)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Doğrusal karıştırma</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Kerndeint</translation>
    </message>
    <message>
        <source>Deinterlace by default</source>
        <translation type="obsolete">Görüntü ayrıştırma varsayılı</translation>
    </message>
    <message>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation type="obsolete">Yeni açılan dosyalarda kullanılacak görüntü ayrıştırma süzgecini seçiniz.</translation>
    </message>
    <message>
        <source>Remember time position</source>
        <translation type="obsolete">İzlerken kalınan yeri hatırla</translation>
    </message>
    <message>
        <source>Remember &amp;time position</source>
        <translation type="obsolete">İzlerken kalınan yeri ha&amp;tırla</translation>
    </message>
    <message>
        <source>Enable the audio equalizer</source>
        <translation type="obsolete">Ses dengeleyiciyi etkinleştir</translation>
    </message>
    <message>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation type="obsolete">Ses dengeleyici kullanmak istiyorsanız işaretleyiniz.</translation>
    </message>
    <message>
        <source>&amp;Enable the audio equalizer</source>
        <translation type="obsolete">Ses dengeleyiciyi &amp;etkinleştir</translation>
    </message>
    <message>
        <source>Draw video using slices</source>
        <translation type="obsolete">Videoyu kesitler halinde oluşturur</translation>
    </message>
    <message>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation type="obsolete">Videonun 16 piksel yüksekliğinde kesitler kullanılması etkin/edilgin. Edilginken tüm görüntü karesi tek seferde oluşturulur. Ön bellek miktarına ve ekran kartına bağlı olarak daha hızlı veya yavaş olabilir. Sadece libmpeg2 ve libavcodec kodlayıcıları kullanıldığında işe yarar.</translation>
    </message>
    <message>
        <source>Dra&amp;w video using slices</source>
        <translation type="obsolete">&amp;Videoyu kesitler halinde oluşturur</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="58"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Oynatma bittiğinde kapat</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="obsolete">hızlı</translation>
    </message>
    <message>
        <source>slow</source>
        <translation type="obsolete">yavaş</translation>
    </message>
    <message>
        <source>fast - ATI cards</source>
        <translation type="obsolete">hızlı - ATI kartlar</translation>
    </message>
    <message>
        <source>User defined...</source>
        <translation type="obsolete">Kullanıcı tarafından belirlenen...</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="321"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="335"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default zoom</source>
        <translation type="obsolete">Geçerli yakınlaştırma</translation>
    </message>
    <message>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation type="obsolete">Yeni açılan videolar için kullanılacak geçerli yakınlaştırmayı belirler.</translation>
    </message>
    <message>
        <source>Default &amp;zoom:</source>
        <translation type="obsolete">Geçerli &amp;yakınlaştırma:</translation>
    </message>
    <message>
        <source>Select the video output driver. %1 provides the best performance.</source>
        <translation type="obsolete">Video çıktı sürücüsünü seçiniz. %1 en iy başarımı sağlar.</translation>
    </message>
    <message>
        <source>%1 is the recommended one. Try to avoid %2 and %3, they are slow and can have an impact on performance.</source>
        <translation type="obsolete">%1 tavsiye edilir. %2 ve %3 yavaş oldukları için ve başarım üzerinde olumsuz etkileri olabileceğinden kullanmaktan kaçınınız.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="330"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Seçilirse, ana pencere gizlendiğinde dosya duraklatılır. Pencere eski boyutuna getirildiğinde oynatma devam eder.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Herhangi bir dosya oynatılırken ekran koruyucuyu devredışı bırakmak için bu seçeneği işaretleyin.&lt;br&gt;Oynatma işlemi bittiğinde ekran koruyucu tekrar çalıştırılacak.</translation>
    </message>
    <message>
        <source>Ou&amp;tput driver:</source>
        <translation type="obsolete">&amp;Çıktı sürücüsü:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="365"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Switch screensaver off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="342"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="347"/>
        <source>Avoid screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="360"/>
        <source>Audio/video auto synchronization</source>
        <translation type="unfinished">Otomatik ses/görüntü uyumu</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished">Ses gecikmesi hesaplamalarına dayanarak, ses/görüntü uyumunu aşama aşama gerçekleştir.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Oynatma listesi</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="72"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation type="unfinished">Dosyaları &amp;otomatik olarak oynatma listesine ekle</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation type="obsolete">Uyum</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="44"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="obsolete">Klavye ve fare</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Hiçbiri</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="obsolete">&amp;Klavye</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">simge</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Burada, değiştirmek istediğiniz kısayola çift tıklayarak veya üzerine gelip yazmaya başlayarak, tüm kısayolları değiştirebilirsiniz. Ayrıca, hazırladığınız listeyi kaydedip insanlarla paylaşabilir veya başka bir bilgisayarda kullanabilirsiniz.</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="obsolete">&amp;Fare</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation type="obsolete">Düğme özellikleri:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation type="obsolete">Gezinme</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation type="obsolete">Ses kontrolü</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="obsolete">Videoyu yakınlaştır</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Burada tüm kısayolları değiştirebilirsiniz. Değiştirmek istediğiniz kısayolun kutucuğuna çift tıklayın veya kutucuktayken enter&apos;a basın. İsterseniz kendi hazırladığınız listeyi kaydedip arkadaşlarınızla paylaşabilir veya başka bir bilgisayarda kullanabilirsiniz.</translation>
    </message>
    <message>
        <source>&amp;Left click</source>
        <translation type="obsolete">So&amp;l tıklama</translation>
    </message>
    <message>
        <source>&amp;Double click</source>
        <translation type="obsolete">&amp;Çift tıklama</translation>
    </message>
    <message>
        <source>&amp;Wheel function:</source>
        <translation type="obsolete">Teker ö&amp;zelliği:</translation>
    </message>
    <message>
        <source>Shortcut editor</source>
        <translation type="obsolete">Kısayol düzenleyici</translation>
    </message>
    <message>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation type="obsolete">Bu tablo neredeyse tüm işlemlerin kısayolları değiştirebilmenize yarar. Değiştirmek istediğiniz kısayolun kutucuğuna çift tıklayın veya kutucuktayken enter&apos;a basın; ya da &lt;b&gt;Kısayolu değiştir&lt;/b&gt; düğmesine basınız. Kısayolları değiştirmek için iki yol var: eğer &lt;b&gt;Yakala&lt;b&gt; düğmesi aktifse, klavyede, atamak istediğiniz kısayol tuşlarına basmanız yeterli. Eğer düğme aktif değilse kısayolu kendiniz yazmalısınız.</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation type="obsolete">Sol tıklama</translation>
    </message>
    <message>
        <source>Select the action for left click on the mouse.</source>
        <translation type="obsolete">Solla tıklandığında ne yapılacağını seçiniz.</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation type="obsolete">Çift tıklama</translation>
    </message>
    <message>
        <source>Select the action for double click on the mouse.</source>
        <translation type="obsolete">Çift tıklandığında ne yapılacağını seçiniz.</translation>
    </message>
    <message>
        <source>Wheel function</source>
        <translation type="obsolete">Teker özelliği</translation>
    </message>
    <message>
        <source>Select the action for the mouse wheel.</source>
        <translation type="obsolete">Fare tekerinin ne işe yarayacağını seçiniz.</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="obsolete">Oynat</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Duraklat</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Durdur</translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="obsolete">Tam ekran</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation type="obsolete">Temiz ekran</translation>
    </message>
    <message>
        <source>Screenshot</source>
        <translation type="obsolete">Ekran görüntüsünü yakala</translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="obsolete">Sessiz</translation>
    </message>
    <message>
        <source>Frame counter</source>
        <translation type="obsolete">Kare sayacı</translation>
    </message>
    <message>
        <source>Reset zoom</source>
        <translation type="obsolete">Yakınlaştırmayı sıfırla</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="obsolete">Tam ekrandan çık</translation>
    </message>
    <message>
        <source>Double size</source>
        <translation type="obsolete">Boyutu ikiye katla</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation type="obsolete">Oynat / Duraklat</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation type="obsolete">Duraklat / Bir kare ilerle</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Oynatma listesi</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Tercihler</translation>
    </message>
    <message>
        <source>No function</source>
        <translation type="obsolete">Özellik atama</translation>
    </message>
    <message>
        <source>Change speed</source>
        <translation type="obsolete">Hızı değiştir</translation>
    </message>
    <message>
        <source>Normal speed</source>
        <translation type="obsolete">Normal hız</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klavye</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Fare</translation>
    </message>
    <message>
        <source>Middle click</source>
        <translation type="obsolete">Orta tıklama</translation>
    </message>
    <message>
        <source>Select the action for middle click on the mouse.</source>
        <translation type="obsolete">Ortayla tıklandığında ne olacağını seçiniz.</translation>
    </message>
    <message>
        <source>M&amp;iddle click</source>
        <translation type="obsolete">&amp;Orta tıklama</translation>
    </message>
    <message>
        <source>X Button &amp;1</source>
        <translation type="obsolete">X Düğmesi &amp;1</translation>
    </message>
    <message>
        <source>X Button &amp;2</source>
        <translation type="obsolete">X Düğmesi &amp;2</translation>
    </message>
    <message>
        <source>Go backward (short)</source>
        <translation type="obsolete">Geriye git (kısa)</translation>
    </message>
    <message>
        <source>Go backward (medium)</source>
        <translation type="obsolete">Geriye git (orta)</translation>
    </message>
    <message>
        <source>Go backward (long)</source>
        <translation type="obsolete">Geriye git (uzun)</translation>
    </message>
    <message>
        <source>Go forward (short)</source>
        <translation type="obsolete">İleriye git (kısa)</translation>
    </message>
    <message>
        <source>Go forward (medium)</source>
        <translation type="obsolete">İleriye git (orta)</translation>
    </message>
    <message>
        <source>Go forward (long)</source>
        <translation type="obsolete">İleriye git (uzun)</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="obsolete">OSD - Sonraki seviye</translation>
    </message>
    <message>
        <source>Show context menu</source>
        <translation type="obsolete">İçerik menüsünü göster</translation>
    </message>
    <message>
        <source>&amp;Right click</source>
        <translation type="obsolete">Sağ &amp;tıklama</translation>
    </message>
    <message>
        <source>Increase volume</source>
        <translation type="obsolete">Sesi yükselt</translation>
    </message>
    <message>
        <source>Decrease volume</source>
        <translation type="obsolete">Sesi düşür</translation>
    </message>
    <message>
        <source>X Button 1</source>
        <translation type="obsolete">X Düğmesi 1</translation>
    </message>
    <message>
        <source>Select the action for the X button 1.</source>
        <translation type="obsolete">X Düğmesi 1&apos;in ne yapacağın seçiniz.</translation>
    </message>
    <message>
        <source>X Button 2</source>
        <translation type="obsolete">X Düğmesi 2</translation>
    </message>
    <message>
        <source>Select the action for the X button 2.</source>
        <translation type="obsolete">X Düğmesi 2&apos;nin ne yapacağını seçiniz.</translation>
    </message>
    <message>
        <source>Show video equalizer</source>
        <translation type="obsolete">Video dengeleyiciyi göster</translation>
    </message>
    <message>
        <source>Show audio equalizer</source>
        <translation type="obsolete">Ses dengeleyiciyi göster</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <source>Interface</source>
        <translation type="obsolete">Arayüz</translation>
    </message>
    <message>
        <source>Volume normalization by default</source>
        <translation type="obsolete">Ses normalleştirme her zaman uygulansın</translation>
    </message>
    <message>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="obsolete">Sesi bozmadan en yüksek seviyeye getirir.</translation>
    </message>
    <message>
        <source>Default subtitle encoding</source>
        <translation type="obsolete">Varsayılan alt yazı kodlaması</translation>
    </message>
    <message>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="obsolete">Alt yazılar için kullanılacak geçerli kodlamayı seçiniz.</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation type="obsolete">Otomatik yükle</translation>
    </message>
    <message>
        <source>Select the subtitle autoload method.</source>
        <translation type="obsolete">Alt yazıları otomatik yükleme yöntemini seçiniz.</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation type="obsolete">&lt;Otomatik&gt;</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="obsolete">Geçerli</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Dil</translation>
    </message>
    <message>
        <source>&amp;Interface</source>
        <translation type="obsolete">Aray&amp;üz</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation type="obsolete">Son açılanlar</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Asla</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation type="obsolete">Gerektiğinde</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation type="obsolete">Sadece yeni bir video yüklendiğinde</translation>
    </message>
    <message>
        <source>Here you can change the language of the application.</source>
        <translation type="obsolete">Burada programın dilini değiştirebilirsiniz.</translation>
    </message>
    <message>
        <source>Ma&amp;x. items</source>
        <translation type="obsolete">&amp;En fazla</translation>
    </message>
    <message>
        <source>St&amp;yle:</source>
        <translation type="obsolete">St&amp;il:</translation>
    </message>
    <message>
        <source>L&amp;anguage:</source>
        <translation type="obsolete">&amp;Dil:</translation>
    </message>
    <message>
        <source>Main window</source>
        <translation type="obsolete">Ana pencere</translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">Otomatik boyutlandı&amp;rma:</translation>
    </message>
    <message>
        <source>R&amp;emember position and size</source>
        <translation type="obsolete">Konumu ve boyutu hatırl&amp;a</translation>
    </message>
    <message>
        <source>Default font:</source>
        <translation type="obsolete">Varsayılan yazıtipi:</translation>
    </message>
    <message>
        <source>&amp;Change...</source>
        <translation type="obsolete">&amp;Değiştir...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">YazıEtiketi</translation>
    </message>
    <message>
        <source>Ins&amp;tances</source>
        <translation type="obsolete">&amp;Oluşumlar</translation>
    </message>
    <message>
        <source>Autoresize</source>
        <translation type="obsolete">Otomatik boyutlandırma</translation>
    </message>
    <message>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="obsolete">Ana pencere otomatik olarak yeniden boyutlandırılır.</translation>
    </message>
    <message>
        <source>Remember position and size</source>
        <translation type="obsolete">Konumu ve boyutu hatırla</translation>
    </message>
    <message>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation type="obsolete"> &lt;b&gt;Aç-&gt;Son açılanlar&lt;/b&gt; alt menüsünde gösterilecek en fazla dosya sayısını seçiniz. Eğer 0&apos;ı seçerseniz menü gösterilmez.</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stil</translation>
    </message>
    <message>
        <source>Select the style you prefer for the application.</source>
        <translation type="obsolete">Uygulama için tercih ettiğiniz stili seçiniz.</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation type="obsolete">Varsayılan yazı tipi</translation>
    </message>
    <message>
        <source>You can change here the application&apos;s font.</source>
        <translation type="obsolete">Burada uygulamanın yazı tipini değiştirebilirsiniz.</translation>
    </message>
    <message>
        <source>Instances</source>
        <translation type="obsolete">Oluşumlar</translation>
    </message>
    <message>
        <source>Default GUI</source>
        <translation type="obsolete">Varsayılan GUI</translation>
    </message>
    <message>
        <source>Automatic port</source>
        <translation type="obsolete">Otomatik bağlantı noktası</translation>
    </message>
    <message>
        <source>Manual port</source>
        <translation type="obsolete">Kullanıcı tarafından belirlenen bağlantı noktası</translation>
    </message>
    <message>
        <source>Port to listen</source>
        <translation type="obsolete">Dinlenecek bağlantı noktası</translation>
    </message>
    <message>
        <source>&amp;Automatic</source>
        <translation type="obsolete">&amp;Otomatik</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="obsolete">&amp;Kullanıcı tarafından</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Alt yazılar</translation>
    </message>
    <message>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="obsolete">Alt yazı dosyalarını otomatik olarak y&amp;ükle (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation type="obsolete">Filmle aynı isimde</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation type="obsolete">Filmin ismini içeren tüm alt yazılar</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation type="obsolete">Klasördeki tüm alt yazılar</translation>
    </message>
    <message>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="obsolete">Varsayılan alt yazı ko&amp;dlaması:</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="obsolete">Ses</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Ses &amp;normalleştirme her zaman uygulansın</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <source>Performance</source>
        <translation type="obsolete">Başarım</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="obsolete">Öncelik</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="obsolete">Ön bellek</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="obsolete">Kare es geçmeye izin ver</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="obsolete">Yavaş sistemlerde ses/görüntü uyumunu sağlamak için bazı kareleri atla.</translation>
    </message>
    <message>
        <source>Allow hard frame drop</source>
        <translation type="obsolete">Yoğun kare es geçme</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="obsolete">Daha yoğun kare es geçme (kod çözmeyi bozar). Görüntünün bozulmasına yol açar!</translation>
    </message>
    <message>
        <source>&amp;Performance</source>
        <translation type="obsolete">&amp;Başarım</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="obsolete">Mplayer için geçerli olacak önceliği seçin.</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="obsolete">gerçek zamanlı</translation>
    </message>
    <message>
        <source>high</source>
        <translation type="obsolete">yüksek</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="obsolete">normal üstü</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="obsolete">normal</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="obsolete">normal altı</translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="obsolete">âtıl</translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="obsolete">KB</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation type="obsolete">Ön belleği kullanmak başarımı arttırabilir</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation type="obsolete">Ses izini hızlı değiştirebilme</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation type="obsolete">DVD bölümlerini hızlı gezinebilme</translation>
    </message>
    <message>
        <source>Priorit&amp;y:</source>
        <translation type="obsolete">&amp;Öncelik:</translation>
    </message>
    <message>
        <source>&amp;Allow frame drop</source>
        <translation type="obsolete">K&amp;are es geçmeye izin ver</translation>
    </message>
    <message>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation type="obsolete">Yoğun kare es &amp;geçmeye izin ver (görüntünün bozulmasına yol açabilir)</translation>
    </message>
    <message>
        <source>&amp;Fast audio track switching</source>
        <translation type="obsolete">&amp;Ses izini hızlı değiştirebilme</translation>
    </message>
    <message>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation type="obsolete">&amp;DVD bölümlerini hızlı gezinebilme</translation>
    </message>
    <message>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation type="obsolete">Seçilirse bölümleri gezinebilmek için en hızlı yöntem denenecek. Bazı disklerde çalışmayabilir.</translation>
    </message>
    <message>
        <source>Skip loop filter</source>
        <translation type="obsolete">Döngü süzgecini atla</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation type="obsolete">H.264</translation>
    </message>
    <message>
        <source>Cache for files</source>
        <translation type="obsolete">Dosyalar için ön bellek</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation type="obsolete">Dosyaları ön belleğe almak için ne kadar bellek (kByte olarak) kullanılacağını belirler.</translation>
    </message>
    <message>
        <source>Cache for streams</source>
        <translation type="obsolete">Akışlar için ön bellek</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation type="obsolete">URL&apos;leri ön belleğe almak için ne kadar bellek (kByte olarak) kullanılacağını belirler.</translation>
    </message>
    <message>
        <source>Cache for DVDs</source>
        <translation type="obsolete">DVD&apos;ler için ön bellek</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation type="obsolete">DVD&apos;leri ön belleğe almak için ne kadar bellek (kByte olarak) kullanılacağını belirler.&lt;br&gt;&lt;b&gt;Uyarı:&lt;/b&gt; DVD&apos;ler için ön bellek kullanıldığı durumda bölümler arasında ve bölüm içinde gezinme düzgün çalışmayabilir.</translation>
    </message>
    <message>
        <source>&amp;Cache</source>
        <translation type="obsolete">&amp;Ön bellek</translation>
    </message>
    <message>
        <source>Cache for &amp;DVDs:</source>
        <translation type="obsolete">&amp;DVD&apos;ler için ön bellek:</translation>
    </message>
    <message>
        <source>Cache for &amp;local files:</source>
        <translation type="obsolete">Bilgisayardaki dosya&amp;lar için ön bellek:</translation>
    </message>
    <message>
        <source>Cache for &amp;streams:</source>
        <translation type="obsolete">&amp;Akışlar için ön bellek:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Etkin</translation>
    </message>
    <message>
        <source>Skip (always)</source>
        <translation type="obsolete">Atla (her zaman)</translation>
    </message>
    <message>
        <source>Skip only on HD videos</source>
        <translation type="obsolete">Sadece HD videoları atla</translation>
    </message>
    <message>
        <source>Loop &amp;filter</source>
        <translation type="obsolete">Döngü &amp;süzgeci</translation>
    </message>
    <message>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation type="obsolete">H.264 kod çözümü esnasında döngü süzgecinin es geçilmesine izin verir. HDTV&apos;lerde görüntü kaybı olmadan büyük hızlanma sağlar.</translation>
    </message>
    <message>
        <source>Possible values:</source>
        <translation type="obsolete">Olası değerler:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation type="obsolete">&lt;b&gt;Etkin&lt;/b&gt;: döngü süzgeci es geçilmez</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation type="obsolete">&lt;b&gt;Atla (her zaman)&lt;/b&gt;: döngü süzgeci videonun çözünürlüğü ne olursa olsun es geçilir</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation type="obsolete">&lt;b&gt;Sadece HD videoları atla&lt;/b&gt;: döngü süzgeci sadece %1 veya daha fazla çözünürlükteki videolar için es geçilir.</translation>
    </message>
    <message>
        <source>Cache for audio CDs</source>
        <translation type="obsolete">Müzik CD&apos;leri için ön bellek</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation type="obsolete">Müzik CD&apos;lerini ön belleğe almak için ne kadar bellek (kByte olarak) kullanılacağını belirler.</translation>
    </message>
    <message>
        <source>Cache for &amp;audio CDs:</source>
        <translation type="obsolete">&amp;Müzik CD&apos;leri için ön bellek:</translation>
    </message>
    <message>
        <source>Cache for VCDs</source>
        <translation type="obsolete">VCD&apos;ler için ön bellek</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation type="obsolete">VCD&apos;leri ön belleğe almak için ne kadar bellek (kByte olarak) kullanılacağını belirler.</translation>
    </message>
    <message>
        <source>Cache for &amp;VCDs:</source>
        <translation type="obsolete">&amp;VCD&apos;ler için ön bellek:</translation>
    </message>
    <message>
        <source>Threads for decoding</source>
        <translation type="obsolete">Kod çözme dizileri</translation>
    </message>
    <message>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation type="obsolete">Sadece MPEG-1/2 ve H.264 için kod çözmede kullanılacak dizi sayısını belirler</translation>
    </message>
    <message>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation type="obsolete">&amp;Kod çözme dizileri (Sadece MPEG-1/2 ve H.264):</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation type="unfinished">Alt yazılar</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished">Tercih edilen ses ve alt yazılar</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation type="obsolete">Bir ttf dosyası seçin</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation type="obsolete">Truetype Fontlar</translation>
    </message>
    <message>
        <source>Subtitle position</source>
        <translation type="obsolete">Alt yazının konumu</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="obsolete">Bu seçenek alt yazıların ekranda bulunacağı yeri belirlemenizi sağlar. En alt için &lt;i&gt;100&lt;/i&gt; , en üst için &lt;i&gt;0&lt;/i&gt;&apos;ı seçin.</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="obsolete">Alt &amp;yazı</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation type="unfinished">Otomatik yükle</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="obsolete">Seçeneğe uyan ilk yazıyı kendiliğinden seç</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation type="unfinished">Filmle aynı isimde</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation type="unfinished">Filmin ismini içeren tüm alt yazılar</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation type="unfinished">Klasördeki tüm alt yazılar</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="obsolete">Konum</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="obsolete">En üst</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="obsolete">En alt</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation type="obsolete">Alt yazılar yakalanan ekranlarda gözüksün</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="obsolete">Font</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation type="obsolete">Alt yazılar (ve OSD) için kullanılacak fontu seçin:</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Boyut</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation type="obsolete">Otomatik orantılama yok</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation type="obsolete">Filmin yüksekliğiyle orantılı</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation type="obsolete">Filmin genişliğiyle orantılı</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation type="obsolete">Filmin köşegen uzunluğuyla orantılı</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished">Alt yazı dosyalarını otomatik olarak y&amp;ükle (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>S&amp;elect first available subtitle</source>
        <translation type="obsolete">S&amp;eçeneğe uyan ilk yazıyı kendiliğinden seç</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="unfinished">Varsayılan alt yazı ko&amp;dlaması:</translation>
    </message>
    <message>
        <source>Default &amp;position of the subtitles on screen</source>
        <translation type="obsolete">Alt yazılar için varsayılan &amp;konum</translation>
    </message>
    <message>
        <source>&amp;Include subtitles on screenshots</source>
        <translation type="obsolete">Alt yazılar &amp;yakalanan ekranlarda gözüksün</translation>
    </message>
    <message>
        <source>&amp;TTF font:</source>
        <translation type="obsolete">&amp;TTF yazıtipi:</translation>
    </message>
    <message>
        <source>S&amp;ystem font:</source>
        <translation type="obsolete">Sistem &amp;yazıtipi:</translation>
    </message>
    <message>
        <source>A&amp;utoscale:</source>
        <translation type="obsolete">&amp;Otomatik orantılama:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation type="unfinished">Varsayılan alt yazı kodlaması</translation>
    </message>
    <message>
        <source>TTF font</source>
        <translation type="obsolete">TTF yazıtipi</translation>
    </message>
    <message>
        <source>System font</source>
        <translation type="obsolete">Sistem yazıtipi</translation>
    </message>
    <message>
        <source>Here you can select a system font to be used for the subtitles and OSD. &lt;b&gt;Note:&lt;/b&gt; requires a MPlayer with fontconfig support.</source>
        <translation type="obsolete">Burada alt yazılar ve OSD için kullanılacak sistem yazı tipini seçebilirsiniz. &lt;b&gt;Not:&lt;/b&gt; fontconfig desteği içeren bir MPlayer gerektirir.</translation>
    </message>
    <message>
        <source>Autoscale</source>
        <translation type="obsolete">Otomatik orantılama</translation>
    </message>
    <message>
        <source>Text color</source>
        <translation type="obsolete">Yazı rengi</translation>
    </message>
    <message>
        <source>Select the color for the text of the subtitles.</source>
        <translation type="obsolete">Alt yazılar için renk seçiniz.</translation>
    </message>
    <message>
        <source>Border color</source>
        <translation type="obsolete">Kenar rengi</translation>
    </message>
    <message>
        <source>Select the color for the border of the subtitles.</source>
        <translation type="obsolete">Alt yazı kenarlarının rengini seçiniz.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation type="unfinished">Alt yazıları otomatik yükleme yöntemini seçiniz.</translation>
    </message>
    <message>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation type="obsolete">Eğer bir veya daha fazla alt yazı izi mevcutsa, içlerinden biri (genellikle birincisi) otomatik olarak seçilecektir. Eğer izlerden biri kullanıcının tercih ettiği dille uyuşuyorsa o iz seçilecektir.</translation>
    </message>
    <message>
        <source>Select the subtitle autoscaling method.</source>
        <translation type="obsolete">Alt yazıları orantılamak için kullanılacak yöntemi seçiniz.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="unfinished">Alt yazılar için kullanılacak geçerli kodlamayı seçiniz.</translation>
    </message>
    <message>
        <source>Try to autodetect for this language</source>
        <translation type="obsolete">Bu dil için otomatik olarak bulmaya çalış</translation>
    </message>
    <message>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a MPlayer compiled with ENCA support.</source>
        <translation type="obsolete">Bu seçenek etkinken altyazıların kodlaması seçilen dile uygun olarak yapılmaya çalışılacaktır. Eğer başarısız olunursa, varsayılı kodlama kullanılacaktır. Bu seçenek, ENCA desteğiyle derlenmiş bir MPlayer gerektirir.</translation>
    </message>
    <message>
        <source>Subtitle language</source>
        <translation type="obsolete">Alt yazı dili</translation>
    </message>
    <message>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation type="obsolete">Kodlamanın hangi dil için otomatik olarak tahmin edileceğini seçiniz.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation type="unfinished">Kodlama</translation>
    </message>
    <message>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation type="obsolete">Bu dil için otomatik olarak b&amp;ulmaya çalış:</translation>
    </message>
    <message>
        <source>Here you can select a ttf font to be used for the subtitles. Usually you&apos;ll find a lot of ttf fonts in %1</source>
        <translation type="obsolete">Burada alt yazılar için kullanılacak ttf yazıtipini seçebilirsiniz. Genellikle %1&apos;de birçok ttf yazıtipi bulabilirsiniz</translation>
    </message>
    <message>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">En alt</translation>
    </message>
    <message>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">En üst</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <source>None</source>
        <translation type="obsolete">Hiçbiri</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">Lowpass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normal)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (2 x kare sayısı)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Doğrusal karıştırma</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Kerndeint</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="97"/>
        <location filename="../preferencesdialog.cpp" line="172"/>
        <source>ROSA Media Player - Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="176"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="177"/>
        <source>Close</source>
        <translation type="unfinished">Kapat</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">İptal</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="178"/>
        <source>Apply</source>
        <translation>Uygula</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="179"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>bu mesajı gösterecek ve çıkacak.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>ana pencere oynatılan dosya/oynatma listesi bittiğinde kapatılacak.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>çalışan bir diğer oluşumla bağlantı kurup, oluşumu belirlenen eyleme göndermeye çalışırı. Örnek: -send-action pause Eğer varsa geri kalan seçenekler yok sayılır ve uygulama kapanır. Başarılı olursa 0 başarısız olursa -1.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>eylem_listesi eylemlerin boşlukla ayrıldığı bir listedir. Eylemler bir dosya çalıştırıldığında sizin belirlediğiniz sırayla uygulanmaya başlanır. Kontrol edilebilir eylemler için &quot;true&quot; ve &quot;false&quot;&apos;u parametre olarak kullanabilirsiniz. Örnek: -actions &quot;fullscreen compact true&quot;. Birden fazla eylem aktarıyorsanız tırnak işaretleri gerekmektedir.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>ortam</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>eğer başka bir olulum çalışıyorsa, dosya oluşumun oynatma listesine eklenecektir. Yoksa, bu seçenek yok sayılacak ve dosyalar yeni bir oluşumda açılacaktır.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>oynatılan dosya/oynatma listesi bittiğinde ana pencere kapatılmayacaktır.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>video tam ekran oynatılacaktır.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>video pencere içinde oynatılacaktır.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Eski ilişkilendirmeleri geri getirir ve kayıt defterini temizler.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Kullanım:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>klasör</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>eylem_adı</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>eylem_listesi</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>varsayılan GUI&apos;yi açar.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>altyazı_dosyası</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>birinci video için yüklenecek alt yazıyı belirler.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation type="unfinished">
            <numerusform>%1 saniye
        </numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation type="unfinished">
            <numerusform>%1 dakika
        </numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 ve %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="444"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>ZIP/UNZIP API hatası %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="94"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="97"/>
        <source>Unknown error in recording occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="100"/>
        <source>Sorry, recording crashed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="49"/>
        <source>/Screencast - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Information</source>
        <translation type="unfinished">Bilgi</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="86"/>
        <source>Length: %1
Size: %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>simge</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>etiket</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Değiştir</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Temizle</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Atamak istediğiniz tuş bileşimine basınız</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Yakala</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Basılan tuşları yakala</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation type="unfinished">Bilgi</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation type="unfinished">Tamam</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished">İptal</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Alt yazı seçimi</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Bu arşiv birden fazla alt yazı dosyası içeriyor. Lütfen içlerinden kullanmak istediğinizi seçiniz.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Hepsini Seç</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Hiçbirini seçme</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="97"/>
        <source>Channel editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="98"/>
        <source>TV/Radio list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Atla:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Otomatik</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Evet</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>Hayır</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="74"/>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Contrast</source>
        <translation>Zıtlık</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Brightness</source>
        <translation>Parlaklık</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Hue</source>
        <translation>Renk tonu</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Saturation</source>
        <translation>Doygunluk</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Gamma</source>
        <translation>Gama</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <source>&amp;Reset</source>
        <translation>&amp;Sıfırla</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Varsayılan yap</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Bu değerleri tüm yeni videolar için kullan.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Tüm kontrolleri sıfırla.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="71"/>
        <source>Video Equalizer</source>
        <translation>Video Dengeleyici</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="122"/>
        <source>Information</source>
        <translation>Bilgi</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="123"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Hali hazırdaki değerler varsayılan değerler olarak kaydedildi.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation type="unfinished">İptal</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation type="unfinished">Dosyayı kaydederken hata oluştu</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished">Dosya kaydedilemedi</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation type="unfinished">Hata</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation type="unfinished">Saniyede %1 kb</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation type="unfinished">%1 Hz</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation type="unfinished">Geçerli</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Ses</translation>
    </message>
</context>
</TS>
