In order to compile dxlist you need the directx headers,
you can get them from here: http://www.videolan.org/vlc/dx7headers.tgz

Then extract them here (actually only dsound.h, ddraw.h and d3dtypes.h
are necessary).
