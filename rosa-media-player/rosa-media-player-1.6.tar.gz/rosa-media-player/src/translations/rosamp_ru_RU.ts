<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="ru_RU">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="156"/>
        <source>The following people have contributed with translations:</source>
        <translation>Следующие люди внесли вклад своими переводами:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="162"/>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="163"/>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="164"/>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="167"/>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="237"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 и %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="171"/>
        <source>Simplified-Chinese</source>
        <translation>Упрощённый китайский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="172"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="234"/>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="173"/>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="83"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Версия %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation type="obsolete">(c) ROSA 2011-2012

Проигрыватель ROSA Media Player является свободным программным обеспечением.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="180"/>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="187"/>
        <source>Portuguese - Brazil</source>
        <translation>Португальский (Бразилия)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="189"/>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="193"/>
        <source>Turkish</source>
        <translation>Турецкий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="194"/>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="195"/>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Traditional Chinese</source>
        <translation>Китайский традиционный</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="197"/>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="198"/>
        <source>Portuguese - Portugal</source>
        <translation>Португальский (Португалия)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Greek</source>
        <translation>Греческий</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="202"/>
        <source>Finnish</source>
        <translation>Финский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <location filename="../about.cpp" line="267"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="291"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="26"/>
        <source>About ROSA Media Player</source>
        <translation>О ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../about.ui" line="75"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Droid Sans&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Droid Sans&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="203"/>
        <source>Korean</source>
        <translation>Корейский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Macedonian</source>
        <translation>Македонский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Basque</source>
        <translation>Баскский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="80"/>
        <source>Using MPlayer %1</source>
        <translation>Используется MPlayer %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="89"/>
        <source>(c) ROSA 2011-2013

ROSA Media Player is a free software.</source>
        <translation>(c) ROSA 2011-2013

Проигрыватель ROSA Media Player является свободным программным обеспечением.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>terms of use</source>
        <translation>условия использования</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="112"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation>Это свободное программное обеспечение; вы можете использовать, распространять и/или изменять его, руководствуясь 3-ей или (на ваше усмотрение) любой более поздней версией &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt;, если она уже официально опубликована фондом &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Catalan</source>
        <translation>Каталонский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Slovenian</source>
        <translation>Словенский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Arabic</source>
        <translation>Арабский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Kurdish</source>
        <translation>Курдский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Galician</source>
        <translation>Галийский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="240"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 и %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="243"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 и %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="211"/>
        <source>Vietnamese</source>
        <translation>Вьетнамский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="212"/>
        <source>Estonian</source>
        <translation>Эстонский</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Lithuanian</source>
        <translation>Литовский</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Shortcut</source>
        <translation>Горячая клавиша</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="169"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="172"/>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="420"/>
        <location filename="../actionseditor.cpp" line="479"/>
        <source>Key files</source>
        <translation>Горячие клавиши</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="418"/>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="432"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="433"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="478"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="447"/>
        <location filename="../actionseditor.cpp" line="487"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="448"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранен</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="488"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Файл не может быть загружен</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="176"/>
        <source>&amp;Change shortcut...</source>
        <translation>Изменить &amp;сочетание клавиш...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="74"/>
        <source>Audio Equalizer</source>
        <translation>Аудиоэквалайзер</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="77"/>
        <source>31.25 Hz</source>
        <translation>31.25 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>62.50 Hz</source>
        <translation>62.50 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="79"/>
        <source>125.0 Hz</source>
        <translation>125.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="80"/>
        <source>250.0 Hz</source>
        <translation>250.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>500.0 Hz</source>
        <translation>500.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>1.000 kHz</source>
        <translation>1.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>2.000 kHz</source>
        <translation>2.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>4.000 kHz</source>
        <translation>4.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>8.000 kHz</source>
        <translation>8.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>16.00 kHz</source>
        <translation>16.00 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>&amp;Apply</source>
        <translation>&amp;Применить</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>&amp;Set as default values</source>
        <translation>Сохранить как &amp;настройки по умолчанию</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать данные настройки по умолчанию для новых файлов.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="96"/>
        <source>Set all controls to zero.</source>
        <translation>Установить все значения в ноль.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="117"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="118"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Текущие параметры были сохранены как используемые по умолчанию.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>&amp;Open</source>
        <translation>&amp;Открыть</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>&amp;Video</source>
        <translation>&amp;Видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>&amp;Audio</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1590"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>&amp;Browse</source>
        <translation>О&amp;бзор</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>Op&amp;tions</source>
        <translation>&amp;Настройки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1593"/>
        <source>&amp;Help</source>
        <translation>Сп&amp;равка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1417"/>
        <source>&amp;File...</source>
        <translation>&amp;Файл...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1418"/>
        <source>D&amp;irectory...</source>
        <translation>Ката&amp;лог...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1419"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Список...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1422"/>
        <source>&amp;DVD from drive</source>
        <translation>DVD с &amp;привода</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1423"/>
        <source>D&amp;VD from folder...</source>
        <translation>DVD из &amp;папки...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <source>&amp;URL...</source>
        <translation>А&amp;дрес...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1599"/>
        <source>&amp;Clear</source>
        <translation>О&amp;чистить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1596"/>
        <source>&amp;Recent files</source>
        <translation>Посл&amp;едние файлы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1439"/>
        <source>P&amp;lay</source>
        <translation>&amp;Воспроизведение</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1446"/>
        <source>&amp;Pause</source>
        <translation>&amp;Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1447"/>
        <source>&amp;Stop</source>
        <translation>&amp;Стоп</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1448"/>
        <source>&amp;Frame step</source>
        <translation>По&amp;кадрово</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1459"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Нормальная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1460"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Половинная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1461"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Удвоенная скорость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1462"/>
        <source>Speed &amp;-10%</source>
        <translation>Скорос&amp;ть –10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>Speed &amp;+10%</source>
        <translation>Скорост&amp;ь +10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1532"/>
        <source>About &amp;ROSA Media Player</source>
        <translation>О &amp;ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1610"/>
        <source>Sp&amp;eed</source>
        <translation>Ск&amp;орость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1470"/>
        <source>&amp;Fullscreen</source>
        <translation>Н&amp;а весь экран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1619"/>
        <source>Si&amp;ze</source>
        <translation>&amp;Размер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1663"/>
        <location filename="../basegui.cpp" line="2733"/>
        <source>&amp;None</source>
        <translation>&amp;Ничего</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1664"/>
        <source>&amp;Lowpass5</source>
        <translation>Lowpass&amp;5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1667"/>
        <source>Linear &amp;Blend</source>
        <translation>Линейное &amp;смешивание</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1628"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Удаление &quot;гребёнки&quot;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1482"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Постобработка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1483"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Автоопределение фазы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1484"/>
        <source>&amp;Deblock</source>
        <translation>Смазывание границ &amp;квадратов</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1485"/>
        <source>De&amp;ring</source>
        <translation>Удаление к&amp;раевых артефактов</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>Add n&amp;oise</source>
        <translation>Добавление &amp;шума</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1632"/>
        <source>F&amp;ilters</source>
        <translation>Ф&amp;ильтры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1471"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1472"/>
        <source>&amp;Screenshot</source>
        <translation>С&amp;нимок экрана</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Расширенное стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке (подавление голоса)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1689"/>
        <source>&amp;Filters</source>
        <translation>&amp;Фильтры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1699"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;Окружение 4.0</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1700"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;Окружение 5.1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1693"/>
        <source>&amp;Channels</source>
        <translation>&amp;Каналы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1497"/>
        <source>&amp;Mute</source>
        <translation>Выключит&amp;ь звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1498"/>
        <source>Volume &amp;-</source>
        <translation>Г&amp;ромкость –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1499"/>
        <source>Volume &amp;+</source>
        <translation>Гр&amp;омкость +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1500"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Задержка –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>D&amp;elay +</source>
        <translation>З&amp;адержка +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1703"/>
        <source>&amp;Select</source>
        <translation>Вы&amp;брать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1512"/>
        <source>&amp;Load...</source>
        <translation>Загрузить из &amp;файла...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1708"/>
        <source>&amp;Title</source>
        <translation>&amp;Заголовок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1712"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Глава</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1716"/>
        <source>&amp;Angle</source>
        <translation>&amp;Ракурс</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1661"/>
        <source>&amp;Disabled</source>
        <translation>Запре&amp;щено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2749"/>
        <location filename="../basegui.cpp" line="2769"/>
        <location filename="../basegui.cpp" line="2789"/>
        <location filename="../basegui.cpp" line="2808"/>
        <location filename="../basegui.cpp" line="2837"/>
        <location filename="../basegui.cpp" line="2869"/>
        <location filename="../basegui.cpp" line="2896"/>
        <location filename="../basegui.cpp" line="2939"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;ничего&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3257"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3258"/>
        <location filename="../basegui.cpp" line="3496"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3259"/>
        <source>Playlists</source>
        <translation>Списки воспроизведения</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3260"/>
        <location filename="../basegui.cpp" line="3474"/>
        <location filename="../basegui.cpp" line="3497"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3255"/>
        <location filename="../basegui.cpp" line="3471"/>
        <location filename="../basegui.cpp" line="3494"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation>ROSA Media Player - отчет mplayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3319"/>
        <source>ROSA Media Player - Information</source>
        <translation>ROSA Media Player - Информация</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3320"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Приводы CD/DVD еще не настроены.
Вы сможете сделать это в диалоге настроек этих устройст.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3429"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3473"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3555"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation>Rosa Media Player – задержка аудио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3859"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>Установленная в вашей системе версия MPlayer (%1) устарела. ROSA Media Player не может работать с ней достаточно хорошо: некотрые опции не будут работать, выбор субтитров может вызывать ошибку...</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="obsolete">Playing %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pause</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1450"/>
        <source>Play / Pause</source>
        <translation>Воспроизведение / Пауза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1456"/>
        <source>Pause / Frame step</source>
        <translation>Пауза / Покадровый просмотр</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1504"/>
        <location filename="../basegui.cpp" line="1513"/>
        <source>U&amp;nload</source>
        <translation>В&amp;ыгрузить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1420"/>
        <source>V&amp;CD</source>
        <translation>&amp;Видео CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="256"/>
        <source>Play list</source>
        <translation>Список воспроизведения</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Trim video</source>
        <translation>Обрезать видео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="258"/>
        <source>Extract audio track</source>
        <translation>Извлечь аудиодорожку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1425"/>
        <source>C&amp;lose</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1453"/>
        <source>Show / Hide right panel</source>
        <translation>Показать / скрыть правую панель</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1527"/>
        <source>View &amp;info and properties...</source>
        <translation>Ин&amp;формация и параметры...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1528"/>
        <source>P&amp;references...</source>
        <translation>&amp;Настройки...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1531"/>
        <source>Help &amp;Contents</source>
        <translation>Руководство &amp;пользователя</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1553"/>
        <source>Dec volume (2)</source>
        <translation>Уменьшить громкость (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1554"/>
        <source>Inc volume (2)</source>
        <translation>Увеличить громкость (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1557"/>
        <source>Exit fullscreen</source>
        <translation>Выйти из поноэкранного режима</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1559"/>
        <source>OSD - Next level</source>
        <translation>OSD – Следующая фраза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1560"/>
        <source>Dec contrast</source>
        <translation>Уменьшить контраст</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1561"/>
        <source>Inc contrast</source>
        <translation>Повысить контраст</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Dec brightness</source>
        <translation>Уменьшить яркость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Inc brightness</source>
        <translation>Повысить яркость</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1564"/>
        <source>Dec hue</source>
        <translation>Уменьшить оттенок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1565"/>
        <source>Inc hue</source>
        <translation>Повысить оттенок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Dec saturation</source>
        <translation>Уменьшить насыщенность</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>Dec gamma</source>
        <translation>Уменьшить гамму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Next audio</source>
        <translation>Следующая звуковая дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Next subtitle</source>
        <translation>Следующая фраза</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Next chapter</source>
        <translation>Следующий раздел</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>Previous chapter</source>
        <translation>Предыдущий раздел</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2109"/>
        <source>Capture desktop...</source>
        <translation>Запись экранной презентации...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3332"/>
        <source>YouTube</source>
        <translation>YouTube</translation>
    </message>
    <message>
        <source>Video capture</source>
        <translation type="obsolete">Запись экранной презентации</translation>
    </message>
    <message>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="obsolete">Будет произведена запись видео с экрана. На время записи видео проигрыватель будет свернут в системный лоток. Для остановки записи нажмите на красный круглый значoк в системном лотке.</translation>
    </message>
    <message>
        <source>Start capture</source>
        <translation type="obsolete">Начать</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Отменить</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1567"/>
        <source>Inc saturation</source>
        <translation>Повысить насыщенность</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Inc gamma</source>
        <translation>Повысить гамму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <source>&amp;Load external file...</source>
        <translation>За&amp;грузить из файла...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1668"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Адаптивное (mplayer)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1665"/>
        <source>&amp;Yadif (normal)</source>
        <translation>Yadif (&amp;обычный)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1666"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Yadif (удвоенная частоты кадров)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1536"/>
        <source>Pre&amp;vious</source>
        <translation>П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1509"/>
        <source>Volume &amp;normalization</source>
        <translation>&amp;Нормализация звука</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Аудио CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1671"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Убрать шумы – &amp;обычный</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1672"/>
        <source>Denoise &amp;soft</source>
        <translation>Убрать шумы – &amp;мягкий</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>Denoise o&amp;ff</source>
        <translation>Убрать шумы – &amp;выключено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>&amp;Использовать SSA/ASS</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Двойной размер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1514"/>
        <source>S&amp;ize -</source>
        <translation>Р&amp;азмер –</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1515"/>
        <source>Si&amp;ze +</source>
        <translation>Ра&amp;змер +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>Add &amp;black borders</source>
        <translation>Добавить &amp;чёрные полосы</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Про&amp;граммное масштабирование</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1517"/>
        <source>Enable &amp;closed caption</source>
        <translation>&amp;Скрытые субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1518"/>
        <source>&amp;Forced subtitles only</source>
        <translation>&amp;Только форсированные</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Reset video equalizer</source>
        <translation>Сброс видеоэквалайзера</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1745"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation>ROSA Media Player – отчёт rosa-media-player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4456"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>Неожиданное завершение MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4457"/>
        <source>Exit code: %1</source>
        <translation>Код завершения: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4478"/>
        <source>MPlayer failed to start.</source>
        <translation>Ошибка запуска MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4479"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Провертье путь к MPlayer в настройках.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4483"/>
        <source>MPlayer has crashed.</source>
        <translation>Сбой MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4484"/>
        <source>See the log for more info.</source>
        <translation>Смотрите отчёт для подробной информации.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1636"/>
        <source>&amp;Rotate</source>
        <translation>По&amp;ворот</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Off</source>
        <translation>О&amp;тключен</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>На 90° по часовой стрелке с &amp;отражением</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>На 90° &amp;по часовой стрелке</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>На 90° п&amp;ротив часовой стрелки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1678"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>На 90° против часовой &amp;стрелки с отражением</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Show context menu</source>
        <translation>Показать контестное меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3256"/>
        <source>Multimedia</source>
        <translation>Мультимедиа</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1491"/>
        <source>E&amp;qualizer</source>
        <translation>&amp;Эквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Reset audio equalizer</source>
        <translation>Сброс аудиоэквалайзера</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1522"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>П&amp;оиск субтитров на OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1523"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Загрузить су&amp;бтитры на OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1651"/>
        <source>&amp;Auto</source>
        <translation>&amp;Авто</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>Speed -&amp;4%</source>
        <translation>Скор&amp;ость –4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>&amp;Speed +4%</source>
        <translation>Скоро&amp;сть +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed -&amp;1%</source>
        <translation>&amp;Скорость –1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>S&amp;peed +1%</source>
        <translation>С&amp;корость +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1641"/>
        <source>Scree&amp;n</source>
        <translation>&amp;Экран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1681"/>
        <source>&amp;Default</source>
        <translation>По &amp;умолчанию</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Next video</source>
        <translation>Следующий видеофайл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1615"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1685"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Дорожка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3858"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Предупреждение: Используется старая версия MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3864"/>
        <source>Please, update your MPlayer.</source>
        <translation>Пожалуйста, обновите ваш MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3866"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Это предупреждение больше не будет показано)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next aspect ratio</source>
        <translation>Следующее соотношение сторон</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1473"/>
        <source>Pre&amp;view...</source>
        <translation>Предпрос&amp;мотр...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1732"/>
        <source>DVD &amp;menu</source>
        <translation>DVD-&amp;меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1734"/>
        <source>DVD &amp;previous menu</source>
        <translation>&amp;Предыдущее DVD-меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>DVD menu, move up</source>
        <translation>DVD-меню, вверх</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1729"/>
        <source>DVD menu, move down</source>
        <translation>DVD-меню, вниз</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1730"/>
        <source>DVD menu, move left</source>
        <translation>DVD-меню, влево</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1731"/>
        <source>DVD menu, move right</source>
        <translation>DVD-меню, вправо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>DVD menu, select option</source>
        <translation>DVD-меню, выбрать</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1735"/>
        <source>DVD menu, mouse click</source>
        <translation>DVD-меню, щелчок мыши</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>Set dela&amp;y...</source>
        <translation>Установить &amp;задержку...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3556"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Задержка аудио (в миллисекундах):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4049"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4191"/>
        <source>Jump to %1</source>
        <translation>Перейти к %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1520"/>
        <source>Subtitle &amp;visibility</source>
        <translation>Отобра&amp;жать субтитры</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1580"/>
        <source>Next wheel function</source>
        <translation>Следующая функция колеса</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1721"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>П&amp;рограмма</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <location filename="../basegui.cpp" line="1429"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Редактировать...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1432"/>
        <source>Next TV channel</source>
        <translation>Следующий ТВ-канал</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1433"/>
        <source>Previous TV channel</source>
        <translation>Предыдущий ТВ-канал</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1434"/>
        <source>Next radio channel</source>
        <translation>Следующий канал радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1435"/>
        <source>Previous radio channel</source>
        <translation>Предыдущий канал радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1601"/>
        <source>&amp;TV</source>
        <translation>&amp;ТВ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1605"/>
        <source>Radi&amp;o</source>
        <translation>&amp;Радио</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1430"/>
        <location filename="../basegui.cpp" line="1431"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Перейти...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1370"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Видеофильтры отключены при использовании vdpau</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>Fli&amp;p image</source>
        <translation>Пере&amp;вернуть картинку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Show filename on OSD</source>
        <translation>Отображать имя файла в OSD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1583"/>
        <source>Toggle deinterlacing</source>
        <translation>Переключить режим удаления &quot;гребёнки&quot;</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation>ROSA Media Player всё ещё запущен</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Убрать</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Восстановить</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>В&amp;ыход</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Список</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation>Панель управления</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation>00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="83"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3142"/>
        <source>Brightness: %1</source>
        <translation>Яркость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3159"/>
        <source>Contrast: %1</source>
        <translation>Контрастность: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3175"/>
        <source>Gamma: %1</source>
        <translation>Гамма: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3191"/>
        <source>Hue: %1</source>
        <translation>Оттенок: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3207"/>
        <source>Saturation: %1</source>
        <translation>Насыщенность: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3359"/>
        <source>Volume: %1</source>
        <translation>Громкость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4325"/>
        <source>Zoom: %1</source>
        <translation>Увеличение: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3497"/>
        <location filename="../core.cpp" line="3515"/>
        <source>Font scale: %1</source>
        <translation>Масштаб шрифта: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4179"/>
        <source>Aspect ratio: %1</source>
        <translation>Соотношение сторон: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4595"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Обновление кэша шрифтов. Это может занять несколько секунд...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3408"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Задержка субтитров: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3428"/>
        <source>Audio delay: %1 ms</source>
        <translation>Aудио задержка: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3272"/>
        <source>Speed: %1</source>
        <translation>Скорость: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="199"/>
        <source>Connecting to %1</source>
        <translation>Соединение с %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="203"/>
        <source>Unable to retrieve youtube page</source>
        <translation>Невозможно извлечь страницу youtube</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="207"/>
        <source>Unable to locate the url of the video</source>
        <translation>Невозможно определить url видео</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3569"/>
        <source>Subtitles on</source>
        <translation>Субтитры включены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3571"/>
        <source>Subtitles off</source>
        <translation>Субтитры отключены</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4230"/>
        <source>Mouse wheel seeks now</source>
        <translation>Колесо мыши: перемотка</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4233"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Колесо мыши: громкость</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4236"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Колесо мыши: масштабироавние</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4239"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Колесо мыши: скорость</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1205"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Скриншот не получен, каталог не настроен</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1221"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Скриншоты не получены, каталог не настроен</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2862"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>Маркер &quot;A&quot; установлен в %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2881"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>Маркер &quot;B&quot; установлен в %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2899"/>
        <source>A-B markers cleared</source>
        <translation>Маркеры A-B очищены</translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation>Формат выходного файла:</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation>Версия ffmpeg, установленная на вашем компьютере, не поддерживает кодек libmp3lame. Для возможности использования функции извлечения аудиодорожки установите ffmpeg с поддержкой libmp3lame.</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation>Невозможно извлечь аудиодорожку ( возможно не хватает места на диске? )</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation>Невозможно извлечь аудиодорожку (код: %1)</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>Новый файл &quot;%1&quot; сохранен в каталоге %2</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation>Извлечь аудио</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation>Формат выходного файла:</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation>mp3</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation>ogg</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation>Извлечь</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to ROSA Media Player</source>
        <translation type="obsolete">Welcome to ROSA Media Player</translation>
    </message>
    <message>
        <source>A:%1</source>
        <translation type="obsolete">A:%1</translation>
    </message>
    <message>
        <source>B:%1</source>
        <translation type="obsolete">B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="320"/>
        <source>&amp;Video info</source>
        <translation>Инфор&amp;мация о видео</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="321"/>
        <source>&amp;Frame counter</source>
        <translation>С&amp;чётчик кадров</translation>
    </message>
    <message>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation type="obsolete">%1x%2 %3 fps</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Скрыть отчёт</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Показать отчёт</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>Ошибка MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation>Значок</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation>Редактор списков избранного</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation>Список избранного</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Вы можете редактировать, удалять, сортировать и добавлять новые пункты. Двойной клик на ячейке для редактирования её содержимого.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation>Выбрать файл значка</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation>&amp;Добавить</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>&amp;Удалить</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation>Удалить &amp;все</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation>В&amp;верх</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation>Перейти к элементу</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Введите номер элемента списка для перехода:</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Загрузка...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Загрузка %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation>ROSA Media Player – Параметры файла</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Информация</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Демультиплексор</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>В&amp;ыберите демультиплексор для воспроизведения этого файла:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>В&amp;идео</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>Вы&amp;берите видео кодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>А&amp;удио</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>Выб&amp;ерите аудио кодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>Настройки &amp;MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Дополнительные параметры Mplayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Здесь можно указать дополнительные параметры для MPlayer.
Указывайте их, разделяя пробелами.
Например: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Настройки:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Также Вы можете передать дополнительные фильтры видео.
Разделяйте их запятой. Не используйте пробелы!
Пример: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>&amp;Видео фильтры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Аудио фильтры. Используются аналогично видео фильтрам.
Пример: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Аудио &amp;фильтры:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="140"/>
        <source>Apply</source>
        <translation>Применить</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation>добавление шума</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation>смазывание границ квадратов</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation>нормальное понижение шумов</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation>мягкое понижение шумов</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation>нормализация громкости</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation>Http</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Включить/отключить использование прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation>Имя прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation>Порт прокси.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Если прокси требует аутентификации, укажите имя пользователя.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Пароль для прокси. &lt;b&gt;Внимание:&lt;/b&gt; пароль будет сохранён в виде текста в конфигурационном файле.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation>Выберите тип прокси, который будет использоваться.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation>Дополнительные настройки</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation>Прокси</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Включить прокси</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation>&amp;Хост:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation>&amp;Порт:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation>&amp;Имя пользователя:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation>&amp;Пароль:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation>&amp;Тип:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Файлы</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Загружено</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Копировать ссылку в буфер обмена</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>Ошибка загузки: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>Соединение с %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>Загрузка...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Завершено.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 файлов доступно</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Ошибка обработки полученных данных.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Найти субтитры</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Субтитры для</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Язык:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Обновить</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Субтиры сохранены как %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation>
            <numerusform>%1 субтитр извлечен</numerusform>
            <numerusform>%1 субтитра извлечено</numerusform>
            <numerusform>%1 субтитров извлечено</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>Файл %1 существует, перезаписать?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Не удалось сохранить загруженный
файл в каталоге %1
Проверьте права на этот каталог.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation>Ошибка загрузки</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation>Временный файл %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Настройки</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Основная информация</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 КБ (%2 МБ)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>Адрес</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Продолжительность</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Демультиплексор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Исполнитель</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Дорожка</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Авторское право</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Примечание</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Программа</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Информация о клипе</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Видео</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Разрешение экрана</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Соотношение сторон</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Скорость</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 кб/с</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Кадров в секунду</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Выбранный кодек</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Исходный Аудио-поток</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Каналы</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Звуковые дорожки</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Язык</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>ничего</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>№</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Название потока</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Адрес потока</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation>Rosa Media Player – Воспроизвести DVD из каталога</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Вы можете открыть DVD с жесткого диска. Выберите каталог, содержащий VIDEO_TS и AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Обзор...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation>Rosa Media Player – укажите версию MPlayer</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation>Rosa Media Player не может определить используемую вами версию MPlayer.</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>Версия, полученная от MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Пожалуйста, &amp;выберите правильную версию:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 или старше</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 или новее</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation>Rosa Media Player – укажите адрес</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;Адрес:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>&amp;Cписок воспроизведения</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="34"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Если опция отмечена, адрес будет воспринят как список: он будет открыть как текст и будут воспроизведены адреса из него.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Абхазский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Африкаанс</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Амхарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Арабский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Ассамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Аймара</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Азербайджанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Башкирский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Болгарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Бихари</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Бислама</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Бенгальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Тибетский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Бретонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Каталонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Корсиканский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Чешский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Валлийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Датский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Греческий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Английский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Эсперанто</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Испанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Эстонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Баскский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Персидский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Финский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Фарерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>Французский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Фризский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Ирландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Галийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Гуарани</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Гуджарати</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Хауса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Хинди</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Хорватский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Венгерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Армянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Интерлингва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Индонезийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Интерлингва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Ирландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Итальянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Инуктитут</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Японский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Яванский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Грузинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Казахский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Гренландский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Каннада</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Корейский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Кашмирский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Курдский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Киргизский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Латинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Лингала</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Литовский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Латвийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Малагасийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Маори</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Македонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Малаялам</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Монгольский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Молдавский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Маратхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Малайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Мальтийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Бирманский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Науру</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Непальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Немецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Норвежский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Окситанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Ория</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Польский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Португальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Кечуа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Румынский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Русский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Киньяруанда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Санскрит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Синдхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Словацкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Словенский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Шона</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Сомалийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Албанский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Сербский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Суданский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Шведский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Суахили</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Тамил</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Телугу</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Таджикский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Тайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Тиграи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Туркменский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Тагальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Турецкий</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Тсонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Татарский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Тви</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Уйгурский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Украинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Урду</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Узбекский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Вьетнамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Волоф</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Коса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Идиш</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Йоруба</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Чжуан</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Китайский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Зулусский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Португальский (Бразилия)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Португальский (Португалия)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Китайский упрощённый</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Китайский традиционный</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Юникод</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Восточноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Восточноевропейская с Евро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Славянская/центральноевропейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Эсперанто, Галисийская, Мальтийская, Турецкая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Старая Балтийская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Кириллица</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Греческая новая</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Балтийская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Кельтская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Иврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Украинская, Белорусская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Китайская упрощенная</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Китайская традиционная</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Японская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Корейская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Тайская</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Кириллица Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Славянская/центральноевропейская Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Арабская Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation>Авестийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation>Акан</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation>Арагонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation>Аварский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation>Белорусский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation>Бамана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation>Боснийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation>Чеченский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation>Кри</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation>Церковный</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation>Чувашский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation>Мальдивский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation>Дзонг-кэ</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation>Эве</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation>Фула</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation>Фиджийский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation>Гойдельский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation>Мэнский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation>Хири-моту</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation>Гаитянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation>Гереро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation>Чаморро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation>Игбо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation>Сычуаньский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation>Инуитский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation>Идо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation>Конго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation>Кикуйю</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation>Кваньяма</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation>Кхмерский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation>Канури</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation>Коми</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation>Корнский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation>Люксембургский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation>Луганда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation>Лимбургский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation>Лаосский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation>Луба-Катанга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation>Маршалльский</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Букмол</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation>Ндебеле</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation>Ндонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation>Навахо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation>Ньянджа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation>Оджибва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation>Оромо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation>Осетинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation>Панджаби</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation>Пали</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation>Пушту</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation>Романшский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation>Рунди</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation>Сардинский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation>Саамский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation>Санго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation>Сингальский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation>Свати</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation>Сесото</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation>Тсвана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation>Таитянский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation>Венда</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation>Волапюк</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation>Валлонский</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation>Новогреческий язык Windows</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Выберите имя файла для сохранения</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Файл уже существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Невозможно сохранить отчёт</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Отчёты</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Окно отчёта</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Сохранить</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Копировать в буфер обмена</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрыть</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Name</source>
        <translation>Имя</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Length</source>
        <translation>Продолжительность</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Play</source>
        <translation>Воспро&amp;изведение</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="386"/>
        <source>&amp;Edit</source>
        <translation>&amp;Редактировать</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="829"/>
        <location filename="../playlist.cpp" line="849"/>
        <source>Playlists</source>
        <translation>Список</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="827"/>
        <source>Choose a file</source>
        <translation>Выбрать файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="847"/>
        <source>Choose a filename</source>
        <translation>Выберите имя файла</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="861"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписать?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="862"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 существует.
Перезаписать?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1080"/>
        <source>Multimedia</source>
        <translation>Мультимедиа</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1081"/>
        <source>All files</source>
        <translation>Все файлы</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>Select one or more files to open</source>
        <translation>Выберите один или более файлов</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1142"/>
        <source>Choose a directory</source>
        <translation>Выбрать каталог</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1367"/>
        <source>Edit name</source>
        <translation>Изменить имя</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1368"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Введите имя, которое будет соответствовать в списке этому файлу:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="346"/>
        <source>&amp;Load</source>
        <translation>&amp;Загрузить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Save</source>
        <translation>&amp;Сохранить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="351"/>
        <source>&amp;Next</source>
        <translation>С&amp;ледующий</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="352"/>
        <source>Pre&amp;vious</source>
        <translation>П&amp;редыдущий</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>Move &amp;up</source>
        <translation>Переместить в&amp;верх</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>Move &amp;down</source>
        <translation>Переместить в&amp;низ</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>&amp;Repeat</source>
        <translation>Пов&amp;торить</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="372"/>
        <source>S&amp;huffle</source>
        <translation>Пере&amp;мешать</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="377"/>
        <source>Add &amp;current file</source>
        <translation>Добавить &amp;текущий файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="378"/>
        <source>Add &amp;file(s)</source>
        <translation>Добавить &amp;файл(ы)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Add &amp;directory</source>
        <translation>Добавить &amp;каталог</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="382"/>
        <source>Remove &amp;selected</source>
        <translation>Убрать в&amp;ыбранные</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>Remove &amp;all</source>
        <translation>Убрать в&amp;се</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="390"/>
        <source>Add...</source>
        <translation>Добавить...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="392"/>
        <source>Remove...</source>
        <translation>Убрать...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="396"/>
        <source>ROSA Media Player - Playlist</source>
        <translation>Rosa Media Player – Список</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="891"/>
        <source>Playlist modified</source>
        <translation>Список воспроизведения изменен</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="892"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Есть несохранённые изменения, желаете сохранить список воспроизведения?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Preferences</source>
        <translation>Настройки</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Список – Настройки</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Выберите эту опцию, если вы хотите, чтобы при добавлении каталога подкаталоги тоже добавлялись рекурсивно. Иначе будут добавлены только файлы из текущего каталога.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>&amp;Добавлять файлы из каталогов рекурсивно</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Выберите эту опцию, чтобы извлечь из добавляемых в список файлов некоторую информацию. Это позволяет отображать имя (если доступно) и информацию о файлах. Иначе эта информация не будет доступна, пока файл не начнёт воспроизводиться. Будьте осторожны: эта опция может замедлить работу, особенно при большом количестве добавляемых файлов.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Автоматически получать &amp;сведения о добавляемых файлах</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>Сохранять &amp;копию списка воспроизведения при выходе</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>&amp;Воспроизводить файлы при запуске</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Внимание</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Не все файлы могут быть ассоциированы. Проверье свои права и попытайтесь снова.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Типы файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Выбраь все типы файлов в списке</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Ничего не выбирать в списке</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Список типов файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation>Отметьте типы файлов, которые хотите связать с ROSA Media Player. После нажатия Применить, отмеченные типы файлов будут ассоциированы с ROSA Media Player. Если убрать отметку, файловая ассоциация будет восстановлена.</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Типы файлов</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation>Медиа файлы, ассоциированные с ROSA Media Player:</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Ничего не выбирать</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Ничего не выбирать</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation>(sp)&lt;b&gt;Примечание:&lt;/b&gt; (Восстановление ассоциаций не работает в Windows Vista).</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="82"/>
        <source>General</source>
        <translation>Главное</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="338"/>
        <source>Media settings</source>
        <translation>Настройки мультимедиа</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="112"/>
        <source>&amp;Disable screensaver</source>
        <translation>Отключить &amp;хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="246"/>
        <source>Cha&amp;nnels by default:</source>
        <translation>Каналы по &amp;умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="119"/>
        <source>YouTube support (experimental)</source>
        <translation>Поддержка YouTube (экспериментальная)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="49"/>
        <source>Preferred video &amp;quality:</source>
        <translation>Предпочтительное &amp;качество:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="129"/>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>Main window</source>
        <translation>Главное окно</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="137"/>
        <source>A&amp;utoresize:</source>
        <translation>Автоматически изменять &amp;размер:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="154"/>
        <source>Never</source>
        <translation>Никогда</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="159"/>
        <source>Whenever it&apos;s needed</source>
        <translation>Когда это нужно</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="164"/>
        <source>Only after loading a new video</source>
        <translation>Только для нового видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="187"/>
        <source>R&amp;emember position and size</source>
        <translation>Запоминать пози&amp;цию и размер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="197"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Instances</source>
        <translation>Экземпляры</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="206"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation>Запускать только о&amp;дну копию ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="216"/>
        <location filename="../prefgeneral.cpp" line="399"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="225"/>
        <source>&amp;Volume normalization by default</source>
        <translation>&amp;Нормализация громкости по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Disable screensaver</source>
        <translation>Подавить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation>По умолчанию ROSA Media Player запоминает настройки каждого воспроизводимого файла (звуковая дорожка, громкость, фильтры...). Отключите эту опцию, если она вам не нравится.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Automatically add files to playlist</source>
        <translation>Автоматически добавлять файлы в список</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation>Если эта опция отмечена, каждый раз при открытии файла, ROSA Media Player будет первым делом очищать список и затем добавлять файл в него. Касательно DVD, CD и VCD, все заголовки на диске будут добавлены в плейлист.</translation>
    </message>
    <message>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="obsolete">Если эта опция отмечена, ROSA Media Player попытается предотвратить появление хранителя экрана во время воспроизведения видеофайла. Скринсейвер разрешён только при воспроизведении аудиофайлов или в режиме паузы. Эта опция работает только если окно ROSA Media Player активно.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="340"/>
        <source>Remember settings</source>
        <translation>Запомнить настройки</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="77"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>За&amp;поминать настройки всех файлов (звук, субтитры...)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="105"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation>&amp;Автоматически добавлять файлы в список</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="345"/>
        <source>Close when finished</source>
        <translation>Закрыть по окончании воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="346"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Если выбрано, то главное окно будет автоматически закрыто по окончании воспроизведения файла или списка.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="98"/>
        <source>2 (Stereo)</source>
        <translation>2 (Стерео)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="99"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="100"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 окружение)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="91"/>
        <source>&amp;Pause when minimized</source>
        <translation>Пауза при &amp;минимизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="349"/>
        <source>Pause when minimized</source>
        <translation>Пауза при минимизации</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="371"/>
        <source>Channels by default</source>
        <translation>Каналы по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="84"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Закрыть по окончании воспроизведения</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="350"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>При включении этой опции, файл будет поставлен на паузу при минимизации главного окна. После восстановления окна воспроизведение продолжится.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="384"/>
        <source>Autoresize</source>
        <translation>Автоматический размер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation>Главное окно может изменять размер автоматически. Выберите предпочтительную настройку.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Remember position and size</source>
        <translation>Запоминать позицию и размер</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation>Если настройка выбрана, позиция и размер видео будут сохранены и восстановлены при следующем запуске ROSA Media Player.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation>Использовать только одну копию ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="396"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation>Выберите эту опцию, если хотите использовать уже запущенную копию ROSA Media Player при открытии новых файлов.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="401"/>
        <source>Volume normalization by default</source>
        <translation>Нормализация громкости по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="402"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation>Увеличивает громкость без искажений звука.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="362"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Отметьте эту опцию, чтобы отключить хранитель экрана во время воспроизведения.&lt;br&gt; Он будет включен снова по окончании воспроизведения.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="372"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Запрашивает количество каналов воспроизведения. MPlayer просит декодер декодировать звук в указанное количество каналов. Выполнение задачи ложится на плечи декодера. Обычно это требуется только при воспроизведении видео с AC3 звуком (например DVD). В этом случае liba52 выполняет декодирование как обычно и корректно сводит аудио в запрошенное количество каналов. &lt;b&gt;ПРИМЕЧАНИЕ&lt;/b&gt;: Эта опция учитывается кодеками (AC3), фильтрами (окружение) и драверами вывода звука (как минимум OSS).</translation>
    </message>
    <message>
        <source>Switch screensaver off</source>
        <translation type="obsolete">Отключить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="103"/>
        <source>1080p</source>
        <translation>1080p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="104"/>
        <source>720p</source>
        <translation>720p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="105"/>
        <source>480p</source>
        <translation>480p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="106"/>
        <source>360p</source>
        <translation>360p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="107"/>
        <source>240p</source>
        <translation>240p</translation>
    </message>
    <message>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="obsolete">Эта опция отключает хранитель экрана перед началом воспроизведения файла и включает его по окончании воспроизведения. Если эта опция задействована, скринсевер не будет появляться даже при воспроизведении аудиофайлов или когда воспроизведение присостановлено.</translation>
    </message>
    <message>
        <source>Avoid screensaver</source>
        <translation type="obsolete">Предотвратить хранитель экрана</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="367"/>
        <source>Audio/video auto synchronization</source>
        <translation>Автосинхронизация звука/видео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="368"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Плавно подстраивает A/V-синхронизацию за счёт измерений задержки аудио.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="98"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Автоматическая &amp;синхронизация аудио/видео</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation>&amp;Звук:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation>Суб&amp;титры:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation>Выбрать предпочитаемый язык:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation>Ауди&amp;о:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation>Су&amp;бтитры:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation>Или указать номер дорожки:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation>Автозагрузка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation>С тем же именем, что и у фильма</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation>Подключать субтитры содержащие название фильма</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation>Все субтитры каталога</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation>&amp;Автозагрузка субтитров (*.srt, *.sub...):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation>Кодировка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation>&amp;Кодировка субтитров по умолчанию:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation>Субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation>Языковая дорожка и субтитры</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation>Предпочитаемый язык звуковой дорожки</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation>Предпочитаемый язык субтитров</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Здесь можно указать предпочитаемый язык для звуковых дорожек. Если воспроизводимое видео содержит несколько звуковых дорожек, то ROSA Media Player будет использовать ту из них, которая соответствует вашим предпочтениям.&lt;br&gt;Все сказанное верно для тех типов данных мультимедиа, которые содержат информацию о языке звуковых дорожек, таких как DVD или mkv.&lt;br&gt;Также можно использовать регулярные выражения. Например: &lt;b&gt;ru|rus&lt;/b&gt; означает, что будет выбрана звуковая дорожка, содержащая в названии языка &lt;i&gt;ru&lt;/i&gt; или &lt;i&gt;rus&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Здесь можно указать предпочитаемый язык для субтитров. Если проигрываемый фильм содержит субтитры на разных языках, то ROSA Media Player будет использовать те из них, которые соответствуют вашим предпочтениям.&lt;br&gt;Все сказанное верно для тех типов данных мультимедиа, которые содержат информацию о языке субтитров, таких как DVD или mkv.&lt;br&gt;Также можно использовать регулярные выражения. Например: &lt;b&gt;ru|rus&lt;/b&gt; означает, что будут выбраны субтитры, содержащие в названии языка &lt;i&gt;ru&lt;/i&gt; или &lt;i&gt;rus&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation>Аудио дорожка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Указывает аудио дорожку по умолчанию, используемую по умолчанию для новых файлов. Если дорожка не существует, будет использована первая. &lt;br&gt;&lt;b&gt;Примечание:&lt;/b&gt; опция &lt;i&gt;предпочитаемый язык&lt;/i&gt; более приоритетна.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation>Дорожка субтитров</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Указывает дорожку субтитров по умолчанию, используемую по умолчанию для новых файлов. Если дорожка не существует, будет использована первая. &lt;br&gt;&lt;b&gt;Примечание:&lt;/b&gt; опция &lt;i&gt;Предпочтительный язык субтитров&lt;/i&gt; более приоритетна.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation>Выберите метод автозагрузки субтитров.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation>Кодировка субтитров по умолчанию</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation>Выберите кодировку, которая будет использована для файлов субтитров по умолчанию.</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>ROSA Media Player - Help</source>
        <translation type="obsolete">ROSA Media Player – Помощь</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="161"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Применить</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Помощь</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation>ROSA Media Player – Настройки</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>будет показанно это сообщение, после чего приложение закроется.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>главное окно будет закрыто после окончания воспроизведения.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>пытается соединиться с другим запущенным экземпляром и послать ему заданное действие. Пример: -send-action pause Остальные параметры (если есть) будут игнорироваться и приложение будет закрыто. При успешном выполнении задачи возвращается 0, или 1 в обратном случае.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>action_list – это список действий разделенный пробелами. Эти действия будут выполняться после загрузки файла в заданной вами последовательности. Для действий с переменными значениями можно использовать true или false в качестве параметров. Например: -actions &quot;fullscreen compact true&quot;. Кавычки необходимы в случае, если используется более одного действия.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation>&apos;media&apos; – любой вид файла, который может открыть ROSA Media Player. Это может быть локальный файл, DVD (т.е. dvd://1), интернет-поток (т.е. mms://...) или локальный список (плейлист) в формате m3u или pls. Если используется опция -playlist, это означает, что ROSA Media Player передаст эту опцию MPlayer-у и её воспримет он, а не ROSA Media Player.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>Если уже запущен экземпляр программы ,то файлы мультимедиа будут добавлены в существующий список. Если же нет – опция будет проигнорирована и файлы будут открыты в новом экземпляре.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>Главное окно не будет закрыто, по окончании файла/списка.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>Видео будет воспроизведиться в полноэкранном режиме.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>Видео будет воспроизводиться в оконном режиме.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Восстанавливает старые ассоциации и очищает реестр.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Использование:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>каталог</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>имя_действия</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>список_действий</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>открывает интерфейс по умолчанию.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>файл_субтитров</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>Указывает файл субтитров, который будет загружен для первого видеофайла.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation>
            <numerusform>%1 секунда</numerusform>
            <numerusform>%1 секунды</numerusform>
            <numerusform>%1 секунд</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation>
            <numerusform>%1 минута</numerusform>
            <numerusform>%1 минуты</numerusform>
            <numerusform>%1 минут</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 и %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>отключено</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>авто</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>неизвестно</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation>ширина</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation>высота</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation>определяет каталог, в котором rosa-media-player будет сохранять свои конфигурационные файлы (rosamp.ini, rosamp_files.ini...)</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>указывает координаты верхнего левого угла главного окна приложения.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation>указывает размер главного окна.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="467"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation>ROSA Media Player запущен в %1</translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation>Добавить в ROSA Media Player</translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>Ошибка ZIP/UNZIP API %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="153"/>
        <source>Source #</source>
        <translation>Источник #</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="153"/>
        <source>Name: </source>
        <translation>Имя: </translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="190"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation>Не удалось начать запись. Проверьте, установлен ли ffmpeg.</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="193"/>
        <source>Unknown error in recording occured</source>
        <translation>Неизвестная ошибка записи</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="196"/>
        <source>Sorry, recording crashed</source>
        <translation>Извините, ошибка записи</translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="63"/>
        <source>/Screencast - </source>
        <translation>/Экранная презентация - </translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="66"/>
        <source>\Screencast-</source>
        <translation>\Экранная презентация-</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation>Экранная презентация успешно сохранена в %1</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="118"/>
        <source>Length: %1
Size: %2
</source>
        <translation>Длина: %1
Размер: %2
</translation>
    </message>
</context>
<context>
    <name>ScreencastDialog</name>
    <message>
        <location filename="../screencast.ui" line="20"/>
        <source>Video capture</source>
        <translation>Запись экранной презентации</translation>
    </message>
    <message>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="obsolete">Будет произведена запись видео с экрана. На время записи видео проигрыватель будет свернут в системный лоток. Для остановки записи нажмите на красный круглый значoк в системном лотке.</translation>
    </message>
    <message>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.
If you want to record from the line-out, the need to restart pulseaudio (can cause it to stop the sound).</source>
        <translation type="obsolete">Будет произведена запись видео с экрана. На время записи видео проигрыватель будет свернут в системный лоток. Для остановки записи нажмите на красный круглый значoк в системном лотке.
Если вы хотите записать звук с линейного выхода, то потребуется перезапуск pulseaudio (может привести к остановке воспроизведения звука).</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="98"/>
        <source>Record audio:</source>
        <translation>Записать звук:</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="65"/>
        <source>Start capture</source>
        <translation>Начать</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="75"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="34"/>
        <location filename="../screencast.cpp" line="99"/>
        <source>not recording</source>
        <translation>не записывать</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="82"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Будет произведена запись видео с экрана. На время записи видео проигрыватель будет свернут в системный лоток. Для остановки записи нажмите на красный круглый значoк в системном лотке.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="44"/>
        <source>line-out</source>
        <translation>линейный выход</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="39"/>
        <source>microphone</source>
        <translation>микрофон</translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Будет произведена запись видео с экрана. На время записи видео проигрыватель будет свернут в системный лоток. Для остановки записи нажмите на красный круглый значoк в системном лотке.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="43"/>
        <source>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;WARNING: The audio subsystem needs to be restarted before recording from the line-out. It may cause interruption of currently playing sound.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;ВНИМАНИЕ: Для записи звука с линейного выхода потребуется перезапуск звуковой системы, что может остановить работу всех уже работающих мультимедийных приложений.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;If you want to record from the line-out the audio subsystem will be restarted (can cause one-time sound playback interruption).&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="obsolete">&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;Если вы хотите записать звук с линейного выхода, то потребуется перезапуск звуковой подсистемы (может привести к остановке воспроизведения звука).&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="48"/>
        <source>&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>значок</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>метка</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Изменить сочетание клавиш</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Нажмите клавиши, сочетание которых вы хотите использовать</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Захват</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Горячая клавиша снимка с экрана</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation>Начальное время обрезки должно быть меньше конечного</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation>/Видео_</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation>Невозможно обрезать видео ( возможно не хватает места на диске? )</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation>Невозможно обрезать видео (код: %1)</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>Новый файл &quot;%1&quot; сохранен в каталоге %2</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation>Обрезать видео</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation>Укажите временной интервал:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation>С:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation>HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation>Установить текущее время воспроизведения</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation>По:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation>Обрезать</translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Выбор субтитров</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Этот архив содержит более одного файла субтиров. Выберите необходимый вам для распаковки.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Выбрать все</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Ничего не выбирать</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="100"/>
        <source>Channel editor</source>
        <translation>Редактор каналов</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="101"/>
        <source>TV/Radio list</source>
        <translation>Список ТВ/Радио</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Перейти к:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Авто</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>Нет</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="74"/>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Contrast</source>
        <translation>Контрастность</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Brightness</source>
        <translation>Яркость</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Hue</source>
        <translation>Оттенок</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Saturation</source>
        <translation>Насыщенность</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Gamma</source>
        <translation>Гамма</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <source>&amp;Reset</source>
        <translation>Сб&amp;рос</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Установки по умолчанию</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Использовать данные настройки по умолчанию для новых файлов.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Установить все значения в ноль.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="71"/>
        <source>Video Equalizer</source>
        <translation>Видеоэквалайзер</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="122"/>
        <source>Information</source>
        <translation>Информация</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="123"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Текущие параметры были сохранены как используемые по умолчанию.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation>Предпросмотр видео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation>Сгенерировано ROSA Media Player-ом</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation>Создание миниатюр...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation>Размер: %1 MB</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation>Продолжительность: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation>Сохранить файл</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation>Ошибка сохранения файла</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не может быть сохранен</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation>Ошибка</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>При создании миниатюр произошла следующая ошибка:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>Не удалось создать временную папку (%1)</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>Процесс mplayer не был запущен</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation>Разрешение: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation>Формат видео: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation>Кадров в секунду: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation>Соотношение сторон: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>Не удалось загрузить файл %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation>Не указано имя файла</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Процесс mplayer не был запущен при получении информации о видео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation>Длительность видео 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>Файл %1 не существует</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation>Изображения</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation>Нет информации</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation>%1 кб/с</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation>Видео битрейт: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation>Аудио битрейт: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation>Частота выборки аудио: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation>По умолчанию</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation>Предпросмотр</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation>&amp;Файл:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation>Стол&amp;бцы:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation>Стро&amp;ки:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation>&amp;Соотношение сторон:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation>Время &amp;первой миниатюры:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation>&amp;Максимальная ширина:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>Окно предпросмотра будет создано для указанного здесь файла.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Миниатюры будут сгруппированы в таблицу.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Эта опция определяет столбцов в таблице.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Эта опция определяет количество строк в таблице.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Если вы отметите эту опцию, время будет отображаться внизу каждой миниатюры.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Если соотношение сторон видео неправильное, здесь можно указать другое.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Обычно первые кадры чёрные, поэтому неплохой идеей будет пропустить несколько секунд в начале видео. Эта опция определяет, сколько секунд будет пропущено.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Эта опция указывает максимальную ширину в пикселах, которую будет иметь сгенерированное изображение.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Некоторые кадры будут извлечены из видео для создания миниатюр. Здесь вы можете выбрать формат извлекаемых изображений. PNG может дать лучшее качество.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>&amp;Добавить время на миниатюрах</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation>Извлечь кадры &amp;как</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Укажите здесь устройство DVD или каталог с образом DVD.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation>Устройст&amp;во DVD:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Запоминать каталог для &amp;сохранения предпросмотра</translation>
    </message>
</context>
<context>
    <name>VideoSearch</name>
    <message>
        <location filename="../videosearch.cpp" line="158"/>
        <source>Context menu</source>
        <translation>Меню</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="322"/>
        <source>&lt;b&gt;Not enough free space to save video file&lt;b&gt;</source>
        <translation>&lt;b&gt;Недостаточно свободного места на диске для записи видеофайла&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="323"/>
        <source>Increase free space and try again</source>
        <translation>Освободите место на диске и повторите попытку снова</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="326"/>
        <source>Error downloading video clip from YouTube</source>
        <translation>Ошибка загрузки видеоролика с YouTube</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="391"/>
        <source>&amp;Play</source>
        <translation>Воспро&amp;извести</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="392"/>
        <source>&amp;Add to play list</source>
        <translation>&amp;Добавить в список воспроизведения</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="393"/>
        <source>&amp;Open video in browser...</source>
        <translation>&amp;Открыть в браузере...</translation>
    </message>
</context>
<context>
    <name>VideoSearchPanel</name>
    <message>
        <location filename="../videosearch.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="32"/>
        <source>Search:</source>
        <translation>Искать:</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="93"/>
        <source>Clear</source>
        <translation>Очистить</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="100"/>
        <source>More</source>
        <translation>Еще результаты</translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Громкость</translation>
    </message>
</context>
</TS>
