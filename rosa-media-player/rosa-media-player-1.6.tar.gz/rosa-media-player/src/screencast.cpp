#include "screencast.h"
#include "ui_screencast.h"

#include <QtCore/QProcess>
#include <QtCore/QFileInfo>

#include "preferences.h"
#include "global.h"

using namespace Global;


ScreencastDialog::ScreencastDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ScreencastDialog)
{
    ui->setupUi(this);

#ifdef Q_OS_WIN
    QStringList devs = getDshowAudioDevices();
    setAudioDevices(devs);
#endif
}

ScreencastDialog::~ScreencastDialog()
{
    delete ui;
}

#ifndef Q_OS_WIN
ScreencastDialog::AudioDeviceTypes ScreencastDialog::deviceSelected()
{
    return (ScreencastDialog::AudioDeviceTypes)(ui->audioDevices->currentIndex());
}

void ScreencastDialog::updateDescription(int pos)
{
    QString text = tr("<html><head/><body><p>Screen capture is starting now. "
                      "The player will be minimized to system tray at the time of video recording. "
                      "Click on the red round icon in system tray to stop the recording.</p>");

    if (pos == 2) {
        text += tr("<p><span style=\" color:#c00000;\">WARNING: The audio subsystem needs to be "
                   "restarted before recording from the line-out. It may cause interruption of currently "
                   "playing sound.</span></p>");
    }

    text += tr("</body></html>");
    ui->descriptionText->setText(text);
}

#else
QString ScreencastDialog::deviceSelected()
{
    if (ui->audioDevices->currentIndex() == 0)
        return QString();
    else
        return ui->audioDevices->currentText();
}

QStringList ScreencastDialog::getDshowAudioDevices()
{
    QProcess ffmpeg;
    QString name = pref->ffmpeg_bin;
    QFileInfo fi(name);
    if (fi.exists() && fi.isExecutable() && !fi.isDir()) {
        name = fi.absoluteFilePath();
    }
    // get list audio devices with ffmpeg
    ffmpeg.setProcessChannelMode(QProcess::MergedChannels);
    ffmpeg.start(name, QStringList() << "-list_devices" << "true" << "-f" << "dshow" << "-i" << "dummy");
    ffmpeg.waitForFinished();

    QStringList devs, strlist;
    QString str = QString::fromUtf8(ffmpeg.readAll().data());
    strlist = str.split("\r\n").filter("[dshow @");

    int pos = -1;
    foreach (const QString &s, strlist) {
        pos++;
        if (s.contains("DirectShow audio devices")) {
            break;
        }
    }
    if (pos != (-1)) { // audio devices found
        for (int i = pos + 1; i < strlist.count(); i++) {
            QString s = strlist[i].remove(QRegExp("\\[.*\\]\\s+"));
            s = s.remove("\"");
            devs << s;
        }
    }

    return devs;
}

void ScreencastDialog::setAudioDevices(const QStringList &devs)
{
    ui->audioDevices->clear();
    ui->audioDevices->addItem(tr("not recording"));
    foreach (const QString &s, devs) {
        ui->audioDevices->addItem(s);
    }
}
#endif
