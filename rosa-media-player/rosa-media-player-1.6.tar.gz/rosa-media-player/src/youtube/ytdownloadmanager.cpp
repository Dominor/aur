#include "ytdownloadmanager.h"

#include <QDebug>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QRegExp>
#include <QProcess>

#include "preferences.h"
#include "global.h"
#include "core.h"
#include "youtube/ytdownloadprocess.h"
#include "youtube/retrieveyoutubeurl.h"
#include "youtube/ytvideoitem.h"

using namespace Global;

YTDownloadManager::YTDownloadManager(QObject *parent) :
    QObject(parent),
    m_proc(0)
{    
}

YTDownloadManager::~YTDownloadManager()
{
    if (m_proc->isRunning()) {
        m_proc->close();
        QFile::remove(m_filePath);
    }
    delete m_proc;
}

void YTDownloadManager::startDownload(const YTVideoItem &item)
{
    if (m_proc)
        delete m_proc;
    m_proc = new YTDownloadProcess();
    connect(m_proc, SIGNAL(downloadProgress(int)), SIGNAL(downloadProgress(int)));
    connect(m_proc, SIGNAL(gotSize(long)), SLOT(checkDiskSpace(long)));
    connect(m_proc, SIGNAL(downloadFinished()), SLOT(downloadFinished()));
    connect(m_proc, SIGNAL(downloadFailed(YTDownloadManager::Error)),SLOT(downloadError(YTDownloadManager::Error)));

    QString title = item.data(YTVideoItem::Title).toString();
    //Check title
    QRegExp name_exp("[\\\\/\\>\\<\\:\\?\\!\\*\\|\\\"]"); //Check "/ \ | < > " * ? | : "
    while (name_exp.indexIn(title) != -1) {
        title.replace(name_exp.pos(),1,"_"); //replace invalid characters in title with '_'
    }
    QString type = item.data(YTVideoItem::Type).toString();
#ifndef Q_OS_WIN
    const char * XDG_DOWNLOADS_DIR = getenv("XDG_DOWNLOADS_DIR");
    if (XDG_DOWNLOADS_DIR != NULL) {
        m_filePath = QString(XDG_DOWNLOADS_DIR) + "/" + title + "." + type;
    } else
        m_filePath = QDesktopServices::storageLocation(QDesktopServices::MoviesLocation) + "/" + title + "." + type;
#else
    m_filePath = QDesktopServices::storageLocation(QDesktopServices::MoviesLocation) + "\\" + title + "." + type;
#endif

    QString wget_bin = pref->wget_bin;
    QFileInfo fi(wget_bin);
    if (fi.exists() && fi.isExecutable() && !fi.isDir()){
        wget_bin = fi.absoluteFilePath();
    }

    QString url = item.data(YTVideoItem::PreferredUrl).toString();

    m_proc->addArgument(wget_bin);
    m_proc->addArgument("-O");
    m_proc->addArgument(m_filePath);
    m_proc->addArgument(url);
    m_proc->start();
}

void YTDownloadManager::stopDownload()
{    
    m_proc->close();    
    QFile::remove(m_filePath);
}

void YTDownloadManager::downloadFinished()
{
    qDebug() << "YTDownloadManager::download success";
    emit downloadSuccess();
}

void YTDownloadManager::downloadError(YTDownloadManager::Error error)
{    
    if (QFile::exists(m_filePath))
        QFile::remove(m_filePath);
    emit downloadFailed(error);
}

void YTDownloadManager::processExited()
{
    delete m_proc;
}

void YTDownloadManager::checkDiskSpace(long size)
{
    QFileInfo fi( m_filePath);
    double fTotal, fFree;
    bool rc = getFreeTotalSpaceKb( fi.filePath(), fTotal, fFree );

    qDebug() << "Check space: needed - " << size/(1024*1024) << "MiB," << "available - "<< fFree/(1024) << "MiB";
    if (((size/1024) > fFree ) || (!rc))
    {
        stopDownload();
        emit downloadFailed(YTDownloadManager::NotEnoughSpace);
    }
}
