/*  ROSA Media Player
    ROSA Media Player. 

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef _OSPARSER_H_
#define _OSPARSER_H_

#include <QObject>
#include <QByteArray>
#include <QList>
#include <QDomDocument>

class OSSubtitle {
public:
	QString movie, releasename, link, iso639, language, date;
	QString format, comments, detail, rating, files, user;
};

class OSParser {

public:
	OSParser();
	~OSParser();

	bool parseXml(QByteArray text);

	QList<OSSubtitle> subtitleList() { return s_list; };

	static QString calculateHash(QString filename);

protected:
	QDomDocument dom_document;
	QList <OSSubtitle> s_list;
};

#endif

