/*  ROSA Media Player
    Julia Mineeva, Evgeniy Augin. Copyright (c) 2013 ROSA  <support@rosalab.ru>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/
#include "videosearch.h"

#include <QtCore/QDebug>
#include <QtCore/QBuffer>
#include <QtGui/QDesktopServices>
#include <QtGui/QPushButton>
#include <QtGui/QScrollBar>
#include <QtGui/QMenu>
#include <QtGui/QMessageBox>

#include "youtube/reply.h"
#include "youtube/request.h"
#include "youtube/requestmanager.h"
#include "youtube/ytvideoitemmodel.h"
#include "youtube/ytvideoitem.h"
#include "videoitemdelegate.h"
#include "core.h"
#include "remoteimageloader.h"
#include "myaction.h"
#include "playlist.h"
#include "global.h"
#include "preferences.h"

using namespace Global;

VideoSearch::VideoSearch(Core* core, Playlist *playlist, QWidget *parent)
    : QWidget(parent)
    , ui( new Ui::VideoSearchPanel )
    , m_core(core)
    , m_playlist(playlist)
{
    ui->setupUi(this);

    m_yt = new RetrieveYoutubeUrl(this);
    connect(m_yt, SIGNAL(gotPreferredUrl(const QString &)), this, SLOT(startDownload(const QString &)));

    m_videoModel = new YTVideoItemModel(this);

    m_imageLoader = new RemoteImageLoader(this);
    connect(m_imageLoader, SIGNAL(imageReady(QUrl, QImage)), SLOT(gotVideoThumbnail(QUrl, QImage)));

    m_requestManager = new RequestManager(this);
    connect(m_requestManager, SIGNAL(newVideoItems(QList<YTVideoItem *>)), SLOT(gotVideoItems(QList<YTVideoItem *>)));

    VideoItemDelegate *delegate = new VideoItemDelegate(this);
    connect(delegate, SIGNAL(downloadClicked(const QModelIndex &)), this, SLOT(startDownload(const QModelIndex &)));
    connect(delegate, SIGNAL(cancelClicked(const QModelIndex &)), this, SLOT(stopDownload(const QModelIndex &)));

    ui->lvVideos->setModel(m_videoModel);
    ui->lvVideos->setItemDelegate(delegate);
    ui->lvVideos->setContextMenuPolicy(Qt::CustomContextMenu);

//    connect(ui->lvVideos->verticalScrollBar(), SIGNAL(valueChanged(int)), SLOT(onSliderMoved(int)));
    connect(ui->lvVideos, SIGNAL(customContextMenuRequested(const QPoint &)), SLOT(showContextMenu(const QPoint &)));

    createActions();
    retranslateStrings();
}

VideoSearch::~VideoSearch()
{
    delete m_yt;
    delete m_videoModel;
    delete m_imageLoader;
    delete m_requestManager;
}

void VideoSearch::gotVideoItems(QList<YTVideoItem *> items)
{
    if (!m_videoModel)
        return;

    if (m_imageLoader) {
        QList<QUrl> images;
        foreach (YTVideoItem *item, items) {
            if (item) {
                images << item->data(YTVideoItem::SmallThumbnailUrl).toUrl();
            }
        }
        m_imageLoader->addImages(images);
        m_imageLoader->load();
    }

    m_videoModel->newVideoItems(items);
}

void VideoSearch::onReturnPressed()
{
    m_videoModel->clear();
    if (!ui->leSearchString->text().isEmpty()) {
        getVideo(ui->leSearchString->text());
    }
}

void VideoSearch::onItemClicked(QModelIndex index)
{
    if (m_core && index.isValid()) {

        QString url = index.data(YTVideoItem::VideoUrl).toString();
        if (!url.isEmpty()) {
            m_core->openStream(url);
        }
        if (m_playlist) {
            QString videoUrl = index.data(YTVideoItem::VideoUrl).toString();
            QString title = index.data(YTVideoItem::Title).toString();
            double duration = index.data(YTVideoItem::Duration).toDouble();
            m_playlist->clear();
            m_playlist->addItem(videoUrl, title, duration);
            m_playlist->getMediaInfo();
        }
    }
}

void VideoSearch::onSliderMoved(int value)
{
    if (value == ui->lvVideos->verticalScrollBar()->maximum()) {
        // post new request...
        searchMore();
    }
}

void VideoSearch::gotVideoThumbnail(QUrl url, QImage image)
{
    for (int i = 0; i < m_videoModel->rowCount(); i++) {
        if (m_videoModel->index(i).data(YTVideoItem::SmallThumbnailUrl).toUrl() == url) {
            m_videoModel->setData(m_videoModel->index(i), image, YTVideoItem::SmallThumbnail);
            break;
        }
    }
}

void VideoSearch::showContextMenu(const QPoint &pos)
{
    if (m_videoModel->rowCount() == 0)
        return;

    QModelIndex index = ui->lvVideos->indexAt(pos);
    if (!index.isValid())
        return;

    QMenu contextMenu(tr("Context menu"), this);
    contextMenu.addAction(m_playAct);
    contextMenu.addAction(m_addPlaylistAct);
    contextMenu.addAction(m_openBrowserAct);
    contextMenu.exec(mapToGlobal(pos));
}

void VideoSearch::playVideo()
{
    QModelIndex index = ui->lvVideos->currentIndex();
    if (!index.isValid())
        return;

    onItemClicked(index);
}

void VideoSearch::addToPlaylist()
{
    QModelIndex index = ui->lvVideos->currentIndex();

    if (!index.isValid())
        return;

    if (m_playlist) {
        QString videoUrl = index.data(YTVideoItem::VideoUrl).toString();
        QString title = index.data(YTVideoItem::Title).toString();
        double duration = index.data(YTVideoItem::Duration).toDouble();

        m_playlist->addItem(videoUrl, title, duration);
        m_playlist->getMediaInfo();
    }
}

void VideoSearch::openBrowser()
{
    QModelIndex index = ui->lvVideos->currentIndex();

    if (!index.isValid())
        return;

    QString videoUrl = index.data(YTVideoItem::VideoUrl).toString();
    QDesktopServices::openUrl(videoUrl);
}

void VideoSearch::clearVideoList()
{
    ui->leSearchString->clear();
    m_videoModel->clear();
    ui->lvVideos->reset();
}

void VideoSearch::searchMore()
{
    if (!ui->leSearchString->text().isEmpty()) {
        getVideo(ui->leSearchString->text(), m_videoModel->rowCount());
    }
}

void VideoSearch::startDownload(const QModelIndex &index)
{
    qDebug() << "VideoSearch::startDownload:   start downloading " << index.data(YTVideoItem::VideoUrl).toString().left(30);

    if (m_yt) {
        QString url = index.data(YTVideoItem::VideoUrl).toString();
        m_yt->setPreferredQuality((RetrieveYoutubeUrl::PreferredQuality) pref->yt_quality);
        if (!pref->yt_user_agent.isEmpty()) m_yt->setUserAgent(pref->yt_user_agent);
        m_yt->fetchPage(url);
    }
}

void VideoSearch::startDownload(const QString &url)
{
    QString origUrl = m_yt->origUrl();
    QString preferredUrl = url; //m_yt->latestPreferredUrl();
    QString videoType = m_yt->latestVideoType();

    for (int i = 0; i < m_videoModel->rowCount(); i++) {
        if (m_videoModel->index(i).data(YTVideoItem::VideoUrl).toString() == origUrl) {
            m_videoModel->setData(m_videoModel->index(i), preferredUrl, YTVideoItem::PreferredUrl);
            m_videoModel->setData(m_videoModel->index(i), videoType, YTVideoItem::Type);
            m_videoModel->setData(m_videoModel->index(i), false, YTVideoItem::Downloaded);
            m_videoModel->setData(m_videoModel->index(i), true, YTVideoItem::Downloading);
            m_videoModel->setData(m_videoModel->index(i), false, YTVideoItem::Error);

            // create manager
            YTDownloadManager *mgr = new YTDownloadManager(this);
            connect(mgr, SIGNAL(downloadProgress(int)), SLOT(updateProgress(int)));
            connect(mgr, SIGNAL(downloadSuccess()), SLOT(downloadFinished()));
            connect(mgr, SIGNAL(downloadFailed(YTDownloadManager::Error)), SLOT(downloadError(YTDownloadManager::Error)));

            m_hash.insert(mgr, origUrl);

            // start download
            mgr->startDownload(*m_videoModel->itemAt(i));

            break;
        }
    }

    m_yt->close();
}

void VideoSearch::stopDownload(const QModelIndex &index)
{
    qDebug() << "VideoSearch::stopDownload:   stop downloading " << index.data(YTVideoItem::VideoUrl).toString().left(30);

    QString origUrl = index.data(YTVideoItem::VideoUrl).toString();
    YTDownloadManager *mgr = m_hash.key(origUrl, 0);


    if (mgr == 0) return;

    disconnect(mgr, SIGNAL(downloadProgress(int)), this, SLOT(updateProgress(int)));
    disconnect(mgr, SIGNAL(downloadSuccess()), this, SLOT(downloadFinished()));
    disconnect(mgr, SIGNAL(downloadFailed(YTDownloadManager::Error)), this, SLOT(downloadError(YTDownloadManager::Error)));

    // stop downloading
    mgr->stopDownload();

    // delete from hash
    m_hash.take(mgr);

    // update item
    m_videoModel->setData(index, false, YTVideoItem::Downloaded);
    m_videoModel->setData(index, false, YTVideoItem::Downloading);
    m_videoModel->setData(index, 0, YTVideoItem::Progress);
}

void VideoSearch::updateProgress(int pos)
{
    YTDownloadManager *mgr = qobject_cast<YTDownloadManager*>(sender());

    int i = indexFromHash(mgr);

    if (i == (-1)) return;

    m_videoModel->setData(m_videoModel->index(i), pos, YTVideoItem::Progress);
}

void VideoSearch::downloadFinished()
{
    qDebug() << "VideoSearch::downloadFinished";

    YTDownloadManager *mgr = qobject_cast<YTDownloadManager*>(sender());
    int i = indexFromHash(mgr);

    if (i == (-1)) return;

    // delete from hash
    m_hash.take(mgr);
//    delete mgr;

    // update item
    m_videoModel->setData(m_videoModel->index(i), true, YTVideoItem::Downloaded);
    m_videoModel->setData(m_videoModel->index(i), false, YTVideoItem::Downloading);
    m_videoModel->setData(m_videoModel->index(i), 0, YTVideoItem::Progress);
}

void VideoSearch::downloadError(YTDownloadManager::Error err)
{
    qDebug() << "VideoSearch::downloadError:   error downloading " << err;

    QMessageBox msgBox(this);
    if (err == YTDownloadManager::NotEnoughSpace) {
        msgBox.setText(tr("<b>Not enough free space to save video file<b>"));
        msgBox.setInformativeText(tr("Increase free space and try again"));
    }
    else
        msgBox.setText(tr("Error downloading video clip from YouTube"));
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setWindowTitle("ROSA Media Player");
    msgBox.exec();

    YTDownloadManager *mgr = qobject_cast<YTDownloadManager*>(sender());
    int i = indexFromHash(mgr);

    if (i == (-1)) return;

    // delete from hash
    m_hash.take(mgr);
//    delete mgr;

    // update item
    m_videoModel->setData(m_videoModel->index(i), false, YTVideoItem::Downloaded);
    m_videoModel->setData(m_videoModel->index(i), false, YTVideoItem::Downloading);
    m_videoModel->setData(m_videoModel->index(i), true, YTVideoItem::Error);
    m_videoModel->setData(m_videoModel->index(i), 0, YTVideoItem::Progress);
}

int VideoSearch::indexFromHash(YTDownloadManager* manager)
{
    if (!manager) return (-1);
    if (!m_hash.contains(manager)) return (-1);
    QString origUrl = m_hash[manager];
    for (int i = 0; i < m_videoModel->rowCount(); i++) {
        if (m_videoModel->index(i).data(YTVideoItem::VideoUrl).toString() == origUrl) {
            return i;
        }
    }
    return (-1);
}

Reply *VideoSearch::videoUrl(const QString &searchVideo, int index)
{
    Request *request = m_requestManager->queryVideo(searchVideo, index);
    Reply *reply = new Reply(request, this);
    if (request != 0)
        request->start();

    return reply;
}

void VideoSearch::getVideo(const QString &searchVideo, int index)
{
    Reply *reply = videoUrl(searchVideo, index);
    /*TO-DO: process error replies*/
    connect(reply, SIGNAL(finished()), reply, SLOT(deleteLater()));
}

void VideoSearch::createActions()
{
    m_playAct = new MyAction(this, "yt_play_video", false);
    connect(m_playAct, SIGNAL(triggered()), this, SLOT(playVideo()));

    m_addPlaylistAct = new MyAction(this, "yt_add_to_playlist", false);
    connect( m_addPlaylistAct, SIGNAL(triggered()), this, SLOT(addToPlaylist()));

    m_openBrowserAct = new MyAction(this, "yt_copy_to_clipboard", false);
    connect(m_openBrowserAct, SIGNAL(triggered()), this, SLOT(openBrowser()));
}

void VideoSearch::retranslateStrings()
{
    m_playAct->change( tr("&Play") );
    m_addPlaylistAct->change( tr("&Add to play list") );
    m_openBrowserAct->change( tr("&Open video in browser...") );
}

// Language change stuff
void VideoSearch::changeEvent(QEvent *e)
{
    if (e->type() == QEvent::LanguageChange) {
        retranslateStrings();
    }
    else {
        QWidget::changeEvent(e);
    }
}
