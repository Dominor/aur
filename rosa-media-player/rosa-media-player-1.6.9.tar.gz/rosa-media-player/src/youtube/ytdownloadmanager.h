#ifndef YTDOWNLOADMANAGER_H
#define YTDOWNLOADMANAGER_H

#include <QObject>

class YTDownloadProcess;
class YTVideoItem;

class YTDownloadManager : public QObject
{
    Q_OBJECT
public:
    enum Error {
        UnknownError,
        NotEnoughSpace
    };
    explicit YTDownloadManager(QObject *parent = 0);
    ~YTDownloadManager();

public slots:
    void startDownload(const YTVideoItem &);
    void stopDownload();

protected slots:
    void downloadFinished();
    void downloadError(YTDownloadManager::Error);
    void processExited();
    void checkDiskSpace( long );

signals:
    void downloadSuccess();
    void downloadFailed(YTDownloadManager::Error error);
    void downloadProgress(int);

private:
    YTDownloadProcess* m_proc;
    QString m_filePath;
};

#endif // YTDOWNLOADMANAGER_H
