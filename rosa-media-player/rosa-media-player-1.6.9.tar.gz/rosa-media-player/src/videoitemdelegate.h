#ifndef VIDEOITEMDELEGATE_H
#define VIDEOITEMDELEGATE_H

#include <QStyledItemDelegate>

class VideoItemDelegate : public QStyledItemDelegate
{
    Q_OBJECT

public:
    explicit VideoItemDelegate(QObject * parent = 0);
    ~VideoItemDelegate();

    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
    QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index ) const;

    static QRect buttonRect(const QStyleOptionViewItem &option);

protected:
    bool editorEvent(QEvent *event, QAbstractItemModel*model, const QStyleOptionViewItem &option, const QModelIndex &index);

signals:
    void downloadClicked(const QModelIndex &index);
    void cancelClicked(const QModelIndex &index);

private:
    bool m_isDownloading;
};


QString convertSecsToStr(int secs);

#endif // VIDEOITEMDELEGATE_H
