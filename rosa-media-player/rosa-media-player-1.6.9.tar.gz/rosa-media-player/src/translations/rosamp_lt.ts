<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="lt_LT">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="156"/>
        <source>The following people have contributed with translations:</source>
        <translation>Šie žmonės prisidėjo vertimais:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="162"/>
        <source>German</source>
        <translation>Vokiečių</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="163"/>
        <source>Slovak</source>
        <translation>Slovakų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="164"/>
        <source>Italian</source>
        <translation>Italų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="167"/>
        <source>French</source>
        <translation>Prancūzų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="237"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 ir %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="171"/>
        <source>Simplified-Chinese</source>
        <translation>Supaprastinta kinų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="172"/>
        <source>Russian</source>
        <translation>Rusų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="234"/>
        <source>%1 and %2</source>
        <translation>%1 ir %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="173"/>
        <source>Hungarian</source>
        <translation>Vengrų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="83"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Polish</source>
        <translation>Lenkų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>Japanese</source>
        <translation>Japonų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="180"/>
        <source>Dutch</source>
        <translation>Olandų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Ukrainian</source>
        <translation>Ukrainiečių</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="187"/>
        <source>Portuguese - Brazil</source>
        <translation>Portugalų (Brazilija)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Georgian</source>
        <translation>Gruzinų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="189"/>
        <source>Czech</source>
        <translation>Čekų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Bulgarian</source>
        <translation>Bulgarų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="193"/>
        <source>Turkish</source>
        <translation>Turkų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="194"/>
        <source>Swedish</source>
        <translation>Švedų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="195"/>
        <source>Serbian</source>
        <translation>Serbų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Traditional Chinese</source>
        <translation>Kinų tradicinė</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="197"/>
        <source>Romanian</source>
        <translation>Rumunų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="198"/>
        <source>Portuguese - Portugal</source>
        <translation>Portugalų (Portugalija)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Greek</source>
        <translation>Graikų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="202"/>
        <source>Finnish</source>
        <translation>Suomių</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <location filename="../about.cpp" line="267"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="291"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="26"/>
        <source>About ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="75"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Droid Sans&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="203"/>
        <source>Korean</source>
        <translation>Korėjiečių</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Macedonian</source>
        <translation>Makedonų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Basque</source>
        <translation>Baskų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="80"/>
        <source>Using MPlayer %1</source>
        <translation>Naudojamas MPlayer %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="89"/>
        <source>(c) ROSA 2011-2013

ROSA Media Player is a free software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>terms of use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="112"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Catalan</source>
        <translation>Katalonų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Slovenian</source>
        <translation>Slovėnų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Arabic</source>
        <translation>Arabų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Kurdish</source>
        <translation>Kurdų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Galician</source>
        <translation>Galisų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="240"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 ir %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="243"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 ir %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="211"/>
        <source>Vietnamese</source>
        <translation>Vietnamiečių</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="212"/>
        <source>Estonian</source>
        <translation>Estų</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Lithuanian</source>
        <translation>Lietuvių</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Description</source>
        <translation>Aprašymas</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Shortcut</source>
        <translation>Nuoroda</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="169"/>
        <source>&amp;Save</source>
        <translation>Iš&amp;saugoti</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="172"/>
        <source>&amp;Load</source>
        <translation>Įke&amp;lti</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="420"/>
        <location filename="../actionseditor.cpp" line="479"/>
        <source>Key files</source>
        <translation>Karšti klavišai</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="418"/>
        <source>Choose a filename</source>
        <translation>Pasirinkite failo vardą</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="432"/>
        <source>Confirm overwrite?</source>
        <translation>Tikrai perrašyti?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="433"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Failas %1 jau yra.
Norite perrašyti?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="478"/>
        <source>Choose a file</source>
        <translation>Pasirinkti failą</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="447"/>
        <location filename="../actionseditor.cpp" line="487"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="448"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Failas negali būti išsaugotas</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="488"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Failas negali būti įkeltas</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="176"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Pakeisti nuorodą...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>Audio Equalizer</source>
        <translation>Audio ekvalaizeris</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>31.25 Hz</source>
        <translation>31.25 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>62.50 Hz</source>
        <translation>62.50 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>125.0 Hz</source>
        <translation>125.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>250.0 Hz</source>
        <translation>250.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>500.0 Hz</source>
        <translation>500.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>1.000 kHz</source>
        <translation>1.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="87"/>
        <source>2.000 kHz</source>
        <translation>2.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>4.000 kHz</source>
        <translation>4.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>8.000 kHz</source>
        <translation>8.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>16.00 kHz</source>
        <translation>16.00 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="92"/>
        <source>&amp;Apply</source>
        <translation>&amp;Pritaikyti</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="93"/>
        <source>&amp;Reset</source>
        <translation>&amp;Atstatyti</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Uždaryti</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Nustatyti kaip numatytas reikšmes</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Nustatyti dabartines reikšnes kaip numatytas naujiems video.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Nustatyti visas reikšmes lygias nuliui.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="120"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="121"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Dabartiniai parametrai buvo išsaugoti kaip pradiniai.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1596"/>
        <source>&amp;Open</source>
        <translation>&amp;Atverti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1597"/>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1599"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtitrai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;Browse</source>
        <translation>&amp;Ieškoti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1601"/>
        <source>Op&amp;tions</source>
        <translation>Nus&amp;tatymai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1602"/>
        <source>&amp;Help</source>
        <translation>Pa&amp;galba</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>&amp;File...</source>
        <translation>&amp;Failas...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1422"/>
        <source>D&amp;irectory...</source>
        <translation>&amp;Katalogas...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1423"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Grojaraštis...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD iš diskasukio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1427"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD iš katalogo...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1541"/>
        <source>About &amp;ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1608"/>
        <source>&amp;Clear</source>
        <translation>Iš&amp;valyti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1605"/>
        <source>&amp;Recent files</source>
        <translation>&amp;Paskutiniai failai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="256"/>
        <source>Play list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>P&amp;lay</source>
        <translation>A&amp;tkurti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1450"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pauzė</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1451"/>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>&amp;Frame step</source>
        <translation>&amp;Kadrų žingsnis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normalus greitis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>&amp;Halve speed</source>
        <translation>P&amp;usė greičio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Dvigubas greitis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed &amp;-10%</source>
        <translation>Greitis &amp;-10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>Speed &amp;+10%</source>
        <translation>Greitis &amp;+10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1619"/>
        <source>Sp&amp;eed</source>
        <translation>Gr&amp;eitis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Fullscreen</source>
        <translation>Per &amp;visą ekraną</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1628"/>
        <source>Si&amp;ze</source>
        <translation>D&amp;ydis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1672"/>
        <location filename="../basegui.cpp" line="2754"/>
        <source>&amp;None</source>
        <translation>&amp;Nieko</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Linear &amp;Blend</source>
        <translation>Linijinis &amp;maišymas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1637"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterliacija</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocesingas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Automatinis fazės nustatymas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblokavimas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>De&amp;ring</source>
        <translation>K&amp;raštinių artefaktų pašalinimas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Add n&amp;oise</source>
        <translation>Triukšm&amp;o įdėjimas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1641"/>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltrai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Ekvalaizeris</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>&amp;Screenshot</source>
        <translation>Momentini&amp;s vaizdas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Ekstrastereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1512"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;Filters</source>
        <translation>&amp;Filtrai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1708"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1709"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Channels</source>
        <translation>K&amp;analai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>&amp;Mute</source>
        <translation>&amp;Be garso</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>Volume &amp;-</source>
        <translation>Garso lygis &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <source>Volume &amp;+</source>
        <translation>Garso lygis &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1504"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Užlaikymas -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1505"/>
        <source>D&amp;elay +</source>
        <translation>U&amp;žlaikymas +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1712"/>
        <source>&amp;Select</source>
        <translation>Pa&amp;sirinkti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>&amp;Load...</source>
        <translation>Įke&amp;lti...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>&amp;Title</source>
        <translation>&amp;Titulinis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1724"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Skyrius</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>&amp;Angle</source>
        <translation>K&amp;ampas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Grojaraštis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Išjungta</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2770"/>
        <location filename="../basegui.cpp" line="2790"/>
        <location filename="../basegui.cpp" line="2810"/>
        <location filename="../basegui.cpp" line="2829"/>
        <location filename="../basegui.cpp" line="2858"/>
        <location filename="../basegui.cpp" line="2890"/>
        <location filename="../basegui.cpp" line="2917"/>
        <location filename="../basegui.cpp" line="2960"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;tuščia&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3280"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3281"/>
        <location filename="../basegui.cpp" line="3519"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3282"/>
        <source>Playlists</source>
        <translation>Grojaraščiai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3283"/>
        <location filename="../basegui.cpp" line="3497"/>
        <location filename="../basegui.cpp" line="3520"/>
        <source>All files</source>
        <translation>Visi failai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3278"/>
        <location filename="../basegui.cpp" line="3494"/>
        <location filename="../basegui.cpp" line="3517"/>
        <source>Choose a file</source>
        <translation>Pasirinkti failą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3343"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM/DVD įrenginiai nenustatyti.
Nustatymo diaogas bus parodytas - galima tai padaryti.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3452"/>
        <source>Choose a directory</source>
        <translation>Pasirinkti katalogą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3496"/>
        <source>Subtitles</source>
        <translation>Subtitrai</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="obsolete">Rodomas %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pauzė</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1454"/>
        <source>Play / Pause</source>
        <translation>Atkurti / Pauzė</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1460"/>
        <source>Pause / Frame step</source>
        <translation>Pauzė/kadrų žingsniu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <location filename="../basegui.cpp" line="1517"/>
        <source>U&amp;nload</source>
        <translation>I&amp;škelti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Trim video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="258"/>
        <source>Extract audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3355"/>
        <source>YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>C&amp;lose</source>
        <translation>&amp;Uždaryti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1457"/>
        <source>Show / Hide right panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1528"/>
        <source>&amp;Off</source>
        <comment>closed captions menu</comment>
        <translation type="unfinished">Iš&amp;jungti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1536"/>
        <source>View &amp;info and properties...</source>
        <translation>Rodyti &amp;informaciją ir savybes...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1537"/>
        <source>P&amp;references...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1540"/>
        <source>Help &amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Dec volume (2)</source>
        <translation>Patildyti garsą (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Inc volume (2)</source>
        <translation>Pagarsinti (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Exit fullscreen</source>
        <translation>Išeiti iš pilnaekranio režimo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>OSD - Next level</source>
        <translation>OSD - Sekantis lygis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Dec contrast</source>
        <translation>Pamažinti kontrastą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Inc contrast</source>
        <translation>Padidinti kontrastą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Dec brightness</source>
        <translation>Pamažinti ryškumą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Inc brightness</source>
        <translation>Padidinti ryškumą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Dec hue</source>
        <translation>Pamažinti atspalvį</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>Inc hue</source>
        <translation>Padidinti atspalvį</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Dec saturation</source>
        <translation>Pamažinti sodrumą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Dec gamma</source>
        <translation>Pamažinti gama</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1580"/>
        <source>Next audio</source>
        <translation>Kitas audio takelis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Next subtitle</source>
        <translation>Kiti subtitrai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Next chapter</source>
        <translation>Kitas skyrius</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1583"/>
        <source>Previous chapter</source>
        <translation>Ankstesnis skyrius</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1716"/>
        <source>&amp;Closed captions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1757"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3882"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4072"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Atšauk</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Inc saturation</source>
        <translation>Padidinti sodrumą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Inc gamma</source>
        <translation>Padidinti gama</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Load external file...</source>
        <translation>Įke&amp;lti iš failo...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Adaptuota</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normaliai)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (dviguba kokybė)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1544"/>
        <source>&amp;Next</source>
        <translation>&amp;Kitas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1545"/>
        <source>Pre&amp;vious</source>
        <translation>&amp;Ankstesnis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>Volume &amp;normalization</source>
        <translation>Garso &amp;normalizavimas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Audio CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Pašalinti triukšmą (no&amp;rmaliai)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1681"/>
        <source>Denoise &amp;soft</source>
        <translation>Pašalinti triukšmą (&amp;švelniai)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1679"/>
        <source>Denoise o&amp;ff</source>
        <translation>&amp;Triukšmų pašalinimas išjungtas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1520"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>Naudoti SSA/&amp;ASS biblioteką</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1584"/>
        <source>&amp;Toggle double size</source>
        <translation>Perjung&amp;ti dvigubą dydį</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1518"/>
        <source>S&amp;ize -</source>
        <translation>D&amp;ydis -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Si&amp;ze +</source>
        <translation>Dydi&amp;s +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1491"/>
        <source>Add &amp;black borders</source>
        <translation>Pridėti &amp;juodą rėmelį</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1492"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Prog&amp;raminis didinimas</translation>
    </message>
    <message>
        <source>Enable &amp;closed caption</source>
        <translation type="obsolete">Įjungti paslėptus sub&amp;titrus</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>&amp;Forced subtitles only</source>
        <translation>Tik &amp;forsuoti subtitrai</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1585"/>
        <source>Reset video equalizer</source>
        <translation>Atstatyti video ekvalaizerį</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2121"/>
        <source>Capture desktop...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4479"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>Netikėta MPLayer pabaiga.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4480"/>
        <source>Exit code: %1</source>
        <translation>Klaidos kodas: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4501"/>
        <source>MPlayer failed to start.</source>
        <translation>MPlayer starto klaida.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4502"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Patikrinkite kelią iki MPLayer&apos;io parinktyse.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4506"/>
        <source>MPlayer has crashed.</source>
        <translation>MPlayer užlūžo.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4507"/>
        <source>See the log for more info.</source>
        <translation>Dėl papildomos informacijos žiūrėk ataskaitą.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1645"/>
        <source>&amp;Rotate</source>
        <translation>&amp;Sukti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1683"/>
        <source>&amp;Off</source>
        <translation>Iš&amp;jungti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>Sukti 90° kampu pagal laikrodžio &amp;rodyklę ir perversti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1685"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>&amp;Sukti 90° kampu pagal laikrodžio &amp;rodyklę</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1686"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>S&amp;ukti 90° kampu prieš laikrodžio &amp;rodyklę</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1687"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>Sukti 90° kampu prieš laikrodžio rodyklę ir &amp;perversti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>Show context menu</source>
        <translation>Rodyti kontekstinį meniu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3279"/>
        <source>Multimedia</source>
        <translation>Multimedija</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1495"/>
        <source>E&amp;qualizer</source>
        <translation>E&amp;kvalaizeris</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>Reset audio equalizer</source>
        <translation>Atstatyti audio ekvalaizerį</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>Rasti subtitrus &amp;OpenSubtitles.org tinklalapyje...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Įkelti su&amp;btitrus į OpenSubtitles.org tinklalapį...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Auto</source>
        <translation>&amp;Auto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;4%</source>
        <translation>Greitis -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>&amp;Speed +4%</source>
        <translation>&amp;Greitis +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1470"/>
        <source>Speed -&amp;1%</source>
        <translation>Greitis -&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1471"/>
        <source>S&amp;peed +1%</source>
        <translation>G&amp;reitis +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>Scree&amp;n</source>
        <translation>Ekra&amp;nas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1690"/>
        <source>&amp;Default</source>
        <translation>&amp;Nymatytas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next video</source>
        <translation>Sekantis video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1624"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Takelis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1694"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Takelis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1756"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3342"/>
        <source>ROSA Media Player - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3578"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3881"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Dėmesio - naudojamas senas MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3887"/>
        <source>Please, update your MPlayer.</source>
        <translation>Atnaujinkite MPlayer&apos;į.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3889"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Šis perspėjimas daugiau nebus rodomas)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>Next aspect ratio</source>
        <translation>Kitas kraštinių santykis</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1477"/>
        <source>Pre&amp;view...</source>
        <translation>Per&amp;žiūra...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>DVD &amp;menu</source>
        <translation>DVD &amp;meniu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1746"/>
        <source>DVD &amp;previous menu</source>
        <translation>&amp;Ankstesnis DVD meniu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1740"/>
        <source>DVD menu, move up</source>
        <translation>DVD meniu, judėti aukštyn</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1741"/>
        <source>DVD menu, move down</source>
        <translation>DVD meniu, judėti žemyn</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1742"/>
        <source>DVD menu, move left</source>
        <translation>DVD meniu, judėti kairėn</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>DVD menu, move right</source>
        <translation>DVD meniu, judėti dešinėn</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1745"/>
        <source>DVD menu, select option</source>
        <translation>DVD meniu, pasirinkti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1747"/>
        <source>DVD menu, mouse click</source>
        <translation>DVD meniu, pelės spragtelėjimas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>Set dela&amp;y...</source>
        <translation>Nustatyti užlaik&amp;ymą...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3579"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Audio užlaikymas (milisekundėmis):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4214"/>
        <source>Jump to %1</source>
        <translation>Šokti į %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1523"/>
        <source>Subtitle &amp;visibility</source>
        <translation>Subtitrų &amp;matomumas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>Next wheel function</source>
        <translation>Kita ratuko funkcija</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>P&amp;rograma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1432"/>
        <location filename="../basegui.cpp" line="1433"/>
        <source>&amp;Edit...</source>
        <translation>R&amp;edaguoti...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1436"/>
        <source>Next TV channel</source>
        <translation>Kitas TV kanalas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1437"/>
        <source>Previous TV channel</source>
        <translation>Ankstesnis TV kanalas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1438"/>
        <source>Next radio channel</source>
        <translation>Kita radijo kanalas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1439"/>
        <source>Previous radio channel</source>
        <translation>Ankstesnis radijo kanalas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1610"/>
        <source>&amp;TV</source>
        <translation>&amp;TV</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>Radi&amp;o</source>
        <translation>&amp;Radijas</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1434"/>
        <location filename="../basegui.cpp" line="1435"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Šokti...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1374"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Naudojant vdpau video filtrai išjungti</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1478"/>
        <source>Fli&amp;p image</source>
        <translation>&amp;Perversti vaizdą</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Show filename on OSD</source>
        <translation>Rodyti failo vardą OSD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>Toggle deinterlacing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>Slėp&amp;ti</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Atstatyti</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>&amp;Baigti</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Grojaraštis</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation type="unfinished">00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="83"/>
        <source>Volume</source>
        <translation type="unfinished">Garso lygis</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3145"/>
        <source>Brightness: %1</source>
        <translation>Ryškumas: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3162"/>
        <source>Contrast: %1</source>
        <translation>Kontrastas: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3178"/>
        <source>Gamma: %1</source>
        <translation>Gama: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3194"/>
        <source>Hue: %1</source>
        <translation>Atspalvis: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3210"/>
        <source>Saturation: %1</source>
        <translation>Sodrumas: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3362"/>
        <source>Volume: %1</source>
        <translation>Garsas: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4328"/>
        <source>Zoom: %1</source>
        <translation>Didinimas: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3500"/>
        <location filename="../core.cpp" line="3518"/>
        <source>Font scale: %1</source>
        <translation>Šrifto dydis: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4182"/>
        <source>Aspect ratio: %1</source>
        <translation>Kraštinių santykis: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4595"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Atnaujinama šriftų atmintinė. Tai gali užtrukti keletą sekundžių...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3411"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Subtitrų užlaikymas: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3431"/>
        <source>Audio delay: %1 ms</source>
        <translation>Audio užlaikymas: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3275"/>
        <source>Speed: %1</source>
        <translation>Greitis %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="199"/>
        <source>Connecting to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="203"/>
        <source>Unable to retrieve youtube page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="207"/>
        <source>Unable to locate the url of the video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3572"/>
        <source>Subtitles on</source>
        <translation>Subtitrai įjungti</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3574"/>
        <source>Subtitles off</source>
        <translation>Subtitrai išjungti</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4233"/>
        <source>Mouse wheel seeks now</source>
        <translation>Dabar pelės ratukas veikia prasukimo režimu</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4236"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Dabar pelės ratukas veikia garso reguliavimo režimu</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4239"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Dabar pelės ratukas veikia vaizdo didinimo/mažinimo režimu</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4242"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Dabar pelės ratukas veikia greičio didinimo/mažinimo režimu</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1205"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Momentinis vaizdas NEpadarytas, neparinktas katalogas</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1221"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Momentiniai vaizdai NEpadaryti, neparinktas katalogas</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2865"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>&quot;A&quot; žymė nustatyta %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2884"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>&quot;B&quot; žymė nustatyta %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2902"/>
        <source>A-B markers cleared</source>
        <translation>A-B žymės išvalytos</translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation type="unfinished">Informacija</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation type="unfinished">Gerai</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation type="unfinished">Atšauk</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>A:%1</source>
        <translation type="obsolete">A:%1</translation>
    </message>
    <message>
        <source>B:%1</source>
        <translation type="obsolete">B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="320"/>
        <source>&amp;Video info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="321"/>
        <source>&amp;Frame counter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>piktograma</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Slėpti ataskaitą</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Rodyti ataskaitą</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>MPlayer klaida</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>piktograma</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation>Piktograma</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation>Favoritų redaktorius</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation>Favoritų sąrašas</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Galite redaguoti, šalinti, rūšiuoti ar papildyti. Turinio redagavimui dukart spustelkite į langelį.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation>Pažymėkite piktogramos failą</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation>Paveiksėliai</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>piktograma</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation>&amp;Nauja</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>Ša&amp;linti</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation>Š&amp;alinti visus</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation>A&amp;ukštyn</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation>&amp;Žemyn</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation>Šokti į elementą</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Įveskite norimo elemento numerį šokimo sąraše:</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Atsiunčiama...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Atsiunčiama %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Informacija</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demukseris</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>Pa&amp;žymėtike demukserį šio failo atkūrimui:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>&amp;Atstatyti</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Video kodekas</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>Pa&amp;žymėtike video kodeką:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>A&amp;udio kodekas</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>Pa&amp;žymėtike audio kodeką:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer parinktys</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Papildomos MPlayer&apos;io parinktys</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Čia galima nurodyti papildomas MPlayer&apos;io parinktis.
Įrašai turi būti atskirti tarpais.
Pavyzdžiui: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>Nu&amp;ostatos:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Taip pat galima perduoti papildomus video filtrus.
Atskirtike juos &quot;,&quot;. Nenaudokite tarpų!
Pavyzdžiui: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo filtrai:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Audio filtrai nurodomi kaip ir video filtrai.
Pavyzdžiui: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Audio &amp;filtrai:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>OK</source>
        <translation>Gerai</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Cancel</source>
        <translation>Atšauk</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="140"/>
        <source>Apply</source>
        <translation>Pritaikyti</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation>triukšmo pridėjimas</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation>atblokavimas</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation>normalus triukšmo sumažinimas</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation>švelnus triukšmo sumažinimas</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation>garso lygio normalizavimas</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation>Http</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Įjungti/išjungti tarpinio serverio naudojimą.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation>Tarpinio serverio vardas.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation>Tarpinio serverio prievadas.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Jei tarpinis serveris reikalauja identifikacijos, čia nustatomas vartotojo vardas.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Slaptažodis tarpiniam serveriui. &lt;b&gt;Dėmesio:&lt;/b&gt; slaptažodis konfigūracijos faile išsaugomas neužšifruotas.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation>Parinkite naudojamo tarpinio serverio tipą.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation>Papildomos nuostatos</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation>Įgaliotas serveris</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Įjungti tarpinį serverį</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation>&amp;Host:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation>&amp;Jungtis:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation>&amp;Vartotojo vardas:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation>&amp;Slaptažodis:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation>&amp;Tipas:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Kalba</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Formatas</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Failai</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Įkeltas</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Visi</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Uždaryti</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Atsiųsti</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Kopijuoti nuorodą į atmintį</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>%1 atsiuntimas nepavyko.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>Jungiamasi prie %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>Atsiunčiama...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Baigta.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 failų prieinama</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Gautų duomenų apdorojimo klaida.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Rasti subtitrus</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Subtitrai</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>Ka&amp;lba:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>At&amp;naujinti</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Subtitrai išsaugoti kaip %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation>
            <numerusform>%1 subtitras ištrauktas</numerusform>
            <numerusform>%1 subtitrai ištraukti</numerusform>
            <numerusform>%1 subtitrų ištraukta</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Perrašyti?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>Failas %1 egzistuoja, perrašyti?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Failo išsaugojimo klaida</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Neįmanoma išsaugoti atsiųstą failą kataloge
%1
Patiktinti priėjimo prie katalogo teises.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation>Siuntimas nepavyko</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation>Laikinas failas %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>Nu&amp;ostatos</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Pagrindinės</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Dydis</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Trukmė</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Demukseris</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Atlikėjas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Autorius</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Albumas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Žanras</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Takelis</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Autorinės teisės</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Komentaras</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Programinė įranga</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Klipo informacija</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Raiška</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Kraštinių santykis</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Formatas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Kokybė</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Kadrų per sekundę</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Pažymėtas kodekas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Pirminis audio takelis</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Dažnis</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Kanalai</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Audio takeliai</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Kalba</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>tuščia</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Subtitrai</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Takelio pavadinimas</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Takelio URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>Failas</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Pasirinkti katalogą</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Galima žiūrėti DVD iš kietojo disko. Pažymėkite katalogą, kuriame yra VIDEO_TS ir AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Nurodykite katalgą...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>Versija gauta iš MPlayer&apos;io:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Nurodykite tei&amp;singą versiją:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 ar senesnė</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 ar naujesnė</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;URL:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>Tai yra &amp;grojaraštis</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="34"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Jei pažymėta, URL bus suprastas kaip grojaraštis: jis bus atydarytas kaip tekstas ir bus atkuriami adresai iš jo.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Afarų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Abchazų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Afrikiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Amharų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Arabų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Asamų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Aimarų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Azerbaidžaniečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Baškirų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Bulgarų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Biharų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Bengalų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Tibetiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Bretonų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Katalonų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Korsikiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Čekų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Velsiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Danų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>Vokiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Graikų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Anglų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Ispanų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Estų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Baskų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Persų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Suomių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Farerų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>Prancūzų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Fryzų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Airių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Galisų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Gvaranių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Gudžaratų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Hausų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Hebrajų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Kroatų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Vengrų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Armėnų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Indoneziečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Islandų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Italų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Inuktitutas</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Japonų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Javiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Gruzinų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Kazachų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Grenlandų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Kanadiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Korėjiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Kašmyrų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Kurdų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Kirgizų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Lotynų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Lietuvių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Latvių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Malagasių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Maorių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Makedonų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Malajalių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Mongolų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Moldavų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Marathų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Malajiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Maltiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Birmiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Nauriečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Nepalų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Olandų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Norvegų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Očitarų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Orijų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Lenkų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Portugalų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Kečujų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Rumunų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Rusų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Kinjaruanda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Sanskritas</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Sindhų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Slovakų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Slovėnų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Samojiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Šonų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Somalių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Albanų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Serbų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Sundos</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Švedų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Svahilių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Tamilų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Telugų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Tadžikų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Tajų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Tigrajų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Turkmėnų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Tagalų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Tongų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Turkų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Tsongų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Totorių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Tvi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Uigūrų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Ukrainiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Uzbekų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Vietnamiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Volofų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Kosų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Judėjų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Jorubų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Džuangų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Kinų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Zulų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Portugalų (Brazilija)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Portugalų (Portugalija)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Supaprastinta kinų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Kinų tradicinė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Unikodas</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Vakarų Europos kalbos</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Vakarų Europos kalbos (su Euru)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Slavų/Centrinės Europos kalbos</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, galisų, maltiečių, turkų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Sena baltų koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Kirilica</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Moderni graikų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Baltų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Keltų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Hebrajų koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainiečių, baltarusių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Supaprastinta kinų koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Kinų tradicinė koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Japonų koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Korėjiečių koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Tajų koduotė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Windows kirilica</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Slavų/Centrinės Europos Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Arabų Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation>Avestos</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation>Akanų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation>Aragoniečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation>Avarų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation>Baltarusių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation>Bambarų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation>Bosnių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation>Čėčėnų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation>Kri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation>Bažnytinė</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation>Čiuvašų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation>Maldyviečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation>Botijų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation>Eve</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation>Fulų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation>Fidžių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation>Galų (keltų)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation>Menksiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation>Hiri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation>Haičio</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation>Herero</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation>Čamorų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation>Igbų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation>Ji</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation>Inupiakų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation>Ido</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation>Kikujų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation>Kvanjama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation>Kmerų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation>Kanurių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation>Komių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation>Kornų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation>Liuksemburgiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation>Lugandų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation>Limburgiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation>Laosiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation>Lubų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation>Maršaliečių</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Norvegų bokmål</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation>Ndebelų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation>Ndongų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation>Navachų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation>Čičevų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation>Odžibvių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation>Oromų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation>Osetinų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation>Pendžabų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation>Pali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation>Puštūnų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation>Retoromanų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation>Kirundžių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation>Sardų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation>Sami</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation>Sango</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation>Sinhalų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation>Svazių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation>Sotų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation>Tsvanų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation>Taitiečių</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation>Vendų</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation>Volapiukas</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation>Valonų</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation>Windows moderni graikų</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Parinkite vardą išsaugojimui</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Tikrai perrašyti?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Failas jau yra.
Norite perrašyti?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Failo išsaugojimo klaida</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Ataskaita neišsaugota</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Ataskaitos</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Ataskaitos langas</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Išsaugoti</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Kopijuoti į atmintį</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Uždaryti</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Uždaryti</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Name</source>
        <translation>Pavadinimas</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Length</source>
        <translation>Trukmė</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Play</source>
        <translation>&amp;Atkurti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="386"/>
        <source>&amp;Edit</source>
        <translation>R&amp;edaguoti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="829"/>
        <location filename="../playlist.cpp" line="849"/>
        <source>Playlists</source>
        <translation>Grojaraščiai</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="827"/>
        <source>Choose a file</source>
        <translation>Pasirinkti failą</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="396"/>
        <source>ROSA Media Player - Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="847"/>
        <source>Choose a filename</source>
        <translation>Pasirinkite failo vardą</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="861"/>
        <source>Confirm overwrite?</source>
        <translation>Tikrai perrašyti?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="862"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Failas %1 jau yra.
Norite perrašyti?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1080"/>
        <source>Multimedia</source>
        <translation type="unfinished">Multimedija</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1081"/>
        <source>All files</source>
        <translation>Visi failai</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>Select one or more files to open</source>
        <translation>Pasirinkite vieną ar kelis failus atvėrimui</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1142"/>
        <source>Choose a directory</source>
        <translation>Pasirinkti katalogą</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1367"/>
        <source>Edit name</source>
        <translation>Redaguoti pavadinimą</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1368"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Įrašykite pavadinimą, kuris bus rodomas grojarašyje šiam failui:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="346"/>
        <source>&amp;Load</source>
        <translation>Įke&amp;lti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Save</source>
        <translation>Iš&amp;saugoti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="351"/>
        <source>&amp;Next</source>
        <translation>&amp;Kitas</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="352"/>
        <source>Pre&amp;vious</source>
        <translation>&amp;Ankstesnis</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>Move &amp;up</source>
        <translation>Judėti &amp;aukštyn</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>Move &amp;down</source>
        <translation>Judėti &amp;žemyn</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>&amp;Repeat</source>
        <translation>Paka&amp;rtoti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="372"/>
        <source>S&amp;huffle</source>
        <translation>S&amp;umaišyti</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="377"/>
        <source>Add &amp;current file</source>
        <translation>&amp;Pridėti šį failą</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="378"/>
        <source>Add &amp;file(s)</source>
        <translation>Pridėti &amp;failus</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Add &amp;directory</source>
        <translation>Pridėti &amp;direktoriją</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="382"/>
        <source>Remove &amp;selected</source>
        <translation>Pa&amp;šalinti pažymėtus</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>Remove &amp;all</source>
        <translation>Pašalinti &amp;visus</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="390"/>
        <source>Add...</source>
        <translation>Pridėti...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="392"/>
        <source>Remove...</source>
        <translation>Pašalinti...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="891"/>
        <source>Playlist modified</source>
        <translation>Grojaraštis pakeistas</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="892"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Yra neišsaugotų pakeitimų, išsaugoti grojaraštį?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Preferences</source>
        <translation>Nuostatos</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>SMPlayer - nuostatos</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Pažymėkite, jei norite kad pridedant katalogą būtų pridėti ir jo pakatalogiai. Priešingu atveju bus pridėti  failai tik iš pažymėto katalogo.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>Pridėti f&amp;ailus ir iš subdirektorijų</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Pažymėkite, jei norite į grojaraštį pridėti papildomą informaciją iš failų. Tai leidžia rodyti failo pavadinimą ir trukmę. Priešingu atveju ši informacija bus prieinama tik pradėjus atkurti failą. Atsargiai - ši nuostata gali sulėtinti darbą, ypač jei įkeliama daug failų.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Automatiškai gauti &amp;informaciją apie pridėtus failus</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>Iš&amp;saugoti grojaraščio kopiją baigiant darbą</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>Atkurti failus nuo &amp;pradžios</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Dėmesio</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Ne visi failai gali būti asocijuoti. Patikrinkite priėjimo teises ir pabandykite dar kartą.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Failų tipai</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Pažymėti visus</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Pažymėti visus failų tipus sąraše</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Atžymėti visus failų tipus sąraše</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Failų tipų sąrašas</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Failų tipai</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Pažymėti visus</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Nepažymėti nei vieno</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Nepažymėti nei vieno</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation> &lt;b&gt;Pastaba:&lt;/b&gt; Asociacijų atstatymas neveikia su Windows Vista.</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <source>Drives</source>
        <translation type="obsolete">Diskai</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">piktograma</translation>
    </message>
    <message>
        <source>CD device</source>
        <translation type="obsolete">CD įrenginys</translation>
    </message>
    <message>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation type="obsolete">Parinkite CDROM įrenginį. Jis bus naudojamas atkurti VCD ir Audio CD diskams.</translation>
    </message>
    <message>
        <source>DVD device</source>
        <translation type="obsolete">DVD įrenginys</translation>
    </message>
    <message>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation type="obsolete">Parinkite DVD įrenginį. Jis bus naudojamas atkurti DVD diskams.</translation>
    </message>
    <message>
        <source>Select your &amp;CD device:</source>
        <translation type="obsolete">Parinkie &amp;CD įrenginį:</translation>
    </message>
    <message>
        <source>Select your &amp;DVD device:</source>
        <translation type="obsolete">Parinkie &amp;DVD įrenginį:</translation>
    </message>
    <message>
        <source>Enable DVD menus</source>
        <translation type="obsolete">Įjungti DVD meniu</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note 1&lt;/b&gt;: cache will be disabled, this can affect performance.</source>
        <translation type="obsolete">&lt;b&gt;1 pastaba:&lt;/b&gt; tarpinė atmintis bus išjungta, tai gali įtakoti darbingumą.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note 2&lt;/b&gt;: you may want to assign the action &quot;activate option in DVD menus&quot; to one of the mouse buttons.</source>
        <translation type="obsolete">&lt;b&gt;2 pastaba:&lt;/b&gt; galbūt norėsite susieti veiksmą &quot;DVD meniu parinkties aktyvacija&quot; su vienu iš pelės mygtukų.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note 3&lt;/b&gt;: this feature is under development, expect a lot of issues with it.</source>
        <translation type="obsolete">&lt;b&gt;3 pastaba:&lt;/b&gt; ši galimybė tik kuriama, todėl ją naudojant galimos įvairios problemos.</translation>
    </message>
    <message>
        <source>&amp;Enable DVD menus (experimental)</source>
        <translation type="obsolete">Įjungti DVD m&amp;eniu (eksperimentinis)</translation>
    </message>
    <message>
        <source>&amp;Scan for CD/DVD drives</source>
        <translation type="obsolete">Aptikti CD/DVD įrenginiu&amp;s</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="82"/>
        <source>General</source>
        <translation>Pagrindinės</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="obsolete">Pa&amp;grindinės</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="338"/>
        <source>Media settings</source>
        <translation>Media nustatymai</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="112"/>
        <source>&amp;Disable screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="246"/>
        <source>Cha&amp;nnels by default:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="119"/>
        <source>YouTube support (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="49"/>
        <source>Preferred video &amp;quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="129"/>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>Main window</source>
        <translation type="unfinished">Pagrindinis langas</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="137"/>
        <source>A&amp;utoresize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="197"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Instances</source>
        <translation type="unfinished">Egzemplioriai</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="206"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="225"/>
        <source>&amp;Volume normalization by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">Au&amp;tomatiškai keisti dydį:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="154"/>
        <source>Never</source>
        <translation type="unfinished">Niekada</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="159"/>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished">Kai reikalinga</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="164"/>
        <source>Only after loading a new video</source>
        <translation type="unfinished">Tik įkėlus naują video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="187"/>
        <source>R&amp;emember position and size</source>
        <translation type="unfinished">&amp;Įsiminti poziciją ir dydį</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation type="obsolete">Pradėti video viso ekrano režimu</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Disable screensaver</source>
        <translation>Išjungti skrynseiverį</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation type="obsolete">Parinkti mplayer&apos;io vykomąją programą</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation type="obsolete">Vykdomosios programos</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="obsolete">Visi failai</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation type="obsolete">Pažymėti katalogą</translation>
    </message>
    <message>
        <source>MPlayer executable</source>
        <translation type="obsolete">Vykdomoji MPlayer programa</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Screenshots folder</source>
        <translation type="obsolete">Momentinių vaizdų katalogas</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Automatically add files to playlist</source>
        <translation type="unfinished">Automatiškai įtraukti failus į grojaraštį</translation>
    </message>
    <message>
        <source>Video output driver</source>
        <translation type="obsolete">Video išvesties įrenginys</translation>
    </message>
    <message>
        <source>Audio output driver</source>
        <translation type="obsolete">Audio išvesties įrenginys</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation type="obsolete">Parinkite audio išvesties įrenginį.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="340"/>
        <source>Remember settings</source>
        <translation>Atsiminti nustatymus</translation>
    </message>
    <message>
        <source>Software video equalizer</source>
        <translation type="obsolete">Programinis video ekvalaizeris</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="obsolete">Galite pažymėti šią parintį, jei jūsų video plokštė arba pasirinkta video išvesties tvarkyklė nepalaiko video ekvalaizerio.&lt;br&gt;&lt;b&gt;Pastaba:&lt;/b&gt; ši parinktis gali būti nesuderinama su kai kuriomis video išvesties tvarkyklėmis.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation type="obsolete">Jei pažymėta, visi video startuos pilno ekrano režimu.</translation>
    </message>
    <message>
        <source>Software volume control</source>
        <translation type="obsolete">Programinė garso lygio kontrolė</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="obsolete">Pabandykite šią parinktį programinio mikserio panaudijomui vietoj garso kortos aparatinio.</translation>
    </message>
    <message>
        <source>Postprocessing quality</source>
        <translation type="obsolete">Postprocesingas kokybė</translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="obsolete">Postprocesingo lygio dinaminis keitimas priklauso nuo laisvo procesoriaus laiko. Nurodytas skaičius atitiks maksimalai leistiną naudoti lygį. Naudokite didesnį skaičių.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="77"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>P&amp;risiminti nustatymus visiems failams (audio takeliams, subtitrams...)</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Grojaraštis</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="105"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation type="unfinished">&amp;Automatiškai įtraukti failus į grojaraštį</translation>
    </message>
    <message>
        <source>&amp;Quality:</source>
        <translation type="obsolete">&amp;Kokybė:</translation>
    </message>
    <message>
        <source>Start videos in &amp;fullscreen</source>
        <translation type="obsolete">Pradėti video &amp;viso ekrano režimu</translation>
    </message>
    <message>
        <source>Disable &amp;screensaver</source>
        <translation type="obsolete">Išjungti &amp;skrynseiverį</translation>
    </message>
    <message>
        <source>Use s&amp;oftware volume control</source>
        <translation type="obsolete">Naudoti programinę gar&amp;so lygio kontrolę</translation>
    </message>
    <message>
        <source>Ma&amp;x. Amplification:</source>
        <translation type="obsolete">Ma&amp;ksimalus padidinimas:</translation>
    </message>
    <message>
        <source>&amp;AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">&amp;AC3/DTS per S/PDIF</translation>
    </message>
    <message>
        <source>Direct rendering</source>
        <translation type="obsolete">Tiesioginis renderingas</translation>
    </message>
    <message>
        <source>Double buffering</source>
        <translation type="obsolete">Dvigubas buferizavimas</translation>
    </message>
    <message>
        <source>D&amp;irect rendering</source>
        <translation type="obsolete">Tiesioginis &amp;renderingas</translation>
    </message>
    <message>
        <source>Dou&amp;ble buffering</source>
        <translation type="obsolete">Dvigubas &amp;buferizavimas</translation>
    </message>
    <message>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation type="obsolete">Dviguba buferizacija koreguoja kadrų mirgėjimą (kadangi į atmintį įkeliami du kadrai ir rodant vieną kadrą jau apdorojamas kitas). Šios parinkties išjungimas gali neigiamai įtakoti OSD, bet neretai pašalina OSD mirgėjimą.</translation>
    </message>
    <message>
        <source>&amp;Enable postprocessing by default</source>
        <translation type="obsolete">Įjungti postproc&amp;esingą neklausus</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Garso lygio &amp;normalizavimas neklausus</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="345"/>
        <source>Close when finished</source>
        <translation>Užverti baigus</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="346"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Jei pažymėta, baigus dabartinį failą/grojaraštį pagrindinis langas užsivers.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="98"/>
        <source>2 (Stereo)</source>
        <translation>2 (Stereo)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="99"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 Surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="100"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 Surround)</translation>
    </message>
    <message>
        <source>C&amp;hannels by default:</source>
        <translation type="obsolete">P&amp;radiniai kanalai:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="91"/>
        <source>&amp;Pause when minimized</source>
        <translation>&amp;Pristabdyti kai sumažinamas</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="349"/>
        <source>Pause when minimized</source>
        <translation>Pristabdyti kai sumažinamas</translation>
    </message>
    <message>
        <source>Enable postprocessing by default</source>
        <translation type="obsolete">Įjungti postprocesingą neklausus</translation>
    </message>
    <message>
        <source>Max. Amplification</source>
        <translation type="obsolete">Maksimalus padidinimas</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">AC3/DTS per S/PDIF</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="401"/>
        <source>Volume normalization by default</source>
        <translation type="unfinished">Numatytas garso lygio normalizavimas</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="402"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="unfinished">Padidina garso lygį be garso iškraipymo.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="371"/>
        <source>Channels by default</source>
        <translation>Numatytieji kanalai</translation>
    </message>
    <message>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation type="obsolete">Nustato maksimalų pagarsinimą procentais (pirminė reikšmė 110). Reikšmė 200 padidins dabartinį garsą dvigubai. Esant žemesnėms už 100 reikšmėms, pradinis garso lygis (100%) bus didesnis už maksimumą, t.y. OSD rodys neteisingą informaciją.</translation>
    </message>
    <message>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation type="obsolete">Postprocesingas bus naudojamas naujai atveriamiems failams.</translation>
    </message>
    <message>
        <source>High speed &amp;playback without altering pitch</source>
        <translation type="obsolete">Greitas atkūrimas be &amp;pič-efekto</translation>
    </message>
    <message>
        <source>High speed playback without altering pitch</source>
        <translation type="obsolete">Greitas atkūrimas be pič-efekto</translation>
    </message>
    <message>
        <source>Allows to change the playback speed without altering pitch. Requires at least MPlayer dev-SVN-r24924.</source>
        <translation type="obsolete">Leidžia keisti atkūrimo greitį be pič-efekto. Reikalinga ne senesnė kaip dev-SVN-r24924 MPlayer&apos;io versija.</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="obsolete">&amp;Video</translation>
    </message>
    <message>
        <source>Use s&amp;oftware video equalizer</source>
        <translation type="obsolete">Naudoti pr&amp;ograminį video ekvalaizerį</translation>
    </message>
    <message>
        <source>A&amp;udio</source>
        <translation type="obsolete">A&amp;udio</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">Garso lygis</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="obsolete">Video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="216"/>
        <location filename="../prefgeneral.cpp" line="399"/>
        <source>Audio</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation type="obsolete">Proritetinė audio ir subtitrų kalba</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nėra</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">Lowpass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normaliai)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (dviguba kokybė)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Linijinis maišymas</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Adaptuota</translation>
    </message>
    <message>
        <source>Deinterlace by default</source>
        <translation type="obsolete">Pašalinti &quot;šukas&quot; neklausiant</translation>
    </message>
    <message>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation type="obsolete">Parinkti &quot;šukų&quot; pašalinimo filtrą naujai atvertiems video failams.</translation>
    </message>
    <message>
        <source>Remember time position</source>
        <translation type="obsolete">Atsiminti laiko poziciją</translation>
    </message>
    <message>
        <source>Remember &amp;time position</source>
        <translation type="obsolete">A&amp;tsiminti laiko poziciją</translation>
    </message>
    <message>
        <source>Enable the audio equalizer</source>
        <translation type="obsolete">Įjungti audio ekvalaizerį</translation>
    </message>
    <message>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation type="obsolete">Jei pažymėta, bus naudojamas audio ekvalaizeris.</translation>
    </message>
    <message>
        <source>&amp;Enable the audio equalizer</source>
        <translation type="obsolete">Įjungti audio &amp;ekvalaizerį</translation>
    </message>
    <message>
        <source>Draw video using slices</source>
        <translation type="obsolete">Piešti video naudojant sluoksnius</translation>
    </message>
    <message>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation type="obsolete">Įjungia/išjungia video piešimą 16 pikselių aukščio sluoksniais/juostomis. Jei išjungta, visas kadras bus piešiamas iš karto. Priklausomai nuo video plokštės ir prieinamos laikinos atmintinės, gali vykti greičiau ar lėčiau. Naudinga tik su libmpeg2 ir libavcodec kodekais.</translation>
    </message>
    <message>
        <source>Dra&amp;w video using slices</source>
        <translation type="obsolete">Piešti &amp;video naudojant sluoksnius</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="84"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Užverti baigus atkūrimą</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="obsolete">greitai</translation>
    </message>
    <message>
        <source>slow</source>
        <translation type="obsolete">lėtai</translation>
    </message>
    <message>
        <source>fast - ATI cards</source>
        <translation type="obsolete">greitai - ATI plokštėms</translation>
    </message>
    <message>
        <source>User defined...</source>
        <translation type="obsolete">Vartotojo pasirinkta...</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Default zoom</source>
        <translation type="obsolete">Numatytas didinimas</translation>
    </message>
    <message>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation type="obsolete">Ši parinktis nustato numatytą didinimą naujiems video.</translation>
    </message>
    <message>
        <source>Default &amp;zoom:</source>
        <translation type="obsolete">Numatytas &amp;didinimas:</translation>
    </message>
    <message>
        <source>Select the video output driver. %1 provides the best performance.</source>
        <translation type="obsolete">Parinkite video išvesties į ekraną įrenginį. %1 užtikrins maksimalios kokybės darbą.</translation>
    </message>
    <message>
        <source>%1 is the recommended one. Try to avoid %2 and %3, they are slow and can have an impact on performance.</source>
        <translation type="obsolete">Rekomenduojamas %1. Pabandykite vengti %2 ir %3, jie lėtesni ir gali pabloginti darbą.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="103"/>
        <source>1080p</source>
        <translation type="unfinished">1080p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="104"/>
        <source>720p</source>
        <translation type="unfinished">720p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="105"/>
        <source>480p</source>
        <translation type="unfinished">480p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="106"/>
        <source>360p</source>
        <translation type="unfinished">360p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="107"/>
        <source>240p</source>
        <translation type="unfinished">240p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="350"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Jei pažymėta, pagrindinį langą minimizavus, failas bus pristabdytas. Langą atstačius, atkūrimas bus tęsiamas.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="384"/>
        <source>Autoresize</source>
        <translation type="unfinished">Automatiškai keisti dydį</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="unfinished">Pagrindinio lango dydis gali būti pakeistas automatiškai. Išrinkite mėgstamą parinktį.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Remember position and size</source>
        <translation type="unfinished">Prisiminti poziciją ir dydį</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="396"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="362"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Pažymėkite skrynseiverio išjungimui atkūrimo metu. &lt;br&gt;Pasibaigus atkūrimui, skrynseiveris bus vėl įjungtas.</translation>
    </message>
    <message>
        <source>Ou&amp;tput driver:</source>
        <translation type="obsolete">Išves&amp;ties tvarkykė:</translation>
    </message>
    <message>
        <source>Add black borders on fullscreen</source>
        <translation type="obsolete">Pridėti juodus kraštus pilnaekraniame režime</translation>
    </message>
    <message>
        <source>If this option is enabled, black borders will be added to the image in fullscreen mode. This allows subtitles to be displayed on the black borders.</source>
        <translation type="obsolete">Jei pažymėta, pilno ekrano režime bus pridėtas juodas rėmelis. Ant rėmelio galima rodyti subtitrus.</translation>
    </message>
    <message>
        <source>&amp;Add black borders on fullscreen</source>
        <translation type="obsolete">Pridėti juodus kr&amp;aštus pilnaekraniame režime</translation>
    </message>
    <message>
        <source>If checked, turns on direct rendering (not supported by all codecs and video outputs)&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; May cause OSD/SUB corruption!</source>
        <translation type="obsolete">Jei pažymėta, įjungiamas tiesioginis renderingas (palaikomas ne visų kodekų ir video išvesčių). &lt;br&gt;&lt;b&gt;Dėmesio:&lt;/b&gt; Gali kilti problebų su OSD ar subtitrais!</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="372"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Užklausia atkūrimo kanalų skaičių. MPlayr prašo dekoderio dekoduoti audio į nurodytą kanalų skaičių. Tai paliekama dekoderio atsakomybei. Paprastai tai svarbu kai atkuriamas video su AC3 garsu (pvz. DVD). Šiuo atvejus liba52 atlieka dekodavimą kaip įprasta ir korektiškai išdalina audio į prašomą kanalų skaičių. &lt;b&gt;Pastaba&lt;/b&gt;: Šią parinktį pripažįsta AC3 kodekai, &lt;i&gt;surround&lt;/i&gt;  filtrai ir audio išvesties tvarkyklės (minimum OSS).</translation>
    </message>
    <message>
        <source>Enable screenshots</source>
        <translation type="obsolete">Įjungti momentinių vaizdų darymą</translation>
    </message>
    <message>
        <source>You can use this option to enable or disable the possibility to take screenshots.</source>
        <translation type="obsolete">Galima naudoti šią parinktį momentinių vaizdų fotografavimo įjungimui ar išjungimui.</translation>
    </message>
    <message>
        <source>&amp;MPlayer executable:</source>
        <translation type="obsolete">Vykdomoji &amp;MPlayer programa:</translation>
    </message>
    <message>
        <source>Screenshots</source>
        <translation type="obsolete">Momentiniai vaizdai</translation>
    </message>
    <message>
        <source>&amp;Enable screenshots</source>
        <translation type="obsolete">Įjungti mom&amp;entinių vaizdų darymą</translation>
    </message>
    <message>
        <source>&amp;Folder:</source>
        <translation type="obsolete">&amp;Katalogas:</translation>
    </message>
    <message>
        <source>Global volume</source>
        <translation type="obsolete">Bendras garso lygis</translation>
    </message>
    <message>
        <source>If this option is checked, the same volume will be used for all files you play. If the option is not checked each file uses its own volume.</source>
        <translation type="obsolete">Jei pažymėta, tas pats garso lygis bus naudojamas visų failų atkūrimui. Priešingu atveju kiekvienas failas naudos savo garso lygį.</translation>
    </message>
    <message>
        <source>This option also applies for the mute control.</source>
        <translation type="obsolete">Ši parinktis taip pat naudojama garso pritildymui.</translation>
    </message>
    <message>
        <source>Glo&amp;bal volume</source>
        <translation type="obsolete">Ben&amp;dras garso lygis</translation>
    </message>
    <message>
        <source>Switch screensaver off</source>
        <translation type="obsolete">Išjungti &lt;i&gt;skrynseiverį&lt;/i&gt;</translation>
    </message>
    <message>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="obsolete">Ši parinktis išjungia skrynseiverį prieš failo atkūrimą ir įjungia jį, kai atkūrimas baigiamas. Jei pažymėta, skrynseiveris neatsiras net ir atkuriant audio failus arba failo atkūrimą pristabdžius.</translation>
    </message>
    <message>
        <source>Avoid screensaver</source>
        <translation type="obsolete">Vengti skrynseiverio</translation>
    </message>
    <message>
        <source>Screensaver</source>
        <translation type="obsolete">Skrynseiveris</translation>
    </message>
    <message>
        <source>Swit&amp;ch screensaver off</source>
        <translation type="obsolete">Iš&amp;jungti skrynseiverį</translation>
    </message>
    <message>
        <source>Avoid &amp;screensaver</source>
        <translation type="obsolete">Vengti &amp;skrynseiverio</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="367"/>
        <source>Audio/video auto synchronization</source>
        <translation>Automatinis audio/video sinchronizavimas</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="368"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Švelniai priderina A/V sinchronizaciją, paremtą audio užlaikymo matavimu.</translation>
    </message>
    <message>
        <source>A-V sync correction</source>
        <translation type="obsolete">A/V sinchronizacijos korekcija</translation>
    </message>
    <message>
        <source>Maximum A-V sync correction per frame (in seconds)</source>
        <translation type="obsolete">Maksimali A/V sinchronizacijos korekcija kadrui (sekundėmis)</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation type="obsolete">Sinchronizacija</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="98"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Automatinis audio/video &amp;sinchronizavimas</translation>
    </message>
    <message>
        <source>&amp;Factor:</source>
        <translation type="obsolete">&amp;Faktorius:</translation>
    </message>
    <message>
        <source>A-V sync &amp;correction</source>
        <translation type="obsolete">A/V sinchronizacijos &amp;korekcija</translation>
    </message>
    <message>
        <source>&amp;Max. correction:</source>
        <translation type="obsolete">&amp;Maksimali korekcija:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note:&lt;/b&gt; This option won&apos;t be used for TV channels.</source>
        <translation type="obsolete">&lt;b&gt;Pastaba:&lt;/b&gt; Ši parinktis nenaudojama TV kanalams.</translation>
    </message>
    <message>
        <source>Dei&amp;nterlace by default (except for TV):</source>
        <translation type="obsolete">Pašalinti &quot;šukas&quot; &amp;neklausiant (išskyrus TV):</translation>
    </message>
    <message>
        <source>Disable video filters when using vdpau</source>
        <translation type="obsolete">Išjungia video filtrus naudojant vdpau</translation>
    </message>
    <message>
        <source>Usually video filters won&apos;t work when using vdpau as video output driver, so it&apos;s wise to keep this option checked.</source>
        <translation type="obsolete">Naudojant vdpau kaip video išvesties tvarkyklę, paprastai video filtrai neveikia, todėl būtų protinga šią parinktį palikti įjungtą.</translation>
    </message>
    <message>
        <source>Disable video filters when using vd&amp;pau</source>
        <translation type="obsolete">Išjungia video filtrus naudojant vd&amp;pau</translation>
    </message>
    <message>
        <source>Uses hardware AC3 passthrough.</source>
        <translation type="obsolete">Naudoti aparatinį AC3.</translation>
    </message>
    <message>
        <source>&lt;b&gt;Note:&lt;/b&gt; none of the audio filters will be used when this option is enabled.</source>
        <translation type="obsolete">&lt;b&gt;Pastaba:&lt;/b&gt; Jei pažymėta,joks audio filtras nebus naudojamas.</translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="obsolete">Klaviatūra ir pelė</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="obsolete">&amp;Klaviatūra</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">piktograma</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="obsolete">&amp;Pelė</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation type="obsolete">Mygtuko funkcijos:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation type="obsolete">Prasukimas</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation type="obsolete">Garso lygio kontrolė</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="obsolete">Didinti video</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nėra</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Čia galima keisti karštųjų klavišų parinktis. Tam dukart spragtelkite arba paspauskite &lt;i&gt;Enter&lt;/i&gt; reikalingame langelyje. Taip pat galima karštųjų klavišų sąrašą išsaugoti ir dalintis juo su kitais vartotojais arba įkelti kitame kompiuteryje.</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Čia galima keisti karštųjų klavišų parinktis. Tam dukart spragtelkite arba pradėkite rašyti reikalingame langelyje. Taip pat galima karštųjų klavišų sąrašą išsaugoti ir dalintis juo su kitais vartotojais arba įkelti kitame kompiuteryje.</translation>
    </message>
    <message>
        <source>&amp;Left click</source>
        <translation type="obsolete">&amp;Karysis paspaudimas</translation>
    </message>
    <message>
        <source>&amp;Double click</source>
        <translation type="obsolete">&amp;Dvigubas paspaudimas</translation>
    </message>
    <message>
        <source>&amp;Wheel function:</source>
        <translation type="obsolete">&amp;Ratuko funkcija:</translation>
    </message>
    <message>
        <source>Shortcut editor</source>
        <translation type="obsolete">Nuorodos redaktorius</translation>
    </message>
    <message>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation type="obsolete">Ši lentelė leidžia keisti įvairių veiksmų karštuosius klavišus. Dukart spragtelkite arba paspauskite &lt;i&gt;Enter&lt;/i&gt; reikalingame laukelyje, arba spauskite &lt;b&gt;Keisti nuorodą&lt;/b&gt; mygtuką, kad atsivertų keitimo dialogas. Yra du būdai pakeisti klavišų derinį: jei mygtukas &lt;b&gt;Užfiksavimas&lt;/b&gt; įspaustas - nuspausti reikalingą klavišų kombinaciją (veikia ne visiems klavišams). Jei mygtukas &lt;b&gt;Užfiksavimas&lt;/b&gt; neįspaustas, galima tiesiog įrašyti klavišų kombinacijos derinio pavadinimą.</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation type="obsolete">Karysis paspaudimas</translation>
    </message>
    <message>
        <source>Select the action for left click on the mouse.</source>
        <translation type="obsolete">Pasirinkite veiksmą dešiniajam pelės mygtukui.</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation type="obsolete">Dvigubas paspaudimas</translation>
    </message>
    <message>
        <source>Select the action for double click on the mouse.</source>
        <translation type="obsolete">Pasirinkite veiksmą dvigubam pelės paspaudimui.</translation>
    </message>
    <message>
        <source>Wheel function</source>
        <translation type="obsolete">Ratuko funkcija</translation>
    </message>
    <message>
        <source>Select the action for the mouse wheel.</source>
        <translation type="obsolete">Pasirinkite veiksmą pelės ratukui.</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="obsolete">Atkurti</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pauzė</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="obsolete">Per visą ekraną</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation type="obsolete">Kompaktiškas</translation>
    </message>
    <message>
        <source>Screenshot</source>
        <translation type="obsolete">Momentinis vaizdas</translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="obsolete">Be garso</translation>
    </message>
    <message>
        <source>Frame counter</source>
        <translation type="obsolete">Kadrų skaitiklis</translation>
    </message>
    <message>
        <source>Reset zoom</source>
        <translation type="obsolete">Atstatyti vaizdą</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="obsolete">Išeiti iš pilnaekranio režimo</translation>
    </message>
    <message>
        <source>Double size</source>
        <translation type="obsolete">Dvigubas dydis</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation type="obsolete">Atkurti / Pauzė</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation type="obsolete">Pauzė/kadrų žingsniu</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Grojaraštis</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Nuostatos</translation>
    </message>
    <message>
        <source>No function</source>
        <translation type="obsolete">Jokio veiksmo</translation>
    </message>
    <message>
        <source>Change speed</source>
        <translation type="obsolete">Pakeisti greitį</translation>
    </message>
    <message>
        <source>Normal speed</source>
        <translation type="obsolete">Normalus greitis</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klaviatūra</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Pelė</translation>
    </message>
    <message>
        <source>Middle click</source>
        <translation type="obsolete">Vidurinysis paspaudimas</translation>
    </message>
    <message>
        <source>Select the action for middle click on the mouse.</source>
        <translation type="obsolete">Pasirinkite veiksmą viduriniam pelės mygtukui.</translation>
    </message>
    <message>
        <source>M&amp;iddle click</source>
        <translation type="obsolete">Vi&amp;durinysis paspaudimas</translation>
    </message>
    <message>
        <source>X Button &amp;1</source>
        <translation type="obsolete">X mygtukas &amp;1</translation>
    </message>
    <message>
        <source>X Button &amp;2</source>
        <translation type="obsolete">X mygtukas &amp;2</translation>
    </message>
    <message>
        <source>Go backward (short)</source>
        <translation type="obsolete">Grįži (trumpai)</translation>
    </message>
    <message>
        <source>Go backward (medium)</source>
        <translation type="obsolete">Grįži (vidutiniškai)</translation>
    </message>
    <message>
        <source>Go backward (long)</source>
        <translation type="obsolete">Grįži (daug)</translation>
    </message>
    <message>
        <source>Go forward (short)</source>
        <translation type="obsolete">Į priekį (trumpai)</translation>
    </message>
    <message>
        <source>Go forward (medium)</source>
        <translation type="obsolete">Į priekį (vidutiniškai)</translation>
    </message>
    <message>
        <source>Go forward (long)</source>
        <translation type="obsolete">Į priekį (daug)</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="obsolete">OSD - Sekantis lygis</translation>
    </message>
    <message>
        <source>Show context menu</source>
        <translation type="obsolete">Rodyti kontekstinį meniu</translation>
    </message>
    <message>
        <source>&amp;Right click</source>
        <translation type="obsolete">&amp;Dešinysis paspaudimas</translation>
    </message>
    <message>
        <source>Increase volume</source>
        <translation type="obsolete">Pagarsinti</translation>
    </message>
    <message>
        <source>Decrease volume</source>
        <translation type="obsolete">Patildyti</translation>
    </message>
    <message>
        <source>X Button 1</source>
        <translation type="obsolete">X mygtukas 1</translation>
    </message>
    <message>
        <source>Select the action for the X button 1.</source>
        <translation type="obsolete">Pasirinkite veiksmą pirmam papildomam mygtukui.</translation>
    </message>
    <message>
        <source>X Button 2</source>
        <translation type="obsolete">X mygtukas 2</translation>
    </message>
    <message>
        <source>Select the action for the X button 2.</source>
        <translation type="obsolete">Pasirinkite veiksmą antram papildomam mygtukui.</translation>
    </message>
    <message>
        <source>Show video equalizer</source>
        <translation type="obsolete">Rodyti video ekvalaizerį</translation>
    </message>
    <message>
        <source>Show audio equalizer</source>
        <translation type="obsolete">Rodyti audio ekvalaizerį</translation>
    </message>
    <message>
        <source>Always on top</source>
        <translation type="obsolete">Visada viršuje</translation>
    </message>
    <message>
        <source>Never on top</source>
        <translation type="obsolete">Niekada viršuje</translation>
    </message>
    <message>
        <source>On top while playing</source>
        <translation type="obsolete">Viršuje kai atkuriama</translation>
    </message>
    <message>
        <source>Activate option under mouse in DVD menus</source>
        <translation type="obsolete">Aktyvuoti parinktį po pele DVD meniu</translation>
    </message>
    <message>
        <source>Return to main DVD menu</source>
        <translation type="obsolete">Grįžti į pagrindinį DVD meniu</translation>
    </message>
    <message>
        <source>Return to previous menu in DVD menus</source>
        <translation type="obsolete">Grįžti į ankstesnį DVD meniu</translation>
    </message>
    <message>
        <source>Move cursor up in DVD menus</source>
        <translation type="obsolete">Perstumti kursorių į viršų DVD meniu</translation>
    </message>
    <message>
        <source>Move cursor down in DVD menus</source>
        <translation type="obsolete">Perstumti kursorių į apačią DVD meniu</translation>
    </message>
    <message>
        <source>Move cursor left in DVD menus</source>
        <translation type="obsolete">Perstumti kursorių į kairę DVD meniu</translation>
    </message>
    <message>
        <source>Move cursor right in DVD menus</source>
        <translation type="obsolete">Perstumti kursorių į dešinę DVD meniu</translation>
    </message>
    <message>
        <source>Activate highlighted option in DVD menus</source>
        <translation type="obsolete">Aktyvuoti išryškintą DVD meniu parinktį</translation>
    </message>
    <message>
        <source>Change function of wheel</source>
        <translation type="obsolete">Pakeisti pelės ratuko funkciją</translation>
    </message>
    <message>
        <source>Reverse mouse wheel seeking</source>
        <translation type="obsolete">Priešingas pelės ratuko veikimas</translation>
    </message>
    <message>
        <source>Check it to seek in the opposite direction.</source>
        <translation type="obsolete">Pažymėkite tam, kad sukti į preišingą pusę.</translation>
    </message>
    <message>
        <source>R&amp;everse wheel media seeking</source>
        <translation type="obsolete">Pri&amp;ešingas pelės ratuko veikimas</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <source>Interface</source>
        <translation type="obsolete">Išvaizda</translation>
    </message>
    <message>
        <source>Volume normalization by default</source>
        <translation type="obsolete">Numatytas garso lygio normalizavimas</translation>
    </message>
    <message>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="obsolete">Padidina garso lygį be garso iškraipymo.</translation>
    </message>
    <message>
        <source>Default subtitle encoding</source>
        <translation type="obsolete">Numatytas subtitrų dekodavimas</translation>
    </message>
    <message>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="obsolete">Parinkti koduotę, kuri bus naudojama subtitrų failams automatiškai.</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation type="obsolete">Įkelti automatiškai</translation>
    </message>
    <message>
        <source>Select the subtitle autoload method.</source>
        <translation type="obsolete">Pasirinkite subtitrų automatinio įkėlimo metodą.</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation type="obsolete">&lt;Automatinis nustatymas&gt;</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="obsolete">Numatyta</translation>
    </message>
    <message>
        <source>&amp;Interface</source>
        <translation type="obsolete">&amp;Išvaizda</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Niekada</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation type="obsolete">Kai reikalinga</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation type="obsolete">Tik įkėlus naują video</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation type="obsolete">Paskutiniai failai</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Kalba</translation>
    </message>
    <message>
        <source>Here you can change the language of the application.</source>
        <translation type="obsolete">Čia galite pakeisti programos kalbą.</translation>
    </message>
    <message>
        <source>Ma&amp;x. items</source>
        <translation type="obsolete">Ma&amp;ksimalus meniu punktų skaičius</translation>
    </message>
    <message>
        <source>St&amp;yle:</source>
        <translation type="obsolete">St&amp;ilius:</translation>
    </message>
    <message>
        <source>L&amp;anguage:</source>
        <translation type="obsolete">K&amp;alba:</translation>
    </message>
    <message>
        <source>Main window</source>
        <translation type="obsolete">Pagrindinis langas</translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">Au&amp;tomatiškai keisti dydį:</translation>
    </message>
    <message>
        <source>R&amp;emember position and size</source>
        <translation type="obsolete">&amp;Įsiminti poziciją ir dydį</translation>
    </message>
    <message>
        <source>Default font:</source>
        <translation type="obsolete">Numatytas šriftas:</translation>
    </message>
    <message>
        <source>&amp;Change...</source>
        <translation type="obsolete">&amp;Keisti...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">Teksto etiketė</translation>
    </message>
    <message>
        <source>Ins&amp;tances</source>
        <translation type="obsolete">E&amp;gzemplioriai</translation>
    </message>
    <message>
        <source>Autoresize</source>
        <translation type="obsolete">Automatiškai keisti dydį</translation>
    </message>
    <message>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="obsolete">Pagrindinio lango dydis gali būti pakeistas automatiškai. Išrinkite mėgstamą parinktį.</translation>
    </message>
    <message>
        <source>Remember position and size</source>
        <translation type="obsolete">Prisiminti poziciją ir dydį</translation>
    </message>
    <message>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation type="obsolete">Parinkite maksimalų elementų, kurie bus rodomi &lt;b&gt;Atverti-&gt;Paskutiniai failai&lt;/b&gt; submeniu, skaičių. Jei nustatytas 0, šis meniu  iš viso nebus rodomas.</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Stilius</translation>
    </message>
    <message>
        <source>Select the style you prefer for the application.</source>
        <translation type="obsolete">Pasirinkite programos stilių.</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation type="obsolete">Numatytas šriftas</translation>
    </message>
    <message>
        <source>You can change here the application&apos;s font.</source>
        <translation type="obsolete">Čia galima pakeisti programos šriftą.</translation>
    </message>
    <message>
        <source>Instances</source>
        <translation type="obsolete">Egzemplioriai</translation>
    </message>
    <message>
        <source>Default GUI</source>
        <translation type="obsolete">Įprastinė aplinka</translation>
    </message>
    <message>
        <source>Automatic port</source>
        <translation type="obsolete">Automatinis jungties parinkimas</translation>
    </message>
    <message>
        <source>Manual port</source>
        <translation type="obsolete">Nurodyti jungtį</translation>
    </message>
    <message>
        <source>Port to listen</source>
        <translation type="obsolete">Jungtis praklausymui</translation>
    </message>
    <message>
        <source>&amp;Automatic</source>
        <translation type="obsolete">&amp;Automatiškai</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="obsolete">&amp;Rankiniu būdu</translation>
    </message>
    <message>
        <source>Floating control</source>
        <translation type="obsolete">Plaukiojanti valdymo panelė</translation>
    </message>
    <message>
        <source>Animated</source>
        <translation type="obsolete">Animuoti</translation>
    </message>
    <message>
        <source>If this option is enabled, the floating control will appear with an animation.</source>
        <translation type="obsolete">Jei pažymėta, valdymo panelė atsiras su animacija.</translation>
    </message>
    <message>
        <source>Width</source>
        <translation type="obsolete">Plotis</translation>
    </message>
    <message>
        <source>Specifies the width of the control (as a percentage).</source>
        <translation type="obsolete">Nustato valdymo panelės plotį (procentais).</translation>
    </message>
    <message>
        <source>Margin</source>
        <translation type="obsolete">Paraštė</translation>
    </message>
    <message>
        <source>This option sets the number of pixels that the floating control will be away from the bottom of the screen. Useful when the screen is a TV, as the overscan might prevent the control to be visible.</source>
        <translation type="obsolete">Ši parinktis nustato pikselių, per kiek plaukiojanti valdymo panelė bus nutolusi nuo ekrano apačios, skaičių. Reikalinga, kai ekranas yra televizorius ir vaizdas padidintas, dėl ko valdymo panelė bus nematoma.</translation>
    </message>
    <message>
        <source>Bypass window manager</source>
        <translation type="obsolete">Apeiti langų menedžerį</translation>
    </message>
    <message>
        <source>If this option is checked, the control is displayed bypassing the window manager. Disable this option if the floating control doesn&apos;t work well with your window manager.</source>
        <translation type="obsolete">Jei pažymėta, valdymo panelė rodoma apeinant langų valdytoją. Atjunkite šią parinktį, jei valdymo panelė su jūsų langų valdytoju veikia nekorektiškai.</translation>
    </message>
    <message>
        <source>&amp;Floating control</source>
        <translation type="obsolete">&amp;Plaukiojanti valdymo panelė</translation>
    </message>
    <message>
        <source>The floating control appears in fullscreen mode when the mouse is moved to the bottom of the screen.</source>
        <translation type="obsolete">Plaukiojanti valdymo panelė atsiranda viso ekrano režime, kai pelės žymeklis perkeliamas į ekrano apačią.</translation>
    </message>
    <message>
        <source>&amp;Animated</source>
        <translation type="obsolete">&amp;Animuoti</translation>
    </message>
    <message>
        <source>&amp;Width:</source>
        <translation type="obsolete">P&amp;lotis:</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>&amp;Margin:</source>
        <translation type="obsolete">&amp;Paraštė:</translation>
    </message>
    <message>
        <source>&amp;Bypass window manager</source>
        <translation type="obsolete">&amp;Apeiti langų menedžerį</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Subtitrai</translation>
    </message>
    <message>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="obsolete">Au&amp;tomatiškai įkelti subtitrų failus (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation type="obsolete">Vardas kaip ir filmo</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation type="obsolete">Visi subtitrai turi filmo vardą</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation type="obsolete">Visi subtitrai kataloge</translation>
    </message>
    <message>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="obsolete">Pirminis subtitrų &amp;dekodavimas:</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="obsolete">Audio</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Garso lygio &amp;normalizavimas neklausus</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <source>Performance</source>
        <translation type="obsolete">Greitaveika</translation>
    </message>
    <message>
        <source>&amp;Performance</source>
        <translation type="obsolete">&amp;Greitaveika</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="obsolete">Prioritetas</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="obsolete">Pažymėkite MPlayer&apos;io proceso prioriteto lygį.</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="obsolete">realiam laike</translation>
    </message>
    <message>
        <source>high</source>
        <translation type="obsolete">aukštas</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="obsolete">aukštesnis nei normalus</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="obsolete">normalus</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="obsolete">žemesnis už normalų</translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="obsolete">žemas</translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="obsolete">KB</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation type="obsolete">Talpyklos nustatymas gali pagerinti arba pabloginti greitaveiką</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="obsolete">Leisti praleisti kadrus</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="obsolete">Praleisti kai kuriuos kadrus audio/video sinchronizacijai lėtose sistemose.</translation>
    </message>
    <message>
        <source>Allow hard frame drop</source>
        <translation type="obsolete">Leisti kietą kadrų praleidimą</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="obsolete">Kietesnis kadrų praleidimas (plėšytas atkūrimas) sukelia vaizdo iškraipymus!</translation>
    </message>
    <message>
        <source>Priorit&amp;y:</source>
        <translation type="obsolete">&amp;Prioritetas:</translation>
    </message>
    <message>
        <source>&amp;Allow frame drop</source>
        <translation type="obsolete">Leisti pr&amp;aleisti kadrus</translation>
    </message>
    <message>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation type="obsolete">Leisti &amp;kietą kadrų praleidimą (gali sukelti vaizdo iškraipymus)</translation>
    </message>
    <message>
        <source>&amp;Fast audio track switching</source>
        <translation type="obsolete">&amp;Greitas audio takelių perjungimas</translation>
    </message>
    <message>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation type="obsolete">Greita DVD &amp;skyrių paieška</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation type="obsolete">Greitas audio takelių perjungimas</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation type="obsolete">Greita DVD skyrių paieška</translation>
    </message>
    <message>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation type="obsolete">Jei pažymėta, bus pabandytas spartesnis skyrių paieškos metodas, bet dali neveikti kai kuriuose diskuose.</translation>
    </message>
    <message>
        <source>Skip loop filter</source>
        <translation type="obsolete">Praleisti kilpinį filtrą</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation type="obsolete">H.264</translation>
    </message>
    <message>
        <source>Cache for files</source>
        <translation type="obsolete">Talpykla failams</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation type="obsolete">Ši nuostata apibrėžia kiek atminties (kilobaitais) bus naudojama išankstiniam failų talpinimui.</translation>
    </message>
    <message>
        <source>Cache for streams</source>
        <translation type="obsolete">Srautų talpykla</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation type="obsolete">Ši nuostata apibrėžia kiek atminties (kilobaitais) bus naudojama išankstiniam URL talpinimui.</translation>
    </message>
    <message>
        <source>Cache for DVDs</source>
        <translation type="obsolete">Laikina DVD talpykla</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation type="obsolete">Ši nuostata apibrėžia kiek atminties (kilobaitais) bus naudojama išankstiniam DVD talpinimui. &lt;br&gt;&lt;b&gt;Dėmesio:&lt;/b&gt; Naudojant išankstinį DVD talpinimą, prasukimas gali blogai veikti (įskaitant ir skyrių perjungimą).</translation>
    </message>
    <message>
        <source>&amp;Cache</source>
        <translation type="obsolete">&amp;Laikina atmintinė</translation>
    </message>
    <message>
        <source>Cache for &amp;DVDs:</source>
        <translation type="obsolete">Laikina &amp;DVD talpykla:</translation>
    </message>
    <message>
        <source>Cache for &amp;local files:</source>
        <translation type="obsolete">Ta&amp;lpykla vietiniams failams:</translation>
    </message>
    <message>
        <source>Cache for &amp;streams:</source>
        <translation type="obsolete">&amp;Srautų talpykla:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Įjungta</translation>
    </message>
    <message>
        <source>Skip (always)</source>
        <translation type="obsolete">Praleisti (visada)</translation>
    </message>
    <message>
        <source>Skip only on HD videos</source>
        <translation type="obsolete">Praleisti tik HD video</translation>
    </message>
    <message>
        <source>Loop &amp;filter</source>
        <translation type="obsolete">Kilpinis &amp;filtras</translation>
    </message>
    <message>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation type="obsolete">Ši parinktis įgalina praleisti kilpinį filtrą (deblokingą) dekoduojant H.264. Kadangi filtruotą kadrą numatoma naudoti kaip priklausomų kadrų dekodavimo nuorodą, tai, pavyzdžiui MPEG-2, video kokybė bus prastesnė, negu deblokingas nebūtų iš viso vykdomas. Bet aukštos kokybės HDTV tai duoda ryškų darbingumo padidėjimą be įžvelgiamo kokybės suprastėjimo.</translation>
    </message>
    <message>
        <source>Possible values:</source>
        <translation type="obsolete">Galimos reikšmės:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation type="obsolete">&lt;b&gt;Įjungtas&lt;/b&gt;: kilpinis filtras nepraleidžiamas</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation type="obsolete">&lt;b&gt;Praleisti (visada)&lt;/b&gt;: kilpinis filtras nenaudojamas nepriklausomai nuo video raiškos</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation type="obsolete">&lt;b&gt;Praleisti tik HD video&lt;/b&gt;: kilpinis filtras bus praleistas tik  %1 aukščio ar geresniam video.</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="obsolete">Laikina atmintinė</translation>
    </message>
    <message>
        <source>Cache for audio CDs</source>
        <translation type="obsolete">Audio CD talpykla</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation type="obsolete">Ši nuostata apibrėžia kiek atminties (kilobaitais) bus naudojama išankstiniam audio CD talpinimui.</translation>
    </message>
    <message>
        <source>Cache for &amp;audio CDs:</source>
        <translation type="obsolete">&amp;Audio CD talpykla:</translation>
    </message>
    <message>
        <source>Cache for VCDs</source>
        <translation type="obsolete">VCD talpykla</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation type="obsolete">Ši nuostata apibrėžia kiek atminties (kilobaitais) bus naudojama išankstiniam VCD talpinimui.</translation>
    </message>
    <message>
        <source>Cache for &amp;VCDs:</source>
        <translation type="obsolete">&amp;VCD talpykla:</translation>
    </message>
    <message>
        <source>Threads for decoding</source>
        <translation type="obsolete">Srautai dekodavimui</translation>
    </message>
    <message>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation type="obsolete">Nustato srautų dekodavimui skaičių (tik MPEG-1/2 ir H.264)</translation>
    </message>
    <message>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation type="obsolete">Srau&amp;tai dekodavimui (tik MPEG-1/2 ir H.264):</translation>
    </message>
    <message>
        <source>Set process priority for mplayer according to the predefined priorities available under Windows.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Using realtime priority can cause system lockup.</source>
        <translation type="obsolete">Nustato MPlayer&apos;io prioritetą sutinkamai su Windows nustatytais procesų prioritetais. &lt;br&gt;&lt;b&gt;Dėmesio:&lt;/b&gt; Realaus laiko prioriteto naudojimas, gali sulėtinti sistemos darbą.</translation>
    </message>
    <message>
        <source>Use CoreAVC if no other codec specified</source>
        <translation type="obsolete">Jei nenurodytas joks kitas kodekas, naudoti &lt;i&gt;CoreAVC&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Try to use non-free CoreAVC codec with no other codec is specified and non-VDPAU video output selected. Requires MPlayer build with CoreAVC support.</source>
        <translation type="obsolete">Jei nenurodytas joks kodekas ir pasirinkta ne VDPAU video išvestis, pabandyti naudoti nelaisvą CoreAVC kodeką. Reikalingas MPlayer sukurtas su CoreAVC palaikymu.</translation>
    </message>
    <message>
        <source>&amp;Use CoreAVC if no other codec specified</source>
        <translation type="obsolete">Jei nen&amp;urodytas joks kitas kodekas, naudoti CoreAVC</translation>
    </message>
    <message>
        <source>Cache for &amp;TV:</source>
        <translation type="obsolete">&amp;TV talpykla:</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation type="unfinished">Subtitrai</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished">Proritetinė audio ir subtitrų kalba</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation type="obsolete">Pasirinkti ttf failą</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation type="obsolete">TrueType šriftai</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="obsolete">&amp;Subtitrai</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation type="unfinished">Įkelti automatiškai</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation type="unfinished">Vardas kaip ir filmo</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation type="unfinished">Visi subtitrai turi filmo vardą</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation type="unfinished">Visi subtitrai kataloge</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="obsolete">Pozicija</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="obsolete">Viršuje</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="obsolete">Apačioje</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="obsolete">Šriftas</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation type="obsolete">Parinkite šriftą subtitrams (ir OSD):</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Dydis</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation type="obsolete">Be automatinio padėties nustatymo</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation type="obsolete">Proporcingai filmo aukščiui</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation type="obsolete">Proporcingai filmo pločiui</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation type="obsolete">Proporcingai filmo įstrižainei</translation>
    </message>
    <message>
        <source>Subtitle position</source>
        <translation type="obsolete">Subtitrų pozicija</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="obsolete">Ši parinktis nustato subtitrų padėtį lango atžvilgiu. &lt;i&gt;100&lt;/i&gt;  reiškia apačioje, &lt;i&gt;0&lt;/i&gt; - viršuje.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished">Au&amp;tomatiškai įkelti subtitrų failus (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>S&amp;elect first available subtitle</source>
        <translation type="obsolete">Pažymėti pirmą &amp;esamą surtitrą</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="unfinished">Pirminis subtitrų &amp;dekodavimas:</translation>
    </message>
    <message>
        <source>Default &amp;position of the subtitles on screen</source>
        <translation type="obsolete">Numatyta subtitrų &amp;pozicija ekrane</translation>
    </message>
    <message>
        <source>&amp;Include subtitles on screenshots</source>
        <translation type="obsolete">&amp;Įtraukti subtitrus į momentinius vaizdus</translation>
    </message>
    <message>
        <source>&amp;TTF font:</source>
        <translation type="obsolete">&amp;TTF šriftas:</translation>
    </message>
    <message>
        <source>S&amp;ystem font:</source>
        <translation type="obsolete">S&amp;isteminis šriftas:</translation>
    </message>
    <message>
        <source>A&amp;utoscale:</source>
        <translation type="obsolete">A&amp;utomatinis padėties nustatymas:</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="obsolete">Pažymėti pirmą esamą surtitrą</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation type="unfinished">Numatytas subtitrų dekodavimas</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation type="obsolete">Įtraukti subtitrus į momentinius vaizdus</translation>
    </message>
    <message>
        <source>TTF font</source>
        <translation type="obsolete">TTF šriftas</translation>
    </message>
    <message>
        <source>System font</source>
        <translation type="obsolete">Sisteminis šriftas</translation>
    </message>
    <message>
        <source>Here you can select a system font to be used for the subtitles and OSD. &lt;b&gt;Note:&lt;/b&gt; requires a MPlayer with fontconfig support.</source>
        <translation type="obsolete">Čia galima nurodyti sisteminį šriftą, kuris bus naudojamas subtitrams ir OSD. &lt;b&gt;Pastaba:&lt;/b&gt; reikalingas MPLayer, palaikantis &lt;b&gt;fontconfig&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Autoscale</source>
        <translation type="obsolete">Automatinis padėties nustatymas</translation>
    </message>
    <message>
        <source>Text color</source>
        <translation type="obsolete">Teksto spalva</translation>
    </message>
    <message>
        <source>Select the color for the text of the subtitles.</source>
        <translation type="obsolete">Pasirinkite subtitrų teksto spalvą.</translation>
    </message>
    <message>
        <source>Border color</source>
        <translation type="obsolete">Rėmelio spalva</translation>
    </message>
    <message>
        <source>Select the color for the border of the subtitles.</source>
        <translation type="obsolete">Pasirinkite subtitrų rėlelio spalvą.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation type="unfinished">Pasirinkite subtitrų automatinio įkėlimo metodą.</translation>
    </message>
    <message>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation type="obsolete">Jei yra vienas ar daugiau subtitrų takelių, vienas iš jų bus automatiškai parinktas, dažniausiai pirmas, tačiau jei vienas iš subtitrų takelių atitinka vartotojo pasirinktą kalbą, tai bus parinktas būtent tas subtitrų takelis.</translation>
    </message>
    <message>
        <source>Select the subtitle autoscaling method.</source>
        <translation type="obsolete">Pasirinkite subtitrų automatinio įkėlimo metodą.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="unfinished">Parinkti koduotę, kuri bus naudojama subtitrų failams automatiškai.</translation>
    </message>
    <message>
        <source>Try to autodetect for this language</source>
        <translation type="obsolete">Pabandyti automatiškai nustatyti šiai kalbai</translation>
    </message>
    <message>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a MPlayer compiled with ENCA support.</source>
        <translation type="obsolete">Jei parinktis įjungta, bus pabandyta automatiškai nustatyti subtitrų koduotę šiai kalbai. Nepavykus, bus naudojama pirminė koduotė. Parinktis reikalauja su ENCA palaikymu sukompiliuoto MPlayer&apos;io.</translation>
    </message>
    <message>
        <source>Subtitle language</source>
        <translation type="obsolete">Subtitrų kalba</translation>
    </message>
    <message>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation type="obsolete">Parinkite kalbą, kuriai bus naudojamas automatinis subtitrų kodiruotės nustatymas.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation type="unfinished">Dekodavimas</translation>
    </message>
    <message>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation type="obsolete">&amp;Automatiškai nustatyti šiai kalbai:</translation>
    </message>
    <message>
        <source>Here you can select a ttf font to be used for the subtitles. Usually you&apos;ll find a lot of ttf fonts in %1</source>
        <translation type="obsolete">Čia galima parinkti ttf šriftą subtitrams. Paprastai daug ttf šriftų galima rasti %1</translation>
    </message>
    <message>
        <source>Outline</source>
        <translation type="obsolete">Kontūras</translation>
    </message>
    <message>
        <source>Select the font for the subtitles.</source>
        <translation type="obsolete">Parinkite subtitrų šriftą.</translation>
    </message>
    <message>
        <source>The size in pixels.</source>
        <translation type="obsolete">Dydis pikseliais.</translation>
    </message>
    <message>
        <source>Bold</source>
        <translation type="obsolete">Paryškintas</translation>
    </message>
    <message>
        <source>If checked, the text will be displayed in &lt;b&gt;bold&lt;/b&gt;.</source>
        <translation type="obsolete">Jei pažymėta, tekstas bus rodomas &lt;b&gt;paryškintas&lt;/b&gt;.</translation>
    </message>
    <message>
        <source>Italic</source>
        <translation type="obsolete">Pasviręs</translation>
    </message>
    <message>
        <source>If checked, the text will be displayed in &lt;i&gt;italic&lt;/i&gt;.</source>
        <translation type="obsolete">Jei pažymėta, tekstas bus rodomas &lt;i&gt;pasviręs&lt;/i&gt;.</translation>
    </message>
    <message>
        <source>Left margin</source>
        <translation type="obsolete">Kairė paraštė</translation>
    </message>
    <message>
        <source>Specifies the left margin in pixels.</source>
        <translation type="obsolete">Nusako kairę paraštę (pikseliais).</translation>
    </message>
    <message>
        <source>Right margin</source>
        <translation type="obsolete">Dešinė paraštė</translation>
    </message>
    <message>
        <source>Specifies the right margin in pixels.</source>
        <translation type="obsolete">Nusako dešinę paraštę (pikseliais).</translation>
    </message>
    <message>
        <source>Vertical margin</source>
        <translation type="obsolete">Vertikali paraštė</translation>
    </message>
    <message>
        <source>Specifies the vertical margin in pixels.</source>
        <translation type="obsolete">Nusako vertikalią paraštę (pikseliais).</translation>
    </message>
    <message>
        <source>Horizontal alignment</source>
        <translation type="obsolete">Horizontalus lygiavimas</translation>
    </message>
    <message>
        <source>Specifies the horizontal alignment. Possible values are left, centered and right.</source>
        <translation type="obsolete">Nusako horizontalų lygiavimą. Galimas kairinis, centrinis ir dešininis.</translation>
    </message>
    <message>
        <source>Vertical alignment</source>
        <translation type="obsolete">Vertikalus lygiavimas</translation>
    </message>
    <message>
        <source>Specifies the vertical alignment. Possible values: bottom, middle and top.</source>
        <translation type="obsolete">Nusako vertikalų lygiavimą. Galimas apatinis, vidurinis ir viršutinis.</translation>
    </message>
    <message>
        <source>Border style</source>
        <translation type="obsolete">Rėmelio stilius</translation>
    </message>
    <message>
        <source>Specifies the border style. Possible values: outline and opaque box.</source>
        <translation type="obsolete">Nusako rėmelio stilių. Galimas kontūras ir neperšviečiamas.</translation>
    </message>
    <message>
        <source>Shadow</source>
        <translation type="obsolete">Šešėlis</translation>
    </message>
    <message>
        <source>Si&amp;ze:</source>
        <translation type="obsolete">D&amp;ydis:</translation>
    </message>
    <message>
        <source>Bol&amp;d</source>
        <translation type="obsolete">Pa&amp;ryškintas</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation type="obsolete">Pasv&amp;iręs</translation>
    </message>
    <message>
        <source>Colors</source>
        <translation type="obsolete">Spalvos</translation>
    </message>
    <message>
        <source>&amp;Text:</source>
        <translation type="obsolete">&amp;Tekstas:</translation>
    </message>
    <message>
        <source>&amp;Border:</source>
        <translation type="obsolete">&amp;Rėmelis:</translation>
    </message>
    <message>
        <source>Margins</source>
        <translation type="obsolete">Paraštės</translation>
    </message>
    <message>
        <source>L&amp;eft:</source>
        <translation type="obsolete">&amp;Kairė:</translation>
    </message>
    <message>
        <source>&amp;Right:</source>
        <translation type="obsolete">&amp;Dešinė:</translation>
    </message>
    <message>
        <source>Verti&amp;cal:</source>
        <translation type="obsolete">&amp;Vertikali:</translation>
    </message>
    <message>
        <source>Alignment</source>
        <translation type="obsolete">Išlyginimas</translation>
    </message>
    <message>
        <source>&amp;Horizontal:</source>
        <translation type="obsolete">&amp;Horizontalus:</translation>
    </message>
    <message>
        <source>&amp;Vertical:</source>
        <translation type="obsolete">&amp;Vertikalus:</translation>
    </message>
    <message>
        <source>Border st&amp;yle:</source>
        <translation type="obsolete">Rėmelio st&amp;ilius:</translation>
    </message>
    <message>
        <source>&amp;Outline:</source>
        <translation type="obsolete">K&amp;ontūras:</translation>
    </message>
    <message>
        <source>Shado&amp;w:</source>
        <translation type="obsolete">&amp;Šešėlis:</translation>
    </message>
    <message>
        <source>The following options allows you to define the style to be used for non-styled subtitles (srt, sub...).</source>
        <translation type="obsolete">Šios nuostatos padės nustatyti nestilizuotų subtitrų (srt, sub...) stilių.</translation>
    </message>
    <message>
        <source>Left</source>
        <comment>horizontal alignment</comment>
        <translation type="obsolete">Iš kairės</translation>
    </message>
    <message>
        <source>Centered</source>
        <comment>horizontal alignment</comment>
        <translation type="obsolete">Per vidurį</translation>
    </message>
    <message>
        <source>Right</source>
        <comment>horizontal alignment</comment>
        <translation type="obsolete">Iš dešinės</translation>
    </message>
    <message>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">Apačioje</translation>
    </message>
    <message>
        <source>Middle</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">Per vidurį</translation>
    </message>
    <message>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">Viršuje</translation>
    </message>
    <message>
        <source>Outline</source>
        <comment>border style</comment>
        <translation type="obsolete">Kontūras</translation>
    </message>
    <message>
        <source>Opaque box</source>
        <comment>border style</comment>
        <translation type="obsolete">Nepermatomas</translation>
    </message>
    <message>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the width of the outline around the text in pixels.</source>
        <translation type="obsolete">Jei rėmelio stilius nustatytas &lt;i&gt;kontūre&lt;/i&gt;, ši parinktis nustato kontūro plotį aplink tekstą (pikseliais).</translation>
    </message>
    <message>
        <source>If border style is set to &lt;i&gt;outline&lt;/i&gt;, this option specifies the depth of the drop shadow behind the text in pixels.</source>
        <translation type="obsolete">Jei rėmelio stilius nustatytas &lt;i&gt;neperšviečiamas&lt;/i&gt;, ši parinktis nustato teksto metamo šešėlio ilgį (pikseliais).</translation>
    </message>
    <message>
        <source>Enable normal subtitles</source>
        <translation type="obsolete">Įjungti normalius subtitrus</translation>
    </message>
    <message>
        <source>Click this button to select the normal/traditional subtitles. This kind of subtitles can only display white subtitles.</source>
        <translation type="obsolete">Paspauskite šį mygtuką normalių/tradicinių subtitrų parinkimui. Ši subtitrų rūšis gali vaizduoti tik baltus subtitrus.</translation>
    </message>
    <message>
        <source>Enable SSA/ASS subtitles</source>
        <translation type="obsolete">Įjungti SSA/ASS subtitrus</translation>
    </message>
    <message>
        <source>Normal subtitles</source>
        <translation type="obsolete">Normalūs subtitrai</translation>
    </message>
    <message>
        <source>This option does NOT change the size of the subtitles in the current video. To do so, use the options &lt;i&gt;Size+&lt;/i&gt; and &lt;i&gt;Size-&lt;/i&gt; in the subtitles menu.</source>
        <translation type="obsolete">Ši parinktis NEPAKEIČIA atkuriamo video subtitrų dydžio. Tam naudokite &lt;i&gt;Dydis+&lt;/i&gt; ir &lt;i&gt;Dydis-&lt;/i&gt; nuostatas subtitrų meniu.</translation>
    </message>
    <message>
        <source>Default scale</source>
        <translation type="obsolete">Numatytas dydis</translation>
    </message>
    <message>
        <source>This option specifies the default font scale for normal subtitles which will be used for new opened files.</source>
        <translation type="obsolete">Ši parinktis apibūdina pradinį subtitrų šrifto dydį, kuris bus naudojamas naujai atveriamiems failams.</translation>
    </message>
    <message>
        <source>SSA/ASS subtitles</source>
        <translation type="obsolete">SSA/ASS subtitrai</translation>
    </message>
    <message>
        <source>This option specifies the default font scale for SSA/ASS subtitles which will be used for new opened files.</source>
        <translation type="obsolete">Ši parinktis nustato SSA/ASS subtitrų šrifto, kuris bus naudojamas naujai atvertiems video, dydį.</translation>
    </message>
    <message>
        <source>Line spacing</source>
        <translation type="obsolete">Tarpas tarp eilučių</translation>
    </message>
    <message>
        <source>This specifies the spacing that will be used to separate multiple lines. It can have negative values.</source>
        <translation type="obsolete">Nurodomas intervalas, kuris bus naudojamas eilutėms atskirti. Gali būti neigiamas.</translation>
    </message>
    <message>
        <source>&amp;Font and colors</source>
        <translation type="obsolete">&amp;Šriftas ir spalvos</translation>
    </message>
    <message>
        <source>Enable &amp;normal subtitles</source>
        <translation type="obsolete">Įjungti &amp;normalius subtitrus</translation>
    </message>
    <message>
        <source>Enable SSA/&amp;ASS subtitles</source>
        <translation type="obsolete">Įjungti SSA/&amp;ASS subtitrus</translation>
    </message>
    <message>
        <source>Default s&amp;cale:</source>
        <translation type="obsolete">Numatytas &amp;dydis:</translation>
    </message>
    <message>
        <source>Defa&amp;ult scale:</source>
        <translation type="obsolete">N&amp;ustatytas dydis:</translation>
    </message>
    <message>
        <source>&amp;Line spacing:</source>
        <translation type="obsolete">&amp;Tarpas tarp eilučių:</translation>
    </message>
    <message>
        <source>Click this button to enable the new SSA/ASS library. This allows to display subtitles with multiple colors, fonts...</source>
        <translation type="obsolete">Šis mygtukas įjungia naują SSA/ASS biblioteką. Tai įgalina naudoti skirtingų spalvų ir šriftų subtitrus...</translation>
    </message>
    <message>
        <source>Freetype support</source>
        <translation type="obsolete">Freetype palaikymas</translation>
    </message>
    <message>
        <source>You should normally not disable this option. Do it only if your MPlayer is compiled without freetype support. &lt;b&gt;Disabling this option could make that subtitles won&apos;t work at all!&lt;/b&gt;</source>
        <translation type="obsolete">Įprastai šios parinkties galima neišjungti.Išjunkite ją, jei MPlayer yra sukompiliuotas be &lt;i&gt;freetype&lt;/i&gt; palaikymo. &lt;b&gt;Dėl šios parinkties išjungimo subtitrai gali iš viso neveikti!&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Freet&amp;ype support</source>
        <translation type="obsolete">Freet&amp;ype palaikymas</translation>
    </message>
    <message>
        <source>If this option is checked, the subtitles will appear in the screenshots. &lt;b&gt;Note:&lt;/b&gt; it may cause some troubles sometimes.</source>
        <translation type="obsolete">Jei pažymėta, subtitrai bus matomi ekrano nuotraukose. &lt;b&gt;Pastaba:&lt;/b&gt; kartais tai gali sukelti keblumų.</translation>
    </message>
    <message>
        <source>Customize SSA/ASS style</source>
        <translation type="obsolete">Nustatyti SSA/ASS subtitrų stilių</translation>
    </message>
    <message>
        <source>Here you can enter your customized SSA/ASS style.</source>
        <translation type="obsolete">Čia galima įvesti norimą SSA/ASS subtitrų stilių.</translation>
    </message>
    <message>
        <source>Clear the edit line to disable the customized style.</source>
        <translation type="obsolete">Nustatyto stiliaus išjungimui išvalyti įvedimo lauką.</translation>
    </message>
    <message>
        <source>SSA/ASS style</source>
        <translation type="obsolete">SSA/ASS stilius</translation>
    </message>
    <message>
        <source>Shadow color</source>
        <translation type="obsolete">Šešėlio spalva</translation>
    </message>
    <message>
        <source>This color will be used for the shadow of the subtitles.</source>
        <translation type="obsolete">Ši spalva bus naudojama subtitrų šešėliui.</translation>
    </message>
    <message>
        <source>Shadow:</source>
        <translation type="obsolete">Šešėlis:</translation>
    </message>
    <message>
        <source>Custo&amp;mize...</source>
        <translation type="obsolete">&amp;Modifikuoti...</translation>
    </message>
    <message>
        <source>Apply style to ass files too</source>
        <translation type="obsolete">Pritaikyti stilių taip pat ir &lt;i&gt;ass&lt;/i&gt; failams</translation>
    </message>
    <message>
        <source>If this option is checked, the style defined above will be applied to ass subtitles too.</source>
        <translation type="obsolete">Jei pažymėta, pasirinktas stilius bus pritaikytas taip pat ir &lt;i&gt;ass&lt;/i&gt; formato subtitrams.</translation>
    </message>
    <message>
        <source>A&amp;pply style to ass files too</source>
        <translation type="obsolete">&amp;Pritaikyti stilių taip pat ir ass failams</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <source>TV and radio</source>
        <translation type="obsolete">Televizija ir radijas</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nėra</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">Lowpass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normaliai)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (dviguba kokybė)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Linijinis maišymas</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Adaptuota</translation>
    </message>
    <message>
        <source>Deinterlace by default for TV</source>
        <translation type="obsolete">Pašalinti TV &quot;šukas&quot; neklausiant</translation>
    </message>
    <message>
        <source>Select the deinterlace filter that you want to be used for TV channels.</source>
        <translation type="obsolete">Parinkti &quot;šukų&quot; pašalinimo filtrą TV kanalams.</translation>
    </message>
    <message>
        <source>Rescan ~/.mplayer/channels.conf on startup</source>
        <translation type="obsolete">Perskanuoti &lt;i&gt;~/.mplayer/channels.conf&lt;/i&gt; startuojant</translation>
    </message>
    <message>
        <source>&amp;TV and radio</source>
        <translation type="obsolete">&amp;Televizija ir radijas</translation>
    </message>
    <message>
        <source>Dei&amp;nterlace by default for TV:</source>
        <translation type="obsolete">Pašalinti TV &quot;šukas&quot; &amp;neklausiant:</translation>
    </message>
    <message>
        <source>&amp;Check for new channels on startup</source>
        <translation type="obsolete">Tiktinti ar nėra &amp;naujų kanalų pradedant</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>OK</source>
        <translation type="obsolete">Gerai</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="161"/>
        <source>Close</source>
        <translation type="unfinished">Uždaryti</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Atšauk</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Pritaikyti</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Pagalba</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>bus parodytas šis pranešimas ir programa baigs darbą.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>pagrindinis langas bus užvertas, kai failas/grojaraštis bus baigtas.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>bando susijungti su kitu paleistu egzemplioriumi ir pasiųsti jam užduotą veiksmą. Pavyzdys: &lt;i&gt;-send-action pause&lt;/i&gt;. Likusios parinktys (jei jų yra) bus ignoruotos ir programa baigs darbą. Sėkmingai įvykdžius užduotį ji grąžins 0, nesėkmės atveju grąžins -1.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>&lt;i&gt;veiksmų_sąrašas&lt;/i&gt; yra veiksmų, atskirtų tarpais, sąrašas. Šie veiksmai bus vykdomi po failo įkėlimo nurodyta tvarka. Veiksmams su kintamomis reikšmėmis galima naudoti &lt;i&gt;true&lt;/i&gt; arba &lt;i&gt;false&lt;/i&gt; parametrus. Pavyzdžiui:&lt;i&gt;-actions &quot;fullscreen compact true&quot;&lt;/i&gt;. Kabutės yra reikalingos jei naudojamas daugiau negu vienas veiksmas.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>jei jau yra paleistas programos egzempliorius, tai media failai bus pridėti į jau egzistuojantį grojaraštį. Priešingu atveju parinktis bus ignoruota ir failai bus atverti naujame programos egzemplioriuje.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>pagrindinis langas nebus užvertas, kai failas/grojaraštis bus baigtas.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>video bus atkuriamas pilno ekrano režimu.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>video bus atkuriamas lango režimu.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Atstato senas asociacijas ir išvalo registrą.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Naudojimas:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>katalogas</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>veiksmo_pavadinimas</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>veiksmų_sąrašas</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>atveria numatytą aplinką.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>subtitrų_failas</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>nurodomas subtitrų failas, kuris bus įkeltas pirmam video.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation>
            <numerusform>%1 sekundė</numerusform>
            <numerusform>%1 sekundės</numerusform>
            <numerusform>%1 sekundžių</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation>
            <numerusform>%1 minutė</numerusform>
            <numerusform>%1 minutės</numerusform>
            <numerusform>%1 minučių</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 ir %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="189"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>išjungta</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="219"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="222"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>nežinoma</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation>plotis</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation>aukštis</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>nurodo pagrindinio programos lango viršutinio kairiojo kampo koordinates.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation>nurodo pagrindinio lango dydį.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="467"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>IP/UNZIP API klaida %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="155"/>
        <source>Source #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="155"/>
        <source>Name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="192"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="195"/>
        <source>Unknown error in recording occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="198"/>
        <source>Sorry, recording crashed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="63"/>
        <source>/Screencast - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="66"/>
        <source>\Screencast-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Information</source>
        <translation type="unfinished">Informacija</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="118"/>
        <source>Length: %1
Size: %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreencastDialog</name>
    <message>
        <location filename="../screencast.ui" line="20"/>
        <source>Video capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="98"/>
        <source>Record audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="65"/>
        <source>Start capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="75"/>
        <source>Cancel</source>
        <translation type="unfinished">Atšauk</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="34"/>
        <location filename="../screencast.cpp" line="99"/>
        <source>not recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="82"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="44"/>
        <source>line-out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="39"/>
        <source>microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="43"/>
        <source>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;WARNING: The audio subsystem needs to be restarted before recording from the line-out. It may cause interruption of currently playing sound.&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="48"/>
        <source>&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>piktograma</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>etiketė</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Keisti nuorodą</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Išvalyti</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Paspauskite klavišų, kuriuos norite priskirti, kombinaciją</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Užfiksavimas</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Užfiksuoti klavišų paspaudimus</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation type="unfinished">Informacija</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation type="unfinished">Gerai</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished">Atšauk</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Subtitrų pasirinkimas</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Archyve yra daugiau nei vienas subtitrų failas. Pasirinkitę vieną, kurį norite išgauti.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Pažymėti visus</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Nepažymėti nei vieno</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="100"/>
        <source>Channel editor</source>
        <translation>Kanalų redaktorius</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="101"/>
        <source>TV/Radio list</source>
        <translation>TV/radijo stočių sąrašas</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Šokti į:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Taip</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>Ne</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Contrast</source>
        <translation>Kontrastas</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Brightness</source>
        <translation>Ryškumas</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Hue</source>
        <translation>Atspalvis</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Saturation</source>
        <translation>Sodrumas</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>Gamma</source>
        <translation>Gama</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="98"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Uždaryti</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>&amp;Reset</source>
        <translation>&amp;Atstatyti</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="100"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Nustatyti kaip numatytas reikšmes</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="104"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Nustatyti dabartines reikšnes kaip numatytas naujiems video.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="106"/>
        <source>Set all controls to zero.</source>
        <translation>Nustatyti visas reikšmes lygias nuliui.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Video Equalizer</source>
        <translation>Video ekvalaizeris</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="126"/>
        <source>Information</source>
        <translation>Informacija</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="127"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Dabartiniai parametrai buvo išsaugoti kaip pradiniai.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation>Video peržiūra</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Atšauk</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation>Kuriami paveikslėliai...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation>Dydis: %1 MB</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation>Trukmė: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation>Išsaugoti failą</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation>Failo išsaugojimo klaida</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Failas negali būti išsaugotas</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation>Klaida</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>Kuriant paveikslėlius įvyko ši klaida:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>Laikino katalogo (%1) nepavyko sukurti</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>Mplayer&apos;io procesas nevyksta</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation>Rezoliucija: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation>Video formatas: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation>Kadrų per sekundę: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation>Kraštinių santykis: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>Failas %1 negali būti įkeltas</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation>Nėra failo vardo</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Mplayer&apos;io procesas nebuvo paleistas bandant gauti informaciją apie video</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation>Video dydis lygus 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>Failo %1 nėra</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation>Paveiksėliai</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation>Nėra informacijos</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation>Video kokybė: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation>Audio kokybė: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation>Audio dažnis: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation>Numatyta</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation>Video peržiūra</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation>&amp;Failas:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation>&amp;Stulpeliai:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation>&amp;Eilutės:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation>Kr&amp;aštinių santykis:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation>Praleisti &amp;sekundžių nuo padžios:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation>&amp;Maksimalus plotis:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>Peržiūra bus sukurta čia nurodytam filmui.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Paveikslėliai bus išrikiuoti lentelėje.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Nustatomas stulpelių skaičius lentelėje.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Nustatomas eilučių skaičius lentelėje.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Jei pažymėta, kiekvieno paveikslėlio apačioje bus rodomas kadro laikas.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Jei video kraštinių santykis yra neteisingas, čia galima nurodyti kitą.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Dažniausiai pirmi kadrai yra juodi, todėl tikslinga praleisti keletą sekunčių nuo filmo pradžios. Čia nurodoma kiek sekundžių bus praleista.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Čia nurodomas maksimalus sugeneruotos peržiūros plotis (pikseliais).</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Peržiūros sukūrimui reikalingi kadrai bus gauti iš filmo. Čia galima pasirinkti išgautų paveikslėlių formatą. PGN suteikia geresnę kokybę.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Pridė&amp;ti grojimo laiką į paveikslėlius</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation>&amp;Išgauti kadrus kaip</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Čia įveskite DVD įrenginį arba katalogo su DVD atvaizdu pavadinimą.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation>&amp;DVD įrenginys:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Įsiminti naudotą katalogą ir iš&amp;saugoti peržiūrą</translation>
    </message>
</context>
<context>
    <name>VideoSearch</name>
    <message>
        <location filename="../videosearch.cpp" line="158"/>
        <source>Context menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="322"/>
        <source>&lt;b&gt;Not enough free space to save video file&lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="323"/>
        <source>Increase free space and try again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="326"/>
        <source>Error downloading video clip from YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="391"/>
        <source>&amp;Play</source>
        <translation type="unfinished">&amp;Atkurti</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="392"/>
        <source>&amp;Add to play list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="393"/>
        <source>&amp;Open video in browser...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoSearchPanel</name>
    <message>
        <location filename="../videosearch.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="93"/>
        <source>Clear</source>
        <translation type="unfinished">Išvalyti</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="32"/>
        <source>Search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="100"/>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Garso lygis</translation>
    </message>
</context>
</TS>
