<?xml version="1.0" ?><!DOCTYPE TS><TS language="uk_UA" version="2.0">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="156"/>
        <source>The following people have contributed with translations:</source>
        <translation>Ці люди зробили свій внесок у переклади:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="162"/>
        <source>German</source>
        <translation>Німецька</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="163"/>
        <source>Slovak</source>
        <translation>Словацька</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="164"/>
        <source>Italian</source>
        <translation>Італійська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="167"/>
        <source>French</source>
        <translation>Французька</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="237"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 та %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="171"/>
        <source>Simplified-Chinese</source>
        <translation>Спрощена китайська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="172"/>
        <source>Russian</source>
        <translation>Російська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="234"/>
        <source>%1 and %2</source>
        <translation>%1 та %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="173"/>
        <source>Hungarian</source>
        <translation>Угорська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="83"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Версія %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation type="obsolete">(c) ROSA 2011-2012

ROSA Media Player is a free software.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Polish</source>
        <translation>Польська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>Japanese</source>
        <translation>Японська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="180"/>
        <source>Dutch</source>
        <translation>Голландська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Ukrainian</source>
        <translation>Українська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="187"/>
        <source>Portuguese - Brazil</source>
        <translation>Португальська (Бразилія)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Georgian</source>
        <translation>Грузинська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="189"/>
        <source>Czech</source>
        <translation>Чеська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Bulgarian</source>
        <translation>Болгарська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="193"/>
        <source>Turkish</source>
        <translation>Турецька</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="194"/>
        <source>Swedish</source>
        <translation>Шведська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="195"/>
        <source>Serbian</source>
        <translation>Сербська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Traditional Chinese</source>
        <translation>Традиційна китайська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="197"/>
        <source>Romanian</source>
        <translation>Румунська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="198"/>
        <source>Portuguese - Portugal</source>
        <translation>Португальська (Португалія)</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Greek</source>
        <translation>Грецька</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="202"/>
        <source>Finnish</source>
        <translation>Фінська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <location filename="../about.cpp" line="267"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="291"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="26"/>
        <source>About ROSA Media Player</source>
        <translation>Про ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../about.ui" line="75"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Droid Sans&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'MS Shell Dlg 2'; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Droid Sans&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Droid Sans'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:'Droid Sans'; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="203"/>
        <source>Korean</source>
        <translation>Корейська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Macedonian</source>
        <translation>Македонська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Basque</source>
        <translation>Баскійська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="80"/>
        <source>Using MPlayer %1</source>
        <translation>Використовується MPlayer %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="89"/>
        <source>(c) ROSA 2011-2013

ROSA Media Player is a free software.</source>
        <translation>(c) ROSA 2011-2012

ROSA Media Player є вільним програмним забезпеченням. {2011-2013
?}</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>terms of use</source>
        <translation>умови використання</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="112"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation>Ця програма є вільним програмним забезпеченням; ви можете розповсюджувати її і/або змінювати згідно з умовами використання &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; опублікованих &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; чи ліцензією версії 3, або (на ваш вибір) будь-якою наступною версією.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Catalan</source>
        <translation>Каталонська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Slovenian</source>
        <translation>Словенська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Arabic</source>
        <translation>Арабська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Kurdish</source>
        <translation>Курдська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Galician</source>
        <translation>Галісійська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="240"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 та %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="243"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 та %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="211"/>
        <source>Vietnamese</source>
        <translation>В&apos;єтнамська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="212"/>
        <source>Estonian</source>
        <translation>Естонська</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Lithuanian</source>
        <translation>Литовська</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Name</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Shortcut</source>
        <translation>Комбінація клавіш</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="169"/>
        <source>&amp;Save</source>
        <translation>&amp;Зберегти</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="172"/>
        <source>&amp;Load</source>
        <translation>За&amp;вантажити</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="420"/>
        <location filename="../actionseditor.cpp" line="479"/>
        <source>Key files</source>
        <translation>Файли клавіш</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="418"/>
        <source>Choose a filename</source>
        <translation>Виберіть назву файлу</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="432"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписати?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="433"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 вже існує.
Перезаписати?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="478"/>
        <source>Choose a file</source>
        <translation>Виберіть файл</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="447"/>
        <location filename="../actionseditor.cpp" line="487"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="448"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не може бути збережений</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="488"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Файл не може бути завантажений</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="176"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Змінити комбінацію клавіш...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>Audio Equalizer</source>
        <translation>Аудіоеквалайзер</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>31.25 Hz</source>
        <translation>31.25 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>62.50 Hz</source>
        <translation>62.50 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>125.0 Hz</source>
        <translation>125.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>250.0 Hz</source>
        <translation>250.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>500.0 Hz</source>
        <translation>500.0 Гц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>1.000 kHz</source>
        <translation>1.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="87"/>
        <source>2.000 kHz</source>
        <translation>2.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>4.000 kHz</source>
        <translation>4.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>8.000 kHz</source>
        <translation>8.000 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>16.00 kHz</source>
        <translation>16.00 кГц</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="92"/>
        <source>&amp;Apply</source>
        <translation>&amp;Застосувати</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="93"/>
        <source>&amp;Reset</source>
        <translation>Традиційна китайська</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрити</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Встановити типове значення</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Використовувати поточні значення як типові для нових відео.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Скинути все на нуль.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="120"/>
        <source>Information</source>
        <translation>Відомості</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="121"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Поточні значення збережені, щоб бути використаними як типові.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1596"/>
        <source>&amp;Open</source>
        <translation>&amp;Відкрити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1597"/>
        <source>&amp;Video</source>
        <translation>&amp;Зображення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Audio</source>
        <translation>Зв&amp;ук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1599"/>
        <source>&amp;Subtitles</source>
        <translation>Су&amp;бтитри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;Browse</source>
        <translation>Ог&amp;ляд</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1601"/>
        <source>Op&amp;tions</source>
        <translation>&amp;Налаштування</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1602"/>
        <source>&amp;Help</source>
        <translation>До&amp;відка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>&amp;File...</source>
        <translation>&amp;Файл...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1422"/>
        <source>D&amp;irectory...</source>
        <translation>&amp;Тека...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1423"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Перелік відтворення...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD з диску</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1427"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD з теки...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL-адреса...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1608"/>
        <source>&amp;Clear</source>
        <translation>&amp;Очистити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1605"/>
        <source>&amp;Recent files</source>
        <translation>Ос&amp;танні файли</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>P&amp;lay</source>
        <translation>Від&amp;творення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1450"/>
        <source>&amp;Pause</source>
        <translation>&amp;Призупинити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1451"/>
        <source>&amp;Stop</source>
        <translation>&amp;Зупинити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>&amp;Frame step</source>
        <translation>&amp;Крок кадра</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Звичайна швидкість</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Половина швидкості</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Подвійна швидкість</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed &amp;-10%</source>
        <translation>Швидкість &amp;-10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>Speed &amp;+10%</source>
        <translation>Швидкість &amp;+10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1541"/>
        <source>About &amp;ROSA Media Player</source>
        <translation>Про &amp;ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1619"/>
        <source>Sp&amp;eed</source>
        <translation>Шв&amp;идкість</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Fullscreen</source>
        <translation>Н&amp;а весь екран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1628"/>
        <source>Si&amp;ze</source>
        <translation>Ро&amp;змір</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1672"/>
        <location filename="../basegui.cpp" line="2754"/>
        <source>&amp;None</source>
        <translation>&amp;Немає</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Linear &amp;Blend</source>
        <translation>Лінійне &amp;змішування</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1637"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Деінтерлейсинг</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Постобробка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Автовизначення фази</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Гаусове розмиття (Deblock)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>De&amp;ring</source>
        <translation>Видалення к&amp;раєвих спотворень (Dering)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Add n&amp;oise</source>
        <translation>Додати ш&amp;ум</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1641"/>
        <source>F&amp;ilters</source>
        <translation>Ф&amp;ільтри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Еквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>&amp;Screenshot</source>
        <translation>Знімок &amp;екрану</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Розширене стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1512"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Караоке</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;Filters</source>
        <translation>&amp;Фільтри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Стерео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1708"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 оточення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1709"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 оточення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Channels</source>
        <translation>&amp;Канали</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>&amp;Mute</source>
        <translation>&amp;Вимкнути звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>Volume &amp;-</source>
        <translation>Гучність &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <source>Volume &amp;+</source>
        <translation>Гучність &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1504"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Затримка -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1505"/>
        <source>D&amp;elay +</source>
        <translation>З&amp;атримка +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1712"/>
        <source>&amp;Select</source>
        <translation>&amp;Вибрати</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>&amp;Load...</source>
        <translation>&amp;Завантажити...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>&amp;Title</source>
        <translation>&amp;Заголовок</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1724"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Розділ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>&amp;Angle</source>
        <translation>&amp;Ракурс</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Список відтворення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Вимкнено</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2770"/>
        <location filename="../basegui.cpp" line="2790"/>
        <location filename="../basegui.cpp" line="2810"/>
        <location filename="../basegui.cpp" line="2829"/>
        <location filename="../basegui.cpp" line="2858"/>
        <location filename="../basegui.cpp" line="2890"/>
        <location filename="../basegui.cpp" line="2917"/>
        <location filename="../basegui.cpp" line="2960"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;немає&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3280"/>
        <source>Video</source>
        <translation>Відео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3281"/>
        <location filename="../basegui.cpp" line="3519"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3282"/>
        <source>Playlists</source>
        <translation>Списки відтворення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3283"/>
        <location filename="../basegui.cpp" line="3497"/>
        <location filename="../basegui.cpp" line="3520"/>
        <source>All files</source>
        <translation>Всі файли</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3278"/>
        <location filename="../basegui.cpp" line="3494"/>
        <location filename="../basegui.cpp" line="3517"/>
        <source>Choose a file</source>
        <translation>Вибрати файл</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1756"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation>ROSA Media Player - Журнал mplayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3342"/>
        <source>ROSA Media Player - Information</source>
        <translation>ROSA Media Player - Інформація</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3343"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>Приводи CD/DVD ще не налаштовані.
Ви зможете зробити це у діалозі налаштувань цих пристроїв.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3452"/>
        <source>Choose a directory</source>
        <translation>Вибрати теку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3496"/>
        <source>Subtitles</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3578"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation>ROSA Media Player - Затримка аудіо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3882"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>Версія MPlayer (%1) встановлена у вашій системі, є застарілою. ROSA Media Player не може нормально працювати з нею: деякі параметри не будуть працювати, вибір субтитрів буде недоступний...</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="obsolete">Playing %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pause</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1454"/>
        <source>Play / Pause</source>
        <translation>Відтворити / Призупинити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1460"/>
        <source>Pause / Frame step</source>
        <translation>Призупинка / Крок кадра</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <location filename="../basegui.cpp" line="1517"/>
        <source>U&amp;nload</source>
        <translation>В&amp;ивантажити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="256"/>
        <source>Play list</source>
        <translation>Список відтворення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Trim video</source>
        <translation>Обрізати відео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="258"/>
        <source>Extract audio track</source>
        <translation>Витягти аудіо доріжку</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>C&amp;lose</source>
        <translation>З&amp;акрити</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1457"/>
        <source>Show / Hide right panel</source>
        <translation>Показати/Приховати праву панель</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1528"/>
        <source>&amp;Off</source>
        <comment>closed captions menu</comment>
        <translation>&amp;Вимкнути</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1536"/>
        <source>View &amp;info and properties...</source>
        <translation>Переглянути &amp;відомості та властивості...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1537"/>
        <source>P&amp;references...</source>
        <translation>Параметри...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1540"/>
        <source>Help &amp;Contents</source>
        <translation>Зміст &amp;довідки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Dec volume (2)</source>
        <translation>Зменшення гучності (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Inc volume (2)</source>
        <translation>Збільшення гучності (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Exit fullscreen</source>
        <translation>Вийти з повноекранного режиму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>OSD - Next level</source>
        <translation>Екранна індикація - Наступний рівень</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Dec contrast</source>
        <translation>Зменшення контрасту</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Inc contrast</source>
        <translation>Збільшення контрасту</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Dec brightness</source>
        <translation>Зменшення яскравості</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Inc brightness</source>
        <translation>Збільшення яскравості</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Dec hue</source>
        <translation>Зменшення кольору</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>Inc hue</source>
        <translation>Збільшення кольору</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Dec saturation</source>
        <translation>Зменшення насиченості</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Dec gamma</source>
        <translation>Зменшення гами</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1580"/>
        <source>Next audio</source>
        <translation>Наступна звукова доріжка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Next subtitle</source>
        <translation>Наступні субтитри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Next chapter</source>
        <translation>Наступний розділ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1583"/>
        <source>Previous chapter</source>
        <translation>Попередній розділ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1716"/>
        <source>&amp;Closed captions</source>
        <translation>&amp;Закриті субтитри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2121"/>
        <source>Capture desktop...</source>
        <translation>Захопити робочий стіл...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3355"/>
        <source>YouTube</source>
        <translation>YouTube</translation>
    </message>
    <message>
        <source>Video capture</source>
        <translation type="obsolete">Video capture</translation>
    </message>
    <message>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="obsolete">Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</translation>
    </message>
    <message>
        <source>Start capture</source>
        <translation type="obsolete">Start capture</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Cancel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Inc saturation</source>
        <translation>Збільшення насиченості</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Inc gamma</source>
        <translation>Збільшення гами</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Load external file...</source>
        <translation>&amp;Завантажити зовнішній файл...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Ядерний деінтерлейсер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (простий)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (подвійна частота кадрів)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1544"/>
        <source>&amp;Next</source>
        <translation>&amp;Наступний</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1545"/>
        <source>Pre&amp;vious</source>
        <translation>Поп&amp;ередній</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>Volume &amp;normalization</source>
        <translation>Нормалізація &amp;гучності</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Звуковий CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Усунення шуму (зви&amp;чайний)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1681"/>
        <source>Denoise &amp;soft</source>
        <translation>Усунення шуму (&amp;програмний)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1679"/>
        <source>Denoise o&amp;ff</source>
        <translation>Б&amp;ез усунення шуму</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1520"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>Використовувати бібліотеку SSA/&amp;ASS</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1584"/>
        <source>&amp;Toggle double size</source>
        <translation>Перемкнути по&amp;двійний розмір</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1518"/>
        <source>S&amp;ize -</source>
        <translation>Р&amp;озмір -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Si&amp;ze +</source>
        <translation>Ро&amp;змір +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1491"/>
        <source>Add &amp;black borders</source>
        <translation>Додати &amp;чорні межі</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1492"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Про&amp;грамне масштабування</translation>
    </message>
    <message>
        <source>Enable &amp;closed caption</source>
        <translation type="obsolete">Enable &amp;closed caption</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>&amp;Forced subtitles only</source>
        <translation>Лише &amp;примусові субтитри</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1585"/>
        <source>Reset video equalizer</source>
        <translation>Скинути еквалайзер відео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1757"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation>ROSA Media Player - Журнал rosa-media-player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4479"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>Несподіване завершення MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4480"/>
        <source>Exit code: %1</source>
        <translation>Код виходу: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4501"/>
        <source>MPlayer failed to start.</source>
        <translation>Помилка старту MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4502"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Перевірте шлях до MPlayer у налаштуваннях.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4506"/>
        <source>MPlayer has crashed.</source>
        <translation>MPlayer зламався.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4507"/>
        <source>See the log for more info.</source>
        <translation>Дивіться журнал для детальніших відомостей.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1645"/>
        <source>&amp;Rotate</source>
        <translation>По&amp;вернути</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1683"/>
        <source>&amp;Off</source>
        <translation>&amp;Вимкнути</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>&amp;90 градусів за годинниковою стрілкою та переворот</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1685"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>90 градусів за &amp;годинниковою стрілкою</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1686"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>90 градусів &amp;проти годинникової стрілки</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1687"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>90 градусів проти &amp;годинникової стрілки та переворот</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>Show context menu</source>
        <translation>Показати контекстне меню</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3279"/>
        <source>Multimedia</source>
        <translation>Мультимедіа</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1495"/>
        <source>E&amp;qualizer</source>
        <translation>&amp;Еквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>Reset audio equalizer</source>
        <translation>Скинути аудіоеквалайзер</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>Шукати субтитри на &amp;OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>&amp;Завантажити субтитри на OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Auto</source>
        <translation>&amp;Автоматично</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;4%</source>
        <translation>Швидкість -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>&amp;Speed +4%</source>
        <translation>Швидкість +&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1470"/>
        <source>Speed -&amp;1%</source>
        <translation>Швидкість -&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1471"/>
        <source>S&amp;peed +1%</source>
        <translation>Швидкість +&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>Scree&amp;n</source>
        <translation>&amp;Екран</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1690"/>
        <source>&amp;Default</source>
        <translation>&amp;Типові</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next video</source>
        <translation>Наступне відео</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1624"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Доріжка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1694"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Доріжка</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3881"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Застереження: Використовується старий MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3887"/>
        <source>Please, update your MPlayer.</source>
        <translation>Будь ласка, оновіть ваш MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3889"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Це застереження не буде більше показуватись)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>Next aspect ratio</source>
        <translation>Наступне співвідношення сторін</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1477"/>
        <source>Pre&amp;view...</source>
        <translation>&amp;Попередній перегляд...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>DVD &amp;menu</source>
        <translation>&amp;Меню DVD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1746"/>
        <source>DVD &amp;previous menu</source>
        <translation>&amp;Попереднє меню DVD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1740"/>
        <source>DVD menu, move up</source>
        <translation>Меню DVD, вгору</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1741"/>
        <source>DVD menu, move down</source>
        <translation>Меню DVD, вниз</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1742"/>
        <source>DVD menu, move left</source>
        <translation>Меню DVD, вліво</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>DVD menu, move right</source>
        <translation>Меню DVD, вправо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1745"/>
        <source>DVD menu, select option</source>
        <translation>Меню DVD, вибрати опцію</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1747"/>
        <source>DVD menu, mouse click</source>
        <translation>Меню DVD, клік мишкою</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>Set dela&amp;y...</source>
        <translation>Встановити &amp;затримку...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3579"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Затримка звуку (в мілісекундах):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4072"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4214"/>
        <source>Jump to %1</source>
        <translation>Перейти до %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1523"/>
        <source>Subtitle &amp;visibility</source>
        <translation>&amp;Видимість субтитрів</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>Next wheel function</source>
        <translation>Наступна функція колеса</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>П&amp;рограма</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1432"/>
        <location filename="../basegui.cpp" line="1433"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Редагувати...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1436"/>
        <source>Next TV channel</source>
        <translation>ROSA Media Player - Журнал rosa-media-player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1437"/>
        <source>Previous TV channel</source>
        <translation>Попередній канал ТБ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1438"/>
        <source>Next radio channel</source>
        <translation>Наступний канал радіо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1439"/>
        <source>Previous radio channel</source>
        <translation>Попередній канал радіо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1610"/>
        <source>&amp;TV</source>
        <translation>&amp;ТБ</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>Radi&amp;o</source>
        <translation>&amp;Радіо</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1434"/>
        <location filename="../basegui.cpp" line="1435"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Перейти...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1374"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Фільтри відео вимкнені, коли використовується vdpau</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1478"/>
        <source>Fli&amp;p image</source>
        <translation>Повернути з&amp;ображення</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Show filename on OSD</source>
        <translation>Показувати назву файла у екранній індикації</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>Toggle deinterlacing</source>
        <translation>Перемикач деінтерлейсингу</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation>ROSA Media Player досі запущений</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Сховати</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Відновити</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>&amp;Вихід</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Список відтворення</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation>00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="83"/>
        <source>Volume</source>
        <translation>Гучність</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3145"/>
        <source>Brightness: %1</source>
        <translation>Яскравість: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3162"/>
        <source>Contrast: %1</source>
        <translation>Контрасність: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3178"/>
        <source>Gamma: %1</source>
        <translation>Гама: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3194"/>
        <source>Hue: %1</source>
        <translation>Колір: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3210"/>
        <source>Saturation: %1</source>
        <translation>Насиченість: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3362"/>
        <source>Volume: %1</source>
        <translation>Гучність: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4328"/>
        <source>Zoom: %1</source>
        <translation>Масштаб: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3500"/>
        <location filename="../core.cpp" line="3518"/>
        <source>Font scale: %1</source>
        <translation>Масштаб шрифта: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4182"/>
        <source>Aspect ratio: %1</source>
        <translation>Співвідношення сторін: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4595"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Оновити кеш шрифтів. Це може тривати кілька секунд...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3411"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Затримка субтитрів: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3431"/>
        <source>Audio delay: %1 ms</source>
        <translation>Затримка аудіо: %1 мс</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3275"/>
        <source>Speed: %1</source>
        <translation>Швидкість: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="199"/>
        <source>Connecting to %1</source>
        <translation>Приєднуюся до %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="203"/>
        <source>Unable to retrieve youtube page</source>
        <translation>Не вдається отримати сторінку youtube</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="207"/>
        <source>Unable to locate the url of the video</source>
        <translation>Не вдалося знайти url відео</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3572"/>
        <source>Subtitles on</source>
        <translation>Субтитри увімкнені</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3574"/>
        <source>Subtitles off</source>
        <translation>Субтитри вимкнені</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4233"/>
        <source>Mouse wheel seeks now</source>
        <translation>Тепер колесо миші здійснює переміщення</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4236"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Тепер колесо миші змінює гучність</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4239"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Тепер колесо миші змінює масштаб</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4242"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Тепер колесо миші змінює швидкість</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1205"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Знімок екрану НЕ був зроблений, оскільки тека не налаштована</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1221"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Знімки екрану НЕ були зроблені, оскільки тека не налаштована</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2865"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>Мітка &quot;А&quot; встановлена на %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2884"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>Мітка &quot;Б&quot; встановлена на %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2902"/>
        <source>A-B markers cleared</source>
        <translation>Мітки А-Б вилучені</translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation>Формат вихідного файлу:</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation>Версія ffmpeg встановлена на вашому комп&apos;ютері не підтримує необхідний кодек libmp3lame. Для того щоб мати можливість витягувати звукові доріжки, будь ласка, встановіть ffmpeg з підтримкою libmp3lame.</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation>Не вдається витягти звукову доріжку (можливо, у вас немає достатньо місця на диску?)</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation>Не вдається витягти звукову доріжку (код: %1)</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>Новий файл &quot;%1&quot; збережено в теку %2</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation>Форма</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation>Формат вихідного файлу:</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation>mp3</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation>ogg</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation>Відміна</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation>Витягти</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to ROSA Media Player</source>
        <translation type="obsolete">Welcome to ROSA Media Player</translation>
    </message>
    <message>
        <source>A:%1</source>
        <translation type="obsolete">A:%1</translation>
    </message>
    <message>
        <source>B:%1</source>
        <translation type="obsolete">B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="320"/>
        <source>&amp;Video info</source>
        <translation>Інформація про &amp;відео</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="321"/>
        <source>&amp;Frame counter</source>
        <translation>Лічильник &amp;кадрів</translation>
    </message>
    <message>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation type="obsolete">%1x%2 %3 fps</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>піктограма</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Сховати журнал</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Показати журнал</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>Помилка MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>піктограма</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation>Піктограма</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Медіа</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation>Редактор улюблених</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation>Список улюблених</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>Ви можете редагувати, видаляти або додавати нові елементи. Подвійний клік по комірці для редагування її вмісту.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation>Виберіть файл з піктограмою</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation>Зображення</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>піктограма</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation>&amp;Новий</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>&amp;Видалити</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation>Видалити в&amp;сі</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation>В&amp;гору</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation>В&amp;низ</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation>Перейти до елементу</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Введіть номер елементу у цьому переліку до якого необхідно перейти:</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Звантажується...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Звантажується %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation>ROSA Media Player - Властивості файлу</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Відомості</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Демультиплексор</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Виберіть демультиплексор для цього файлу:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>Ск&amp;инути</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Відео кодек</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Виберіть відео кодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>З&amp;вуковий кодек</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Виберіть звуковий кодек:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>Опції &amp;MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Додаткові опції для MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Версія ffmpeg встановлена на вашому комп&apos;ютері не підтримує необхідний кодек libmp3lame. Для того щоб мати можливість витягувати звукові доріжки, будь ласка, встановіть ffmpeg з підтримкою libmp3lame.</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Опції:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Ви можете також передати додаткові фильтри відео.
Разділяйте їх комою. Не використовуйте пробіли!
Приклад: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>Фільтри в&amp;ідео:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Фільтри звука. Використовуються так само як фільтри відео.
Приклад: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Фильтри &amp;звуку:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>OK</source>
        <translation>Гаразд</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Cancel</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="140"/>
        <source>Apply</source>
        <translation>Застосувати</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation>додати шум</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation>гаусове розмиття (Deblock)</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation>звичайне усунення шуму</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation>легке усунення шуму</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation>нормалізація гучності</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation>Http</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Увімкнути/вимкнути використання проксі.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation>Назва серверу проксі.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation>Порт проксі.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>Якщо проксі портебує автентифікації, це встановлює ім&apos;я користувача.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>Пароль для проксі. &lt;b&gt;Застереження:&lt;/b&gt; пароль буде збережений як звичайний текст у файлі налаштувань.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation>Виберіть, який тип проксі використовувати.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation>Додаткові опції</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation>Проксі</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Увімкнути проксі</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation>Ви можете редагувати, видаляти або додавати нові елементи. Подвійний клік по комірці для редагування її вмісту.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation>П&amp;орт:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation>&amp;Ім&apos;я користувача:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation>П&amp;ароль:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation>&amp;Тип:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Файли</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Вивантажено</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Всі</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Звантажити</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Скопіювати посилання до буферу обміну</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>Звантаження невдале: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>З&apos;єднуюсь з %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>Завантажується...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Виконано.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 файлів доступні</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Неможливо опрацювати отримані дані.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Пошук субтитрів</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Субтитри для</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Мова:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Оновити</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Субтитри збережені як %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation><numerusform>%1 субтитр витягнуто</numerusform><numerusform>%1 субтитра витягнуто</numerusform><numerusform>%1 субтитрів витягнуто</numerusform></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Перезаписати?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>Файл %1 вже існує, перезаписати?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Помилка збереження файлу</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn't possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Неможливо зберегти звантажений
файл в теці %1
Будь ласка, перевірте права доступу до цієї теки.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation>Звантаження невдале</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation>Тимчасовий файл %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Опції</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Загальна</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 кбайт (%2 Мбайт)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>URL-адреса</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Тривалість</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Демультиплексор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Виконавець</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Автор</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Альбом</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Жанр</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Дата</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Доріжка</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Авторське право</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Примітка</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Програмне забезпечення</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Відомості про кліп</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Зображення</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Роздільна здатність</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Співвідношення сторін</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Швидкість потоку</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 кбіт/с</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Кадрів за секунду</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Вибраний кодек</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Початковий звуковий потік</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Частота</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Канали</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Звукові доріжки</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>нічого</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Тип</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>№</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Заголовок доріжки</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>URL-адреса потоку</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>Файл</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Вибрати теку</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation>ROSA Media Player - Грати DVD з теки</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Ви можете відкрити DVD з жорсткого диску. Виберіть теку, яка містить VIDEO_TS та AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Виберіть теку...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation>ROSA Media Player - Введіть версію MPlayer</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation>ROSA Media Player не може визначити версію MPlayer, яку ви використовуєте.</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>Вказана версія MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Будь ласка, &amp;виберіть правильну версію:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 чи старіша</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 чи новіша</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation>ROSA Media Player - Введіть URL</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;URL-адреса:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>Це &amp;список відтворення</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="34"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Якщо ця опція увімкнена, URL-адреса сприймається як список відтворення: буде відкрита як текст та відтворена.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Афарська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Абхазька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Африкаанс</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Амхарська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Арабська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Ассамська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Аймара</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Азербайджанська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Башкирська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Болгарська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Біхарі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Біслама</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Бенгальська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Тібетська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Бретонська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Каталонська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Корсіканська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Чеська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Валійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Данська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>Німецька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Грецька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>Англійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Есперанто</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Іспанська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Естонська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Баскська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Перська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Фінська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Фарерська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>Французька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Фризька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Ірландська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Галисійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Гуарані</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Гуджараті</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Хауса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Іврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Хінді</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Хорватська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Угорська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Вірменська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Інтерлінгва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Індонезійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Окциденталь</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Ісландська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Італійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Інуктитут</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Японська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Якщо ця опція увімкнена, URL-адреса сприймається як список відтворення: буде відкрита як текст та відтворена.</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Грузинська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Казахська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Ґренландська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Канадська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Корейська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Кашмірі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Курдська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Киргизька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Латинська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Лінгала</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Литовська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Латвійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Малагаська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Маорі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Македонська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Малаялам</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Монгольська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Молдавська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Маратхі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Малайска</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Мальтійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Бірманська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Науру</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Непальська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Голландська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Норвезька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Окситанська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Орія</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Польська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Португальська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Кечуа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Румунська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Російська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Киньяруанда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Санскріт</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Сіндхи</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Словацька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Словенська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Шона</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Сомалійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Албанська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Сербська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Суданська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Шведська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Суахілі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Таміл</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Телугу</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Таджикська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Тайська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Тигринья</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Туркменська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Тагальська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Тонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Турецька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Тсонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Татарська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Тві</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Уйгурська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Українська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Урду</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Узбецька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>В&apos;єтнамська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Волоф</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Ісікоса</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Їдиш</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Йоруба</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Чжуанська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Китайська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Зулу</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Португальська (Бразилія)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Португальська (Португалія)</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Спрощена китайська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Традиційна китайська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Юнікод</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Східна Європа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Східна Європа з Євро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Кирилиця/Центральна Європа</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Есперанто, Галісійська, Мальтійська, Турецька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Балтійська стара</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Кирилиця</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Сучасна грецька</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Балтійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Кельтська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Іврит</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Українська, Білоруська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Китайська спрощена</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Китайська традиційна</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Японська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Корейська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Тайська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Кирилиця Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Кирилиця/Центральна Європа Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Арабська Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation>Авестійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation>Аканська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation>Арагонська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation>Аваріська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation>Білоруська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation>Бамбара</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation>Боснійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation>Чеченська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation>Крі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation>Церковна</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation>Чуваська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation>Мальдівійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation>Дзонг-ке</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation>Еве</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation>Фула</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation>Фіджійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation>Гельська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation>Менська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation>Хірі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation>Гаітійська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation>Гереро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation>Чаморро</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation>Ігбо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation>Сичуанська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation>Інупіак</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation>Ідо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation>Конго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation>Кікуйю</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation>Традиційна китайська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation>Кхмерська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation>Канурі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation>Комі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation>Корнська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation>Люксембургська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation>Луганда</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation>Лімбурган</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation>Лаоська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation>Луба-Катанга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation>Маршульська</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Букмол</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation>Ндебеле</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation>Ндонга</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation>Навахо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation>Чічева</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation>Оджибва</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation>Оромо</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation>Осетинська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation>Панджабська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation>Палі</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation>Пушто</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation>Романшська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation>Рунді</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation>Сардінська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation>Саамська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation>Санго</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation>Сінгальська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation>Сваті</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation>Сото</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation>Тсвана</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation>Таїтіянська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation>Венда</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation>Волапюк</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation>Валонська</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation>Сучасна грецька Windows</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Виберіть назву файлу, з якою необхідно зберегти</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписати?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Файл вже існує.
Перезаписати?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Помилка збереження файлу</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Неможливо зберегти журнал</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Журнали</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Вікно журналу</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Зберегти</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Копіювати до буферу обміну</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Закрити</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Name</source>
        <translation>Назва</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Length</source>
        <translation>Тривалість</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Play</source>
        <translation>Від&amp;творити</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="386"/>
        <source>&amp;Edit</source>
        <translation>&amp;Редагувати</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="829"/>
        <location filename="../playlist.cpp" line="849"/>
        <source>Playlists</source>
        <translation>Список відтворення</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="827"/>
        <source>Choose a file</source>
        <translation>Вибрати файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="847"/>
        <source>Choose a filename</source>
        <translation>Виберіть назву файлу</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="861"/>
        <source>Confirm overwrite?</source>
        <translation>Перезаписати?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="862"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Файл %1 вже існує.
Перезаписати?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1080"/>
        <source>Multimedia</source>
        <translation>Мультимедія</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1081"/>
        <source>All files</source>
        <translation>Всі файли</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>Select one or more files to open</source>
        <translation>Виберіть один чи більше файлів</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1142"/>
        <source>Choose a directory</source>
        <translation>Вибрати теку</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1367"/>
        <source>Edit name</source>
        <translation>Змінити назву</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1368"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Введіть назву, яка буде відображатись у списку для цього файлу:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="346"/>
        <source>&amp;Load</source>
        <translation>&amp;Завантажити</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Save</source>
        <translation>&amp;Зберегти</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="351"/>
        <source>&amp;Next</source>
        <translation>&amp;Наступний</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="352"/>
        <source>Pre&amp;vious</source>
        <translation>По&amp;передній</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>Move &amp;up</source>
        <translation>Змістити &amp;вгору</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>Move &amp;down</source>
        <translation>Змістити &amp;вниз</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Повторювати</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="372"/>
        <source>S&amp;huffle</source>
        <translation>П&amp;еремішати</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="377"/>
        <source>Add &amp;current file</source>
        <translation>Додати &amp;поточний файл</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="378"/>
        <source>Add &amp;file(s)</source>
        <translation>Додати &amp;файл(и)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Add &amp;directory</source>
        <translation>Додати &amp;теку</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="382"/>
        <source>Remove &amp;selected</source>
        <translation>Видалити &amp;вибране</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>Remove &amp;all</source>
        <translation>Видалити &amp;все</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="390"/>
        <source>Add...</source>
        <translation>Додати...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="392"/>
        <source>Remove...</source>
        <translation>Видалити...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="396"/>
        <source>ROSA Media Player - Playlist</source>
        <translation>ROSA Media Player - Список відтворення</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="891"/>
        <source>Playlist modified</source>
        <translation>Список відтворення змінено</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="892"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Зміни в списку відтворення не збережені! Ви бажаєте зберегти?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Preferences</source>
        <translation>Налаштування</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Список відтворення - Налаштування</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Виберіть цю опцію, якщо хочете, щоб додавання теки також додавало підтеки рекурсивно. Інакше будуть додані лише файли у вибраній теці.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>&amp;Додати файли в теках рекурсивно</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Виберіть цю опцію, щоб витягти з файлів, які будуть додані до списку відтворення, деякі подробиці. Це дозволить показувати назву (якщо наявна) та довжину файлів. Інакше ці подробиці не будуть доступні доки файл не буде дійсно програватися. Пам&apos;ятайте: ця опція може бути повільною, особливо, якщо ви додаєте багато файлів.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Автоматично отримувати &amp;відомості про додані файли</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>&amp;Зберегти копію списку відтворення під час виходу</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>Грати файли з &amp;початку</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Попередження</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Не всі файли можуть бути асоційовані. Перевірте Ваші права доступу та спробуйте знову.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Типи файлів</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Вибрати всі</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Відмітити всі типи файлів в списку</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Зняти відмітки з усіх типів файлів у списку</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Перелік всіх типів файлів</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation>Оберіть типи медіа-файлів які б ви хотіли опрацьовувати ROSA Media Player. Коли ви натиснете Застосувати, відмічені файли будуть асоційовані з ROSA Media Player. Якщо ви знімете виділення з типів, файлові асоціації будуть відновлені.</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Типи файлів</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation>Медіа файли, які опрацьовуються ROSA Media Player:</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Вибрати все</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Нічого не обирати</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Нічого не обирати</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation> &lt;b&gt;Примітка:&lt;/b&gt; (Відновлення не діє у Windows Vista).</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="82"/>
        <source>General</source>
        <translation>Загальні</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="338"/>
        <source>Media settings</source>
        <translation>Налаштування медіа</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="112"/>
        <source>&amp;Disable screensaver</source>
        <translation>&amp;Відмінити зберігач екрану</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="246"/>
        <source>Cha&amp;nnels by default:</source>
        <translation>Типові ка&amp;нали</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="119"/>
        <source>YouTube support (experimental)</source>
        <translation>Підтримка YouTube (експериментальна)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="49"/>
        <source>Preferred video &amp;quality:</source>
        <translation>Бажана &amp;якість відео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="129"/>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>Main window</source>
        <translation>Головне вікно</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="137"/>
        <source>A&amp;utoresize:</source>
        <translation>А&amp;втоматична зміна розміру:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="154"/>
        <source>Never</source>
        <translation>Ніколи</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="159"/>
        <source>Whenever it&apos;s needed</source>
        <translation>Коли це потрібно</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="164"/>
        <source>Only after loading a new video</source>
        <translation>Лише після завантаження нового відео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="187"/>
        <source>R&amp;emember position and size</source>
        <translation>З&amp;апам&apos;ятовувати положення та розмір</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="197"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Instances</source>
        <translation>Екземпляри</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="206"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation>&amp;Використовувати лише один запущений екземпляр ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="216"/>
        <location filename="../prefgeneral.cpp" line="399"/>
        <source>Audio</source>
        <translation>Звук</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="225"/>
        <source>&amp;Volume normalization by default</source>
        <translation>Типова нормалізація &amp;гучності</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Disable screensaver</source>
        <translation>Відмінити зберігач екрану</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation>Зазвичай ROSA Media Player буде запам&apos;ятовувати налаштування для кожного файлу, який ви відтворювали (обрана аудіо-доріжка, рівень гучності, фільтри...). Зніміть цю позначку, якщо вам не подобається ця функція.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="103"/>
        <source>1080p</source>
        <translation>1080p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="104"/>
        <source>720p</source>
        <translation>720p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="105"/>
        <source>480p</source>
        <translation>480p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="106"/>
        <source>360p</source>
        <translation>360p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="107"/>
        <source>240p</source>
        <translation>240p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Automatically add files to playlist</source>
        <translation>Автоматично додавати файли до списку відтворення</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation>Якщо ця опція увімкнена, щоразу, як тільки файл буде відкритим, ROSA Media Player очистить список відтворення і потім додасть файл до нього. У випадку з DVD, CD and VCD, усі заголовки на диску будуть додані до списку відтворення.</translation>
    </message>
    <message>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="obsolete">When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="340"/>
        <source>Remember settings</source>
        <translation>Запам&apos;ятати налаштування</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="77"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>Запам&apos;ятовувати налаштування для &amp;всіх файлів (звукові доріжки, субтитри...)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="105"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation>&amp;Автоматчно додавати файл до списку відтворення</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="345"/>
        <source>Close when finished</source>
        <translation>Вийти по закінченню</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="346"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Ця опція активує автоматичний вихід з програми по закінченню відтворення файлу/списку відтворення.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="98"/>
        <source>2 (Stereo)</source>
        <translation>2 (Стерео)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="99"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 оточення)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="100"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 оточення)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="91"/>
        <source>&amp;Pause when minimized</source>
        <translation>&amp;Призупинити при мінімізації</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="349"/>
        <source>Pause when minimized</source>
        <translation>Призупинити при мінімізації</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="371"/>
        <source>Channels by default</source>
        <translation>Типові канали</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="84"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Вийти по закінченню відтворення</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="350"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Якщо ця опція увімкнена, файл буде призупинений, коли головне вікно сховане. Коли вікно відновиться, відтворення буде відновлене.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="384"/>
        <source>Autoresize</source>
        <translation>Автоматичний розмір</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation>Головне вікно може змінювати розмір автоматично. Виберіть бажаний варіант.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Remember position and size</source>
        <translation>Запам&apos;ятовувати положення і розмір</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation>Якщо ви відмітите цю опцію, положення і розмір головного вікна будуть зберігатися і відновлюватися коли ви запускаєте ROSA Media Player знову.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation>Використовувати лише один запущений екземпляр ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="396"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation>Відмітьте цю властивість, якщо ви хочете використовувати запущений екземпляр ROSA Media Player коли відкриваєте інші файли.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="401"/>
        <source>Volume normalization by default</source>
        <translation>Типова нормалізація гучності</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="402"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation>Максимізація гучності без спотворення звуку.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="362"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Встановіть цю опцію, щоб вимкнути зберігач екрану під час відтворення.&lt;br&gt;Зберігач екрану увімкнеться знову, коли відтворення завершиться.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="372"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Вказує кількість каналів для відтворення. MPlayer вказує декодеру декодувати звук на вказану кількість каналів. Це виконує сам декодер. Це, як правило, актуально лише для відтворення відео із звуком AC3 (як DVD). В цьому випадку liba52 декодує типово та правильно змішує звук в необхідну кількість каналів. &lt;b&gt;Примітка:&lt;/b&gt; Ця опція лише для кодеку (тільки AC3), фільтрів (розширення оточення) та драйверів виведення звуку (принаймні OSS).</translation>
    </message>
    <message>
        <source>Switch screensaver off</source>
        <translation type="obsolete">Switch screensaver off</translation>
    </message>
    <message>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="obsolete">This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</translation>
    </message>
    <message>
        <source>Avoid screensaver</source>
        <translation type="obsolete">Avoid screensaver</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="367"/>
        <source>Audio/video auto synchronization</source>
        <translation>Автосинхронізація звука/відео</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="368"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Поступове регулювання синхронізації аудіо-відео, основане на розмірах звукових затримок.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="98"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Автосинхронізація аудіо-&amp;відео</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation>&amp;Субтитри</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation>Бажана мова</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation>&amp;Звук</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation>&amp;Субтитри</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation>Або оберіть номер треку:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation>Автоматичне завантаження</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation>Така ж назва як і у кліпа</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation>Підключати субтитри, які містять назву кліпу</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation>Всі субтитри теки</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation>Ав&amp;amp;тозавантаження субтитрів (*.srt, *.sub...):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation>Кодування</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation>Типове &amp;amp;кодування субтитрів:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation>Субтитри</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation>Бажані аудіо-доріжки та субтитри</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation>Бажана мова аудіо-доріжок</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation>Бажана мова субтитрів</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Тут ви можете ввести бажану мову для звукових доріжок. Як тільки трапиться медіа-файл з кількома звуковими доріжками, ROSA Media Player спробує використати бажану для вас мову.&lt;br&gt;Ця функція працюватиме лише якщо у медіа-файлі буде надано інформацію про мови звукових доріжок, як в DVD чи mkv файлах.&lt;br&gt;
Це поле приймає регулярні вирази. Приклад: &lt;b&gt;es|esp|spa&lt;/b&gt; обере звукову доріжку, якщо в назві зустрінеться &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; чи &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Тут ви можете ввести бажану мову для доріжки субтитрів. Як тільки трапиться медіа-файл з кількома субтитрами, ROSA Media Player спробує використати бажану для вас мову.&lt;br&gt;Ця функція працюватиме лише якщо у медіа-файлі буде надано інформацію про мови субтитрів, як в DVD чи mkv файлах.&lt;br&gt;
Це поле приймає регулярні вирази. Приклад: &lt;b&gt;es|esp|spa&lt;/b&gt; обере доріжку субтитрів, якщо в назві зустрінеться &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; чи &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation>Аудіо-доріжка</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Вказує типову звукову доріжку, яка буде використана при програванні нових файлів. Якщо такої звукової доріжки не існує, буде використано першу. &lt;br&gt;&lt;b&gt;Примітка:&lt;/b&gt; &lt;i&gt;&quot;бажана мова звукової доріжки&quot;&lt;/i&gt; має перевагу над цією властивістю.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation>Трек субтитрів</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Автоматично додавати файли до списку відтворення</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation>Вкажіть метод автозавантаження субтитрів.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation>Типове кодування субтитрів</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation>Виберіть кодування, яке буде використовуватись типово для файлів субтитрів.</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>ROSA Media Player - Help</source>
        <translation type="obsolete">ROSA Media Player - Help</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="161"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Apply</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Help</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation>ROSA Media Player - Налаштування</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>відобразити це повідомлення та вийти.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>головне вікно закриється, коли скінчиться відтворення файлу/списку відтворення.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>спробувати з&apos;єднатися з віддаленою програмою та передати їй вказану дію. Наприклад: -send-action pause. Решта опцій (якщо такі будуть) будуть знехтувані і програма закриється. Буде повернено 0 при вдалому виконанні чи -1 при помилці.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>action_list - перелік дій, розділених пробілами. Дії будуть виконані тільки після завантаження файлу (якщо такий буде) у порядку, вказаному Вами. Для перевірки дії Ви можете передати параметр true чи false. Наприклад: -actions &quot;fullscreen compact true&quot;. Лапки потрібні, якщо Ви передаєте більше ніж один параметр.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation>'медіа-файл' це файл будь-якого типу, який ROSA Media Player може відкрити. 
Це може бути локальний файл, DVD (напр. dvd://1), Інтернет-потік (напр. mms://....) чи локальний список відтворенні у форматі m3u чи pls. Якщо використано опцію -playlist, то це означатиме, що ROSA Media Player передасть опцію -playlist до MPlayer, таким чином,  MPlayer буде утримувати список відтворення, але не ROSA Media Player.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>якщо вже працює інший процес, медіа будуть додані до списку відтворення. Якщо не буде ніякого іншого процесу, ця опція нехтується та файли відкриються в новому екземплярі.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>не закривати головне вікно після закінчення відтворення файлу чи переліку.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>відтворювати відео на повний екран.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>відтворювати відео у віконному режимі.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Відновити старі асоціації та почистити реєстр.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Використання:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>тека</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>action_name</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>action_list</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>відкрити типовий інтерфейс.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>subtitle_file</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>визначає файл з субтитрами, що завантажується для першого відео.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation><numerusform>%1 секунда</numerusform><numerusform>%1 секунди</numerusform><numerusform>%1 секунд</numerusform></translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation><numerusform>%1 хвилина</numerusform><numerusform>%1 хвилини</numerusform><numerusform>%1 хвилин</numerusform></translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 та %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="189"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>вимкнено</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="219"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>автоматично</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="222"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>невідомо</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation>ширина</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation>висота</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation>вказує каталог, де rosa-media-player буде зберігати власні файли налаштувань (rosamp.ini, rosamp_files.ini...)</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>визначає координати, де буде відображене головне вікно.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation>визначає розміри головного вікна.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="467"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation>Це ROSA Media Player, завантажений на %1</translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation>Поставити у чергу до ROSA Media Player</translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>Помилка ZIP/UNZIP API: %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="155"/>
        <source>Source #</source>
        <translation>Джерело #</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="155"/>
        <source>Name: </source>
        <translation>Назва: </translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="192"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation>Не вдалося почати запис. Будь ласка, перевірте, чи ffmpeg встановлений. </translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="195"/>
        <source>Unknown error in recording occured</source>
        <translation>Виникла невідома помилка при записі</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="198"/>
        <source>Sorry, recording crashed</source>
        <translation>Вибачте, запис не вдався</translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="63"/>
        <source>/Screencast - </source>
        <translation>/Screencast - </translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="66"/>
        <source>\Screencast-</source>
        <translation>\Screencast-</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation>Відео захоплене з екрану було успішно збережене до %1</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="118"/>
        <source>Length: %1
Size: %2
</source>
        <translation>Довжина: %1
Розмір: %2
</translation>
    </message>
</context>
<context>
    <name>ScreencastDialog</name>
    <message>
        <location filename="../screencast.ui" line="20"/>
        <source>Video capture</source>
        <translation>Захоплення відео</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="34"/>
        <location filename="../screencast.cpp" line="99"/>
        <source>not recording</source>
        <translation>не записується</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="39"/>
        <source>microphone</source>
        <translation>мікрофон</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="44"/>
        <source>line-out</source>
        <translation>лінійний вихід</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="65"/>
        <source>Start capture</source>
        <translation>Почати захоплення</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="75"/>
        <source>Cancel</source>
        <translation>Відмінити</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="82"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Зараз почнеться захоплення екрану. Програвач буде мінімізовано до системного лотку на час запису відео. Для зупинки захоплення відео натисніть по червоній круглій піктограмі в системному лотку.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="98"/>
        <source>Record audio:</source>
        <translation>Записати звук:</translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Зараз почнеться захоплення екрану. Програвач буде мінімізовано до системного лотку на час запису відео. Для зупинки захоплення відео натисніть по червоній круглій піктограмі в системному лотку.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="43"/>
        <source>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;WARNING: The audio subsystem needs to be restarted before recording from the line-out. It may cause interruption of currently playing sound.&lt;/span&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;УВАГА: Звукова підсистема потребує перезавантаження перед записом з лінійного виходу. Це може спричинити переривання звуку що відтворюється.&lt;/span&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="48"/>
        <source>&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>піктограма</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>мітка</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Змінити комбінацію</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Очистити</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Натисніть комбінацію клавіш, яку Ви бажаєте задати</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Захопити</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Комбінація клавіш захоплення</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation>Час початку повинен передувати часу завершення</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation>/Movie_</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation>Не вдалося обрізати відео (можливо, недостатньо вільного місця на диску?)</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation>Не вдалося обрізати відео (код: %1)</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation>Інформація</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>Новий файл &quot;%1&quot; збережено до каталогу %2</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation>Розділити відео</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation>Вказати часовий інтервал:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation>Від:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation>HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation>Встановити поточний час відтворення</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation>До:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation>Відмінити</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation>Обрізати</translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Вибір субтитрів</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>Цей архів містить більш ніж один файл субтитрів. Будь ласка, виберіть один, який хочете витягти.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Вибрати всі</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Не вибирати жодного</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="100"/>
        <source>Channel editor</source>
        <translation>Редактор каналів</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="101"/>
        <source>TV/Radio list</source>
        <translation>Перелік ТБ/Радіо</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Перейти до:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Авто</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Так</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>Ні</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Contrast</source>
        <translation>Контрастність</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Brightness</source>
        <translation>Яскравість</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Hue</source>
        <translation>Колір</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Saturation</source>
        <translation>Насиченість</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>Gamma</source>
        <translation>Гама</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="98"/>
        <source>&amp;Close</source>
        <translation>Якщо співвідношення сторін відео не правильне, тут Ви можете визначити інше.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>&amp;Reset</source>
        <translation>Об&amp;нулити</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="100"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Встановити типове значення</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="104"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Використовувати поточні значення як типові для нових кліпів.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="106"/>
        <source>Set all controls to zero.</source>
        <translation>Скинути все на нуль.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Video Equalizer</source>
        <translation>Відеоеквалайзер</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="126"/>
        <source>Information</source>
        <translation>Відомості</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="127"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Поточні значення збережені, щоб використовуватись як типові.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation>Попередній перегляд відео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Скасувати</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation>Згенеровано ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation>Створення мініатюр...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation>Розмір: %1 Мб</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation>Довжина: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation>Зберегти файл</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation>Помилка збереження файлу</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Файл не може бути збережений</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation>Помилка</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>Сталася наступна помилка під час створення мініатюр:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>Тимчасова тека (%1) не може бути створена</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>Процес mplayer не запустився</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation>Роздільна здатність: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation>Формат відео: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation>Кадрів за секунду: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation>Співвідношення сторін: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>Файл %1 не може бути завантажений</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation>Немає назви файлу</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>Процес mplayer не запустився під час спроби отримання відомостей про відео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation>Довжина відео: 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>Файл %1 не існує</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation>Зображення</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation>Немає відомостей</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation>%1 кбіт/с</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation>%1 Гц</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation>Бітрейт відео: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation>Бітрейт аудіо: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation>Частота аудіо: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation>Типові</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation>Попередній перегляд відео</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation>&amp;Файл:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation>&amp;Стовпці:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation>&amp;Рядки:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation>&amp;Співвідношення сторін:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation>Пропустити &amp;секунд на початку:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation>Найбільша &amp;ширина:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>Попередній перегляд буде створено для відео, яке ви вкажете тут.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>Мініатюри будуть розташовані в таблиці.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>Ця опція визначає кількість стовпців таблиці.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>Ця опція визначає кількість рядків таблиці.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>Якщо ви виберете цю опцію, час програвання буде відображений знизу для кожної мініатюри.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>Якщо співвідношення сторін відео не правильне, тут Ви можете визначити інше.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Зазвичай перший кадр чорний, тому гарною думкою є пропустити декілька секунд на початку відео. Ця опція дозволяє визначити скільки секунд буде пропущено.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>Ця опція визначає найбільшу ширину в пікселях, що будуть мати створені мініатюри.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Деякі кадри будуть витягнені з відео в порядку створення попереднього перегляду. Тут ви можете обрати формат зображення для здобутих кадрів. PNG може дати кращу якість.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Додати &amp;час програвання до мініатюр</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation>Витягнути &amp;кадри як</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Введіть пристрій DVD або теку з образом DVD.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation>Пристрій &amp;DVD:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Запам&apos;ятати теку для &amp;збереження мініатюр</translation>
    </message>
</context>
<context>
    <name>VideoSearch</name>
    <message>
        <location filename="../videosearch.cpp" line="158"/>
        <source>Context menu</source>
        <translation>Контекстне меню</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="322"/>
        <source>&lt;b&gt;Not enough free space to save video file&lt;b&gt;</source>
        <translation>&lt;b&gt;Не достатньо вільного місця на диску для збереження відео файлу&lt;b&gt;</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="323"/>
        <source>Increase free space and try again</source>
        <translation> Звільніть місце на диску і спробуйте знову</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="326"/>
        <source>Error downloading video clip from YouTube</source>
        <translation>Помилка завантаження відео кліпу з YouTube</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="391"/>
        <source>&amp;Play</source>
        <translation>&amp;Грати</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="392"/>
        <source>&amp;Add to play list</source>
        <translation>&amp;Додати до списку відтворення</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="393"/>
        <source>&amp;Open video in browser...</source>
        <translation>&amp;Відкрити відео у браузері...</translation>
    </message>
</context>
<context>
    <name>VideoSearchPanel</name>
    <message>
        <location filename="../videosearch.ui" line="14"/>
        <source>Form</source>
        <translation>Від</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="32"/>
        <source>Search:</source>
        <translation>Пошук:</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="93"/>
        <source>Clear</source>
        <translation>Очистити</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="100"/>
        <source>More</source>
        <translation>Більше</translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Гучність</translation>
    </message>
</context>
</TS>