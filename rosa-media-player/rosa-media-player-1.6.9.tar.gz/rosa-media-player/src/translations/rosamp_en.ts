<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="156"/>
        <source>The following people have contributed with translations:</source>
        <translation>The following people have contributed with translations:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="162"/>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="163"/>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="164"/>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="167"/>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="237"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 and %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="171"/>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="172"/>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="234"/>
        <source>%1 and %2</source>
        <translation>%1 and %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="173"/>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="83"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation type="obsolete">(c) ROSA 2011-2012

ROSA Media Player is a free software.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Polish</source>
        <translation>Polish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="180"/>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="187"/>
        <source>Portuguese - Brazil</source>
        <translation>Portuguese - Brazil</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="189"/>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="193"/>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="194"/>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="195"/>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Traditional Chinese</source>
        <translation>Traditional Chinese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="197"/>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="198"/>
        <source>Portuguese - Portugal</source>
        <translation>Portuguese - Portugal</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="202"/>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <location filename="../about.cpp" line="267"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="291"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="26"/>
        <source>About ROSA Media Player</source>
        <translation>About ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../about.ui" line="75"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;MS Shell Dlg 2&apos;; font-size:8.25pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:&apos;Droid Sans&apos;; font-size:10pt;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="203"/>
        <source>Korean</source>
        <translation>Korean</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Macedonian</source>
        <translation>Macedonian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Basque</source>
        <translation>Basque</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="80"/>
        <source>Using MPlayer %1</source>
        <translation>Using MPlayer %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="89"/>
        <source>(c) ROSA 2011-2013

ROSA Media Player is a free software.</source>
        <translation type="unfinished">(c) ROSA 2011-2012

ROSA Media Player is a free software. {2011-2013
?}</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>terms of use</source>
        <translation>terms of use</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="112"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Slovenian</source>
        <translation>Slovenian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Kurdish</source>
        <translation>Kurdish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Galician</source>
        <translation>Galician</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="240"/>
        <source>%1, %2, %3 and %4</source>
        <translation>%1, %2, %3 and %4</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="243"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation>%1, %2, %3, %4 and %5</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="211"/>
        <source>Vietnamese</source>
        <translation>Vietnamese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="212"/>
        <source>Estonian</source>
        <translation>Estonian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Lithuanian</source>
        <translation>Lithuanian</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Description</source>
        <translation>Description</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="167"/>
        <source>Shortcut</source>
        <translation>Shortcut</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="169"/>
        <source>&amp;Save</source>
        <translation>&amp;Save</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="172"/>
        <source>&amp;Load</source>
        <translation>&amp;Load</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="420"/>
        <location filename="../actionseditor.cpp" line="479"/>
        <source>Key files</source>
        <translation>Key files</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="418"/>
        <source>Choose a filename</source>
        <translation>Choose a filename</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="432"/>
        <source>Confirm overwrite?</source>
        <translation>Confirm overwrite?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="433"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>The file %1 already exists.
Do you want to overwrite?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="478"/>
        <source>Choose a file</source>
        <translation>Choose a file</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="447"/>
        <location filename="../actionseditor.cpp" line="487"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="448"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>The file couldn&apos;t be saved</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="488"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>The file couldn&apos;t be loaded</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="176"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Change shortcut...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>Audio Equalizer</source>
        <translation>Audio Equalizer</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>31.25 Hz</source>
        <translation>31.25 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>62.50 Hz</source>
        <translation>62.50 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>125.0 Hz</source>
        <translation>125.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>250.0 Hz</source>
        <translation>250.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>500.0 Hz</source>
        <translation>500.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>1.000 kHz</source>
        <translation>1.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="87"/>
        <source>2.000 kHz</source>
        <translation>2.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>4.000 kHz</source>
        <translation>4.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>8.000 kHz</source>
        <translation>8.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>16.00 kHz</source>
        <translation>16.00 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="92"/>
        <source>&amp;Apply</source>
        <translation>&amp;Apply</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="93"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Close</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Set as default values</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Use the current values as default values for new videos.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Set all controls to zero.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="120"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="121"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>The current values have been stored to be used as default.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1596"/>
        <source>&amp;Open</source>
        <translation>&amp;Open</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1597"/>
        <source>&amp;Video</source>
        <translation>&amp;Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1599"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Subtitles</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;Browse</source>
        <translation>&amp;Browse</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1601"/>
        <source>Op&amp;tions</source>
        <translation>Op&amp;tions</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1602"/>
        <source>&amp;Help</source>
        <translation>&amp;Help</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>&amp;File...</source>
        <translation>&amp;File...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1422"/>
        <source>D&amp;irectory...</source>
        <translation>D&amp;irectory...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1423"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Playlist...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD from drive</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1427"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD from folder...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1608"/>
        <source>&amp;Clear</source>
        <translation>&amp;Clear</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1605"/>
        <source>&amp;Recent files</source>
        <translation>&amp;Recent files</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>P&amp;lay</source>
        <translation>P&amp;lay</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1450"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pause</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1451"/>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>&amp;Frame step</source>
        <translation>&amp;Frame step</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normal speed</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Halve speed</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Double speed</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed &amp;-10%</source>
        <translation>Speed &amp;-10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>Speed &amp;+10%</source>
        <translation>Speed &amp;+10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1541"/>
        <source>About &amp;ROSA Media Player</source>
        <translation>About &amp;ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1619"/>
        <source>Sp&amp;eed</source>
        <translation>Sp&amp;eed</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Fullscreen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1628"/>
        <source>Si&amp;ze</source>
        <translation>Si&amp;ze</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1672"/>
        <location filename="../basegui.cpp" line="2754"/>
        <source>&amp;None</source>
        <translation>&amp;None</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Linear &amp;Blend</source>
        <translation>Linear &amp;Blend</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1637"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Deinterlace</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Postprocessing</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetect phase</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Add n&amp;oise</source>
        <translation>Add n&amp;oise</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1641"/>
        <source>F&amp;ilters</source>
        <translation>F&amp;ilters</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Equalizer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>&amp;Screenshot</source>
        <translation>&amp;Screenshot</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1512"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;Filters</source>
        <translation>&amp;Filters</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1708"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1709"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Channels</source>
        <translation>&amp;Channels</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>&amp;Mute</source>
        <translation>&amp;Mute</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>Volume &amp;-</source>
        <translation>Volume &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <source>Volume &amp;+</source>
        <translation>Volume &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1504"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Delay -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1505"/>
        <source>D&amp;elay +</source>
        <translation>D&amp;elay +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1712"/>
        <source>&amp;Select</source>
        <translation>&amp;Select</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>&amp;Load...</source>
        <translation>&amp;Load...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>&amp;Title</source>
        <translation>&amp;Title</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1724"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Chapter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>&amp;Angle</source>
        <translation>&amp;Angle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Playlist</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Disabled</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2770"/>
        <location filename="../basegui.cpp" line="2790"/>
        <location filename="../basegui.cpp" line="2810"/>
        <location filename="../basegui.cpp" line="2829"/>
        <location filename="../basegui.cpp" line="2858"/>
        <location filename="../basegui.cpp" line="2890"/>
        <location filename="../basegui.cpp" line="2917"/>
        <location filename="../basegui.cpp" line="2960"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;empty&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3280"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3281"/>
        <location filename="../basegui.cpp" line="3519"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3282"/>
        <source>Playlists</source>
        <translation>Playlists</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3283"/>
        <location filename="../basegui.cpp" line="3497"/>
        <location filename="../basegui.cpp" line="3520"/>
        <source>All files</source>
        <translation>All files</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3278"/>
        <location filename="../basegui.cpp" line="3494"/>
        <location filename="../basegui.cpp" line="3517"/>
        <source>Choose a file</source>
        <translation>Choose a file</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1756"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation>ROSA Media Player - mplayer log</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3342"/>
        <source>ROSA Media Player - Information</source>
        <translation>ROSA Media Player - Information</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3343"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3452"/>
        <source>Choose a directory</source>
        <translation>Choose a directory</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3496"/>
        <source>Subtitles</source>
        <translation>Subtitles</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3578"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation>ROSA Media Player - Audio delay</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3882"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</translation>
    </message>
    <message>
        <source>Playing %1</source>
        <translation type="obsolete">Playing %1</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pause</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1454"/>
        <source>Play / Pause</source>
        <translation>Play / Pause</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1460"/>
        <source>Pause / Frame step</source>
        <translation>Pause / Frame step</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <location filename="../basegui.cpp" line="1517"/>
        <source>U&amp;nload</source>
        <translation>U&amp;nload</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="256"/>
        <source>Play list</source>
        <translation>Play list</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Trim video</source>
        <translation>Trim video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="258"/>
        <source>Extract audio track</source>
        <translation>Extract audio track</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>C&amp;lose</source>
        <translation>C&amp;lose</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1457"/>
        <source>Show / Hide right panel</source>
        <translation>Show / Hide right panel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1528"/>
        <source>&amp;Off</source>
        <comment>closed captions menu</comment>
        <translation type="unfinished">&amp;Off</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1536"/>
        <source>View &amp;info and properties...</source>
        <translation>View &amp;info and properties...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1537"/>
        <source>P&amp;references...</source>
        <translation>P&amp;references...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1540"/>
        <source>Help &amp;Contents</source>
        <translation>Help &amp;Contents</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Dec volume (2)</source>
        <translation>Dec volume (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Inc volume (2)</source>
        <translation>Inc volume (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Exit fullscreen</source>
        <translation>Exit fullscreen</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>OSD - Next level</source>
        <translation>OSD - Next level</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Dec contrast</source>
        <translation>Dec contrast</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Inc contrast</source>
        <translation>Inc contrast</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Dec brightness</source>
        <translation>Dec brightness</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Inc brightness</source>
        <translation>Inc brightness</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Dec hue</source>
        <translation>Dec hue</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>Inc hue</source>
        <translation>Inc hue</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Dec saturation</source>
        <translation>Dec saturation</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Dec gamma</source>
        <translation>Dec gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1580"/>
        <source>Next audio</source>
        <translation>Next audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Next subtitle</source>
        <translation>Next subtitle</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Next chapter</source>
        <translation>Next chapter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1583"/>
        <source>Previous chapter</source>
        <translation>Previous chapter</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1716"/>
        <source>&amp;Closed captions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2121"/>
        <source>Capture desktop...</source>
        <translation>Capture desktop...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3355"/>
        <source>YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Video capture</source>
        <translation type="obsolete">Video capture</translation>
    </message>
    <message>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="obsolete">Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</translation>
    </message>
    <message>
        <source>Start capture</source>
        <translation type="obsolete">Start capture</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Cancel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Inc saturation</source>
        <translation>Inc saturation</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Inc gamma</source>
        <translation>Inc gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Load external file...</source>
        <translation>&amp;Load external file...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normal)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (double framerate)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1544"/>
        <source>&amp;Next</source>
        <translation>&amp;Next</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1545"/>
        <source>Pre&amp;vious</source>
        <translation>Pre&amp;vious</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>Volume &amp;normalization</source>
        <translation>Volume &amp;normalization</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Audio CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Denoise nor&amp;mal</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1681"/>
        <source>Denoise &amp;soft</source>
        <translation>Denoise &amp;soft</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1679"/>
        <source>Denoise o&amp;ff</source>
        <translation>Denoise o&amp;ff</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1520"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>Use SSA/&amp;ASS library</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1584"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Toggle double size</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1518"/>
        <source>S&amp;ize -</source>
        <translation>S&amp;ize -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Si&amp;ze +</source>
        <translation>Si&amp;ze +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1491"/>
        <source>Add &amp;black borders</source>
        <translation>Add &amp;black borders</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1492"/>
        <source>Soft&amp;ware scaling</source>
        <translation>Soft&amp;ware scaling</translation>
    </message>
    <message>
        <source>Enable &amp;closed caption</source>
        <translation type="obsolete">Enable &amp;closed caption</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>&amp;Forced subtitles only</source>
        <translation>&amp;Forced subtitles only</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1585"/>
        <source>Reset video equalizer</source>
        <translation>Reset video equalizer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1757"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation>ROSA Media Player - rosa-media-player log</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4479"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>MPlayer has finished unexpectedly.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4480"/>
        <source>Exit code: %1</source>
        <translation>Exit code: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4501"/>
        <source>MPlayer failed to start.</source>
        <translation>MPlayer failed to start.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4502"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Please check the MPlayer path in preferences.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4506"/>
        <source>MPlayer has crashed.</source>
        <translation>MPlayer has crashed.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4507"/>
        <source>See the log for more info.</source>
        <translation>See the log for more info.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1645"/>
        <source>&amp;Rotate</source>
        <translation>&amp;Rotate</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1683"/>
        <source>&amp;Off</source>
        <translation>&amp;Off</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>&amp;Rotate by 90 degrees clockwise and flip</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1685"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>Rotate by 90 degrees &amp;clockwise</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1686"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>Rotate by 90 degrees counterclock&amp;wise</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1687"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>Rotate by 90 degrees counterclockwise and &amp;flip</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>Show context menu</source>
        <translation>Show context menu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3279"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1495"/>
        <source>E&amp;qualizer</source>
        <translation>E&amp;qualizer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>Reset audio equalizer</source>
        <translation>Reset audio equalizer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>Find subtitles on &amp;OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Upload su&amp;btitles to OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Auto</source>
        <translation>&amp;Auto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;4%</source>
        <translation>Speed -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>&amp;Speed +4%</source>
        <translation>&amp;Speed +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1470"/>
        <source>Speed -&amp;1%</source>
        <translation>Speed -&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1471"/>
        <source>S&amp;peed +1%</source>
        <translation>S&amp;peed +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>Scree&amp;n</source>
        <translation>Scree&amp;n</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1690"/>
        <source>&amp;Default</source>
        <translation>&amp;Default</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next video</source>
        <translation>Next video</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1624"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Track</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1694"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Track</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3881"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Warning - Using old MPlayer</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3887"/>
        <source>Please, update your MPlayer.</source>
        <translation>Please, update your MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3889"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(This warning won&apos;t be displayed anymore)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>Next aspect ratio</source>
        <translation>Next aspect ratio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1477"/>
        <source>Pre&amp;view...</source>
        <translation>Pre&amp;view...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>DVD &amp;menu</source>
        <translation>DVD &amp;menu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1746"/>
        <source>DVD &amp;previous menu</source>
        <translation>DVD &amp;previous menu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1740"/>
        <source>DVD menu, move up</source>
        <translation>DVD menu, move up</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1741"/>
        <source>DVD menu, move down</source>
        <translation>DVD menu, move down</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1742"/>
        <source>DVD menu, move left</source>
        <translation>DVD menu, move left</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>DVD menu, move right</source>
        <translation>DVD menu, move right</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1745"/>
        <source>DVD menu, select option</source>
        <translation>DVD menu, select option</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1747"/>
        <source>DVD menu, mouse click</source>
        <translation>DVD menu, mouse click</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>Set dela&amp;y...</source>
        <translation>Set dela&amp;y...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3579"/>
        <source>Audio delay (in milliseconds):</source>
        <translation>Audio delay (in milliseconds):</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4072"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4214"/>
        <source>Jump to %1</source>
        <translation>Jump to %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1523"/>
        <source>Subtitle &amp;visibility</source>
        <translation>Subtitle &amp;visibility</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>Next wheel function</source>
        <translation>Next wheel function</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation>P&amp;rogram</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1432"/>
        <location filename="../basegui.cpp" line="1433"/>
        <source>&amp;Edit...</source>
        <translation>&amp;Edit...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1436"/>
        <source>Next TV channel</source>
        <translation>Next TV channel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1437"/>
        <source>Previous TV channel</source>
        <translation>Previous TV channel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1438"/>
        <source>Next radio channel</source>
        <translation>Next radio channel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1439"/>
        <source>Previous radio channel</source>
        <translation>Previous radio channel</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1610"/>
        <source>&amp;TV</source>
        <translation>&amp;TV</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>Radi&amp;o</source>
        <translation>Radi&amp;o</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1434"/>
        <location filename="../basegui.cpp" line="1435"/>
        <source>&amp;Jump...</source>
        <translation>&amp;Jump...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1374"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation>Video filters are disabled when using vdpau</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1478"/>
        <source>Fli&amp;p image</source>
        <translation>Fli&amp;p image</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Show filename on OSD</source>
        <translation>Show filename on OSD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>Toggle deinterlacing</source>
        <translation>Toggle deinterlacing</translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation>ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation>ROSA Media Player is still running here</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Hide</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Restore</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>&amp;Quit</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Playlist</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation>00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="83"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3145"/>
        <source>Brightness: %1</source>
        <translation>Brightness: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3162"/>
        <source>Contrast: %1</source>
        <translation>Contrast: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3178"/>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3194"/>
        <source>Hue: %1</source>
        <translation>Hue: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3210"/>
        <source>Saturation: %1</source>
        <translation>Saturation: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3362"/>
        <source>Volume: %1</source>
        <translation>Volume: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4328"/>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3500"/>
        <location filename="../core.cpp" line="3518"/>
        <source>Font scale: %1</source>
        <translation>Font scale: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4182"/>
        <source>Aspect ratio: %1</source>
        <translation>Aspect ratio: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4595"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation>Updating the font cache. This may take some seconds...</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3411"/>
        <source>Subtitle delay: %1 ms</source>
        <translation>Subtitle delay: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3431"/>
        <source>Audio delay: %1 ms</source>
        <translation>Audio delay: %1 ms</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3275"/>
        <source>Speed: %1</source>
        <translation>Speed: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="199"/>
        <source>Connecting to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="203"/>
        <source>Unable to retrieve youtube page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="207"/>
        <source>Unable to locate the url of the video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3572"/>
        <source>Subtitles on</source>
        <translation>Subtitles on</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3574"/>
        <source>Subtitles off</source>
        <translation>Subtitles off</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4233"/>
        <source>Mouse wheel seeks now</source>
        <translation>Mouse wheel seeks now</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4236"/>
        <source>Mouse wheel changes volume now</source>
        <translation>Mouse wheel changes volume now</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4239"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation>Mouse wheel changes zoom level now</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4242"/>
        <source>Mouse wheel changes speed now</source>
        <translation>Mouse wheel changes speed now</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1205"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation>Screenshot NOT taken, folder not configured</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1221"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation>Screenshots NOT taken, folder not configured</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2865"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation>&quot;A&quot; marker set to %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2884"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation>&quot;B&quot; marker set to %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2902"/>
        <source>A-B markers cleared</source>
        <translation>A-B markers cleared</translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation>Output file format:</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation>Cannot extract audio track ( maybe you have no enough disk space? )</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation>Cannot extract audio track (code: %1)</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>New file &quot;%1&quot; saved in the folder %2</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation>Output file format:</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation>mp3</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation>ogg</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation>Extract</translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <source>Welcome to ROSA Media Player</source>
        <translation type="obsolete">Welcome to ROSA Media Player</translation>
    </message>
    <message>
        <source>A:%1</source>
        <translation type="obsolete">A:%1</translation>
    </message>
    <message>
        <source>B:%1</source>
        <translation type="obsolete">B:%1</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="320"/>
        <source>&amp;Video info</source>
        <translation>&amp;Video info</translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="321"/>
        <source>&amp;Frame counter</source>
        <translation>&amp;Frame counter</translation>
    </message>
    <message>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation type="obsolete">%1x%2 %3 fps</translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>icon</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Hide log</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Show log</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>MPlayer Error</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>icon</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation>Icon</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation>Media</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation>Favorite editor</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation>Favorite list</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation>Select an icon file</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation>Images</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation>icon</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation>&amp;New</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation>D&amp;elete</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation>Delete &amp;all</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation>&amp;Up</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation>&amp;Down</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation>Jump to item</translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation>Enter the number of the item in the list to jump:</translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation>...</translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Downloading...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Downloading %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation>ROSA Media Player - File properties</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Information</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Select the demuxer that will be used for this file:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Video codec</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Select the video codec:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>A&amp;udio codec</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Select the audio codec:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>&amp;MPlayer options</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Additional Options for MPlayer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Options:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>V&amp;ideo filters:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Audio &amp;filters:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="140"/>
        <source>Apply</source>
        <translation>Apply</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation>add noise</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation>deblock</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation>normal denoise</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation>soft denoise</translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation>volume normalization</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation>Http</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation>Enable/disable the use of the proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation>The host name of the proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation>The port of the proxy.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation>If the proxy requires authentication, this sets the username.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation>Select the proxy type to be used.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation>Advanced options</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation>Proxy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation>&amp;Enable proxy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation>&amp;Host:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation>&amp;Port:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation>&amp;Username:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation>Pa&amp;ssword:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation>&amp;Type:</translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Files</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Uploaded by</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>All</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Download</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Copy link to clipboard</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>Download failed: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>Connecting to %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>Downloading...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Done.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 files available</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Failed to parse the received data.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Find Subtitles</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Subtitles for</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Language:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Refresh</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Subtitle saved as %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation>
            <numerusform>%1 subtitle extracted</numerusform>
            <numerusform>%1 subtitles extracted</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Overwrite?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>The file %1 already exits, overwrite?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Error saving file</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation>Download failed</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation>Temporary file %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation>&amp;Options</translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Size</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Length</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Artist</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Author</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Genre</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Comment</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Software</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Clip info</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Video</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Resolution</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Aspect ratio</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Frames per second</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Selected codec</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Initial Audio Stream</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Rate</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Channels</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Audio Streams</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>empty</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Subtitles</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Stream title</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>Stream URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>File</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Choose a directory</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation>ROSA Media Player - Play a DVD from a folder</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Choose a directory...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation>ROSA Media Player - Enter the MPlayer version</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>Version reported by MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Please, &amp;select the correct version:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 or older</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation>1.0rc3 or newer</translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation>ROSA Media Player - Enter URL</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;URL:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>It&apos;s a &amp;playlist</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="34"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Abkhazian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Amharic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Assamese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Aymara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Azerbaijani</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Bashkir</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Bengali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Tibetan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Breton</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Corsican</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Welsh</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Danish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation>Estonian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Basque</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Persian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Faroese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Frisian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Irish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Galician</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Guarani</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Hebrew</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Croatian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Armenian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Indonesian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Icelandic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Javanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Kazakh</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Greenlandic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Korean</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Kashmiri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Kurdish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Kirghiz</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Latin</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Lithuanian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Latvian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Malagasy</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Maori</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Macedonian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Mongolian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Moldavian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Malay</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Maltese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Burmese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Nepali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Norwegian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Occitan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Polish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Portuguese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Sanskrit</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Slovenian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Samoan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Somali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Albanian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Sundanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Tajik</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Tigrinya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Turkmen</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Tatar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Uighur</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Uzbek</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Vietnamese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Yiddish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Yoruba</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Portuguese - Brazil</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Portuguese - Portugal</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Traditional Chinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Western European Languages</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Western European Languages with Euro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Slavic/Central European Languages</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galician, Maltese, Turkish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Old Baltic charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Cyrillic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Modern Greek</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Baltic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Celtic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Hebrew charsets</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainian, Belarusian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Simplified Chinese charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Traditional Chinese charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Japanese charsets</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Korean charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Thai charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Cyrillic Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Slavic/Central European Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Arabic Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation>Avestan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation>Akan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation>Aragonese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation>Avaric</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation>Belarusian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation>Bambara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation>Bosnian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation>Chechen</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation>Cree</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation>Church</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation>Chuvash</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation>Divehi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation>Dzongkha</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation>Fulah</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation>Fijian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation>Gaelic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation>Manx</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation>Hiri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation>Haitian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation>Herero</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation>Chamorro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation>Sichuan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation>Inupiaq</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation>Ido</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation>Kikuyu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation>Kuanyama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation>Khmer</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation>Kanuri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation>Komi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation>Cornish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation>Luxembourgish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation>Ganda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation>Limburgan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation>Lao</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation>Luba-Katanga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation>Marshallese</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation>Bokmål</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation>Ndebele</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation>Ndonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation>Navajo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation>Chichewa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation>Ojibwa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation>Oromo</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation>Ossetian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation>Panjabi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation>Pali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation>Pushto</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation>Romansh</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation>Rundi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation>Sardinian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation>Sami</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation>Sango</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation>Sinhala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation>Swati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation>Sotho</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation>Tswana</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation>Tahitian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation>Venda</translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation>Volapük</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation>Walloon</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation>Modern Greek Windows</translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Choose a filename to save under</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Confirm overwrite?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>The file already exists.
Do you want to overwrite?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Error saving file</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>The log couldn&apos;t be saved</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Logs</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Log Window</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Copy to clipboard</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Close</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>Length</source>
        <translation>Length</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Play</source>
        <translation>&amp;Play</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="386"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edit</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="829"/>
        <location filename="../playlist.cpp" line="849"/>
        <source>Playlists</source>
        <translation>Playlists</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="827"/>
        <source>Choose a file</source>
        <translation>Choose a file</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="847"/>
        <source>Choose a filename</source>
        <translation>Choose a filename</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="861"/>
        <source>Confirm overwrite?</source>
        <translation>Confirm overwrite?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="862"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>The file %1 already exists.
Do you want to overwrite?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1080"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1081"/>
        <source>All files</source>
        <translation>All files</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>Select one or more files to open</source>
        <translation>Select one or more files to open</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1142"/>
        <source>Choose a directory</source>
        <translation>Choose a directory</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1367"/>
        <source>Edit name</source>
        <translation>Edit name</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1368"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Type the name that will be displayed in the playlist for this file:</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="346"/>
        <source>&amp;Load</source>
        <translation>&amp;Load</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Save</source>
        <translation>&amp;Save</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="351"/>
        <source>&amp;Next</source>
        <translation>&amp;Next</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="352"/>
        <source>Pre&amp;vious</source>
        <translation>Pre&amp;vious</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>Move &amp;up</source>
        <translation>Move &amp;up</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>Move &amp;down</source>
        <translation>Move &amp;down</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Repeat</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="372"/>
        <source>S&amp;huffle</source>
        <translation>S&amp;huffle</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="377"/>
        <source>Add &amp;current file</source>
        <translation>Add &amp;current file</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="378"/>
        <source>Add &amp;file(s)</source>
        <translation>Add &amp;file(s)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Add &amp;directory</source>
        <translation>Add &amp;directory</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="382"/>
        <source>Remove &amp;selected</source>
        <translation>Remove &amp;selected</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>Remove &amp;all</source>
        <translation>Remove &amp;all</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="390"/>
        <source>Add...</source>
        <translation>Add...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="392"/>
        <source>Remove...</source>
        <translation>Remove...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="396"/>
        <source>ROSA Media Player - Playlist</source>
        <translation>ROSA Media Player - Playlist</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="891"/>
        <source>Playlist modified</source>
        <translation>Playlist modified</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="892"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>There are unsaved changes, do you want to save the playlist?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Preferences</source>
        <translation>Preferences</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Playlist - Preferences</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>&amp;Add files in directories recursively</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Automatically get &amp;info about files added</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>&amp;Save copy of playlist on exit</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>&amp;Play files from start</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Warning</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Not all files could be associated. Please check your security permissions and retry.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>File Types</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Select all</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Check all file types in the list</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Uncheck all file types in the list</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>List of file types</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>File types</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation>Media files handled by ROSA Media Player:</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Select All</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Select None</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Select none</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="82"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="338"/>
        <source>Media settings</source>
        <translation>Media settings</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="112"/>
        <source>&amp;Disable screensaver</source>
        <translation>&amp;Disable screensaver</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="246"/>
        <source>Cha&amp;nnels by default:</source>
        <translation>Cha&amp;nnels by default:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="119"/>
        <source>YouTube support (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="49"/>
        <source>Preferred video &amp;quality:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="129"/>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>Main window</source>
        <translation>Main window</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="137"/>
        <source>A&amp;utoresize:</source>
        <translation>A&amp;utoresize:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="154"/>
        <source>Never</source>
        <translation>Never</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="159"/>
        <source>Whenever it&apos;s needed</source>
        <translation>Whenever it&apos;s needed</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="164"/>
        <source>Only after loading a new video</source>
        <translation>Only after loading a new video</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="187"/>
        <source>R&amp;emember position and size</source>
        <translation>R&amp;emember position and size</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="197"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Instances</source>
        <translation>Instances</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="206"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation>&amp;Use only one running instance of ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="216"/>
        <location filename="../prefgeneral.cpp" line="399"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="225"/>
        <source>&amp;Volume normalization by default</source>
        <translation>&amp;Volume normalization by default</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Disable screensaver</source>
        <translation>Disable screensaver</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="103"/>
        <source>1080p</source>
        <translation type="unfinished">1080p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="104"/>
        <source>720p</source>
        <translation type="unfinished">720p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="105"/>
        <source>480p</source>
        <translation type="unfinished">480p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="106"/>
        <source>360p</source>
        <translation type="unfinished">360p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="107"/>
        <source>240p</source>
        <translation type="unfinished">240p</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Automatically add files to playlist</source>
        <translation>Automatically add files to playlist</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</translation>
    </message>
    <message>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="obsolete">When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="340"/>
        <source>Remember settings</source>
        <translation>Remember settings</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="77"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>&amp;Remember settings for all files (audio track, subtitles...)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="105"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation>&amp;Automatically add files to playlist</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="345"/>
        <source>Close when finished</source>
        <translation>Close when finished</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="346"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="98"/>
        <source>2 (Stereo)</source>
        <translation>2 (Stereo)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="99"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 Surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="100"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 Surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="91"/>
        <source>&amp;Pause when minimized</source>
        <translation>&amp;Pause when minimized</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="349"/>
        <source>Pause when minimized</source>
        <translation>Pause when minimized</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="371"/>
        <source>Channels by default</source>
        <translation>Channels by default</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="84"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Close when finished playback</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="350"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="384"/>
        <source>Autoresize</source>
        <translation>Autoresize</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation>The main window can be resized automatically. Select the option you prefer.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Remember position and size</source>
        <translation>Remember position and size</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation>Use only one running instance of ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="396"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="401"/>
        <source>Volume normalization by default</source>
        <translation>Volume normalization by default</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="402"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation>Maximizes the volume without distorting the sound.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="362"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="372"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</translation>
    </message>
    <message>
        <source>Switch screensaver off</source>
        <translation type="obsolete">Switch screensaver off</translation>
    </message>
    <message>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="obsolete">This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</translation>
    </message>
    <message>
        <source>Avoid screensaver</source>
        <translation type="obsolete">Avoid screensaver</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="367"/>
        <source>Audio/video auto synchronization</source>
        <translation>Audio/video auto synchronization</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="368"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation>Gradually adjusts the A/V sync based on audio delay measurements.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="98"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation>Audio/video auto &amp;synchronization</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation>&amp;Audio:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation>Su&amp;btitles:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation>Preferred language:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation>Audi&amp;o:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation>&amp;Subtitle:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation>Or choose a track number:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation>Autoload</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation>Same name as movie</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation>All subs containing movie name</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation>All subs in directory</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation>Au&amp;toload subtitles files (*.srt, *.sub...):</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation>Encoding</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation>&amp;Default subtitle encoding:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation>Subtitles</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation>Preferred audio and subtitles</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation>Preferred audio language</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation>Preferred subtitle language</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation>Audio track</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation>Subtitle track</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation>Select the subtitle autoload method.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation>Default subtitle encoding</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation>Select the encoding which will be used for subtitle files by default.</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <source>ROSA Media Player - Help</source>
        <translation type="obsolete">ROSA Media Player - Help</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="161"/>
        <source>Close</source>
        <translation>Close</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation type="obsolete">Apply</translation>
    </message>
    <message>
        <source>Help</source>
        <translation type="obsolete">Help</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation>ROSA Media Player - Preferences</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>will show this message and then will exit.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>the main window will be closed when the file/playlist finishes.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>the main window won&apos;t be closed when the file/playlist finishes.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>the video will be played in fullscreen mode.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>the video will be played in window mode.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Restores the old associations and cleans up the registry.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Usage:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>directory</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>action_name</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>action_list</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>opens the default gui.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>subtitle_file</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>specifies the subtitle file to be loaded for the first video.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation>
            <numerusform>%1 second</numerusform>
            <numerusform>%1 seconds</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation>
            <numerusform>%1 minute</numerusform>
            <numerusform>%1 minutes</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 and %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="189"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation>disabled</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="219"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation>auto</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="222"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation>unknown</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation>width</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation>height</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation>specifies the coordinates where the main window will be displayed.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation>specifies the size of the main window.</translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="467"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation>This is ROSA Media Player running on %1</translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation>Enqueue in ROSA Media Player</translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>ZIP/UNZIP API error %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="155"/>
        <source>Source #</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="155"/>
        <source>Name: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="192"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation>Failed to start recording. Please check that ffmpeg is installed.</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="195"/>
        <source>Unknown error in recording occured</source>
        <translation>Unknown error in recording occured</translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="198"/>
        <source>Sorry, recording crashed</source>
        <translation>Sorry, recording crashed</translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="63"/>
        <source>/Screencast - </source>
        <translation>/Screencast - </translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="66"/>
        <source>\Screencast-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="91"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation>Screen capture was successfully saved to %1</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="118"/>
        <source>Length: %1
Size: %2
</source>
        <translation>Length: %1
Size: %2
</translation>
    </message>
</context>
<context>
    <name>ScreencastDialog</name>
    <message>
        <location filename="../screencast.ui" line="20"/>
        <source>Video capture</source>
        <translation type="unfinished">Video capture</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="34"/>
        <location filename="../screencast.cpp" line="99"/>
        <source>not recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="39"/>
        <source>microphone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="44"/>
        <source>line-out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="65"/>
        <source>Start capture</source>
        <translation type="unfinished">Start capture</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="75"/>
        <source>Cancel</source>
        <translation type="unfinished">Cancel</translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="82"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.ui" line="98"/>
        <source>Record audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="38"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="43"/>
        <source>&lt;p&gt;&lt;span style=&quot; color:#c00000;&quot;&gt;WARNING: The audio subsystem needs to be restarted before recording from the line-out. It may cause interruption of currently playing sound.&lt;/span&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencast.cpp" line="48"/>
        <source>&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>icon</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>label</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Modify shortcut</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Clear</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Press the key combination you want to assign</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Capture</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Capture keystrokes</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation>Start time must be before than the end time</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation>/Movie_</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation>Cannot trim video ( maybe you have no enough disk space? )</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation>Cannot trim video (code: %1)</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation>New file &quot;%1&quot; saved in the folder %2</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation>Split Video</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation>Specify the time interval:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation>From:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation>HH:mm:ss</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation>Set a current playback time</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation>To:</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation>Trim</translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Subtitle selection</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>This archive contains more than one subtitle file. Please choose the ones you want to extract.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Select All</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Select None</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="100"/>
        <source>Channel editor</source>
        <translation>Channel editor</translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="101"/>
        <source>TV/Radio list</source>
        <translation>TV/Radio list</translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Jump to:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Yes</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>No</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Contrast</source>
        <translation>Contrast</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Brightness</source>
        <translation>Brightness</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Hue</source>
        <translation>Hue</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Saturation</source>
        <translation>Saturation</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="98"/>
        <source>&amp;Close</source>
        <translation type="unfinished">&amp;Close</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>&amp;Reset</source>
        <translation>&amp;Reset</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="100"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Set as default values</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="104"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Use the current values as default values for new videos.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="106"/>
        <source>Set all controls to zero.</source>
        <translation>Set all controls to zero.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Video Equalizer</source>
        <translation>Video Equalizer</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="126"/>
        <source>Information</source>
        <translation>Information</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="127"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>The current values have been stored to be used as default.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation>Video preview</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation>Generated by ROSA Media Player</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation>Creating thumbnails...</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation>Size: %1 MB</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation>Length: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation>Save file</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation>Error saving file</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>The file couldn&apos;t be saved</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation>The following error has occurred while creating the thumbnails:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation>The temporary directory (%1) can&apos;t be created</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation>The mplayer process didn&apos;t run</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation>Resolution: %1x%2</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation>Video format: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation>Frames per second: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation>Aspect ratio: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation>The file %1 can&apos;t be loaded</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation>No filename</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation>The mplayer process didn&apos;t start while trying to get info about the video</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation>The length of the video is 0</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation>The file %1 doesn&apos;t exist</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation>Images</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation>No info</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation>Video bitrate: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation>Audio bitrate: %1</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation>Audio rate: %1</translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation>Default</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation>Video Preview</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation>&amp;File:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation>&amp;Columns:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation>&amp;Rows:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation>&amp;Aspect ratio:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation>&amp;Seconds to skip at the beginnning:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation>&amp;Maximum width:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation>The preview will be created for the video you specify here.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation>The thumbnails will be arranged on a table.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation>This option specifies the number of columns of the table.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation>This option specifies the number of rows of the table.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation>If the aspect ratio of the video is wrong, you can specify a different one here.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation>This option specifies the maximum width in pixels that the generated preview image will have.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation>Add playing &amp;time to thumbnails</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation>&amp;Extract frames as</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation>Enter here the DVD device or a folder with a DVD image.</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation>&amp;DVD device:</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation>Remember folder used to &amp;save the preview</translation>
    </message>
</context>
<context>
    <name>VideoSearch</name>
    <message>
        <location filename="../videosearch.cpp" line="158"/>
        <source>Context menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="322"/>
        <source>&lt;b&gt;Not enough free space to save video file&lt;b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="323"/>
        <source>Increase free space and try again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="326"/>
        <source>Error downloading video clip from YouTube</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="391"/>
        <source>&amp;Play</source>
        <translation type="unfinished">&amp;Play</translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="392"/>
        <source>&amp;Add to play list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.cpp" line="393"/>
        <source>&amp;Open video in browser...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoSearchPanel</name>
    <message>
        <location filename="../videosearch.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished">Form</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="32"/>
        <source>Search:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="93"/>
        <source>Clear</source>
        <translation type="unfinished">Clear</translation>
    </message>
    <message>
        <location filename="../videosearch.ui" line="100"/>
        <source>More</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
</context>
</TS>
