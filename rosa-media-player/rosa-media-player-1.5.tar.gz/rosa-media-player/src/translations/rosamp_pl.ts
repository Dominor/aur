<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="pl">
<context>
    <name>About</name>
    <message>
        <location filename="../about.cpp" line="168"/>
        <source>The following people have contributed with translations:</source>
        <translation>Udział w tłumaczeniu mają:</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="174"/>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="175"/>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="176"/>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="179"/>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="249"/>
        <source>%1, %2 and %3</source>
        <translation>%1, %2 i %3</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="183"/>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="184"/>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="246"/>
        <source>%1 and %2</source>
        <translation>%1 i %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="185"/>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="93"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;/head&gt;&lt;body&gt;&lt;table width=&quot;100%&quot; cellpadding=&quot;0&quot;&gt;&lt;tr&gt;&lt;td&gt;&lt;p&gt;&lt;span style=&quot;font-size:14pt; font-weight:600;&quot;&gt;ROSA Media Player&lt;/span&gt;&lt;br/&gt;&lt;br/&gt;Version %1&lt;/p&gt;&lt;/td&gt;&lt;td width=&quot;128&quot; valign=&quot;top&quot;&gt;&lt;img src=&quot;:/icons-png/logo.png&quot; width=&quot;128&quot; height=&quot;128&quot;&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="99"/>
        <source>(c) ROSA 2011-2012

ROSA Media Player is a free software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="188"/>
        <source>Polish</source>
        <translation>Polish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="191"/>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="192"/>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="196"/>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="199"/>
        <source>Portuguese - Brazil</source>
        <translation>Portuguese - Brazil</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="200"/>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="201"/>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="204"/>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="205"/>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="206"/>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="207"/>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="208"/>
        <source>Traditional Chinese</source>
        <translation>Traditional Chinese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="209"/>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="210"/>
        <source>Portuguese - Portugal</source>
        <translation>Portuguese - Portugal</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="213"/>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="214"/>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="267"/>
        <location filename="../about.cpp" line="279"/>
        <source>&lt;b&gt;%1&lt;/b&gt;: %2</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;: %2</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="303"/>
        <source>&lt;b&gt;%1&lt;/b&gt; (%2)</source>
        <translation>&lt;b&gt;%1&lt;/b&gt; (%2)</translation>
    </message>
    <message>
        <location filename="../about.ui" line="38"/>
        <source>About ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.ui" line="84"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Droid Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="215"/>
        <source>Korean</source>
        <translation>Korean</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="216"/>
        <source>Macedonian</source>
        <translation>Macedonian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="217"/>
        <source>Basque</source>
        <translation>Basque</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="90"/>
        <source>Using MPlayer %1</source>
        <translation>Używa MPlayera %1</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="100"/>
        <source>terms of use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="122"/>
        <source>This program is free software; you can redistribute it and/or modify it under the terms of the &lt;a href=&quot;http://www.gnu.org/licenses/gpl.html&quot;&gt;GNU General Public License&lt;/a&gt; as published by the &lt;a href=&quot;http://www.fsf.org&quot;&gt;Free Software Foundation&lt;/a&gt;; either version 3 of the License, or (at your option) any later version.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="218"/>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="219"/>
        <source>Slovenian</source>
        <translation>Slovenian</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="220"/>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="221"/>
        <source>Kurdish</source>
        <translation>Kurdish</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="222"/>
        <source>Galician</source>
        <translation>Galician</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="252"/>
        <source>%1, %2, %3 and %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="255"/>
        <source>%1, %2, %3, %4 and %5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="223"/>
        <source>Vietnamese</source>
        <translation type="unfinished">Vietnamese</translation>
    </message>
    <message>
        <location filename="../about.cpp" line="224"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../about.cpp" line="225"/>
        <source>Lithuanian</source>
        <translation type="unfinished">Lithuanian</translation>
    </message>
</context>
<context>
    <name>ActionsEditor</name>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="217"/>
        <source>Shortcut</source>
        <translation>Klawisz skrótu</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="219"/>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="222"/>
        <source>&amp;Load</source>
        <translation>&amp;Wczytaj</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="470"/>
        <location filename="../actionseditor.cpp" line="529"/>
        <source>Key files</source>
        <translation>Pliki Key</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="468"/>
        <source>Choose a filename</source>
        <translation>Wybierz nazwę pliku</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="482"/>
        <source>Confirm overwrite?</source>
        <translation>Nadpisać?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="483"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Plik %1 istnieje
Nadpisać go?</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="528"/>
        <source>Choose a file</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="497"/>
        <location filename="../actionseditor.cpp" line="537"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="498"/>
        <source>The file couldn&apos;t be saved</source>
        <translation>Plik nie może zostać zapisany</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="538"/>
        <source>The file couldn&apos;t be loaded</source>
        <translation>Plik nie może zostać wczytany</translation>
    </message>
    <message>
        <location filename="../actionseditor.cpp" line="226"/>
        <source>&amp;Change shortcut...</source>
        <translation>&amp;Zmień klawisz skrótu...</translation>
    </message>
</context>
<context>
    <name>AudioEqualizer</name>
    <message>
        <location filename="../audioequalizer.cpp" line="74"/>
        <source>Audio Equalizer</source>
        <translation>Korektor audio</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="77"/>
        <source>31.25 Hz</source>
        <translation>31.25 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="78"/>
        <source>62.50 Hz</source>
        <translation>62.50 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="79"/>
        <source>125.0 Hz</source>
        <translation>125.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="80"/>
        <source>250.0 Hz</source>
        <translation>250.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="81"/>
        <source>500.0 Hz</source>
        <translation>500.0 Hz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="82"/>
        <source>1.000 kHz</source>
        <translation>1.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="83"/>
        <source>2.000 kHz</source>
        <translation>2.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="84"/>
        <source>4.000 kHz</source>
        <translation>4.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="85"/>
        <source>8.000 kHz</source>
        <translation>8.000 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="86"/>
        <source>16.00 kHz</source>
        <translation>16.00 kHz</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="88"/>
        <source>&amp;Apply</source>
        <translation>&amp;Zatwierdź</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="89"/>
        <source>&amp;Reset</source>
        <translation>&amp;Resetuj</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="90"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Ustaw wartości jako domyślne</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="94"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Użyj aktualnych wartości jako domyślnych dla nowych plików wideo.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="96"/>
        <source>Set all controls to zero.</source>
        <translation>Ustaw wszystkie suwaki na zero.</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="117"/>
        <source>Information</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../audioequalizer.cpp" line="118"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Aktualne wartości zostaną przechowane aby mogły być użyte jako domyślne.</translation>
    </message>
</context>
<context>
    <name>BaseGui</name>
    <message>
        <location filename="../basegui.cpp" line="1586"/>
        <source>&amp;Open</source>
        <translation>&amp;Otwórz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1587"/>
        <source>&amp;Video</source>
        <translation>&amp;Wideo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1588"/>
        <source>&amp;Audio</source>
        <translation>&amp;Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1589"/>
        <source>&amp;Subtitles</source>
        <translation>&amp;Napisy</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1590"/>
        <source>&amp;Browse</source>
        <translation>&amp;Przeglądaj</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1591"/>
        <source>Op&amp;tions</source>
        <translation>Op&amp;cje</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1592"/>
        <source>&amp;Help</source>
        <translation>&amp;Pomoc</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1413"/>
        <source>&amp;File...</source>
        <translation>&amp;Plik ...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1414"/>
        <source>D&amp;irectory...</source>
        <translation>K&amp;atalog...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1415"/>
        <source>&amp;Playlist...</source>
        <translation>&amp;Lista odtwarzania...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1418"/>
        <source>&amp;DVD from drive</source>
        <translation>&amp;DVD z napędu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1419"/>
        <source>D&amp;VD from folder...</source>
        <translation>D&amp;VD z katalogu...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1420"/>
        <source>&amp;URL...</source>
        <translation>&amp;URL...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1531"/>
        <source>About &amp;ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1598"/>
        <source>&amp;Clear</source>
        <translation>&amp;Wyczyść</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1595"/>
        <source>&amp;Recent files</source>
        <translation>&amp;Ostatnio otwierane pliki</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="257"/>
        <source>Play list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1435"/>
        <source>P&amp;lay</source>
        <translation>O&amp;dtwarzaj</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1442"/>
        <source>&amp;Pause</source>
        <translation>&amp;Pauza</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1443"/>
        <source>&amp;Stop</source>
        <translation>&amp;Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1444"/>
        <source>&amp;Frame step</source>
        <translation>&amp;Krok</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1461"/>
        <source>&amp;Normal speed</source>
        <translation>&amp;Normala prędkość</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1462"/>
        <source>&amp;Halve speed</source>
        <translation>&amp;Połowa prędkości</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1463"/>
        <source>&amp;Double speed</source>
        <translation>&amp;Podwójna prędkość</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1464"/>
        <source>Speed &amp;-10%</source>
        <translation>Prędkość &amp;-10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1465"/>
        <source>Speed &amp;+10%</source>
        <translation>Prędkość &amp;+10%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1609"/>
        <source>Sp&amp;eed</source>
        <translation>&amp;Prędkość</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1472"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Pełny ekran</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1618"/>
        <source>Si&amp;ze</source>
        <translation>Ro&amp;zmiar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1662"/>
        <location filename="../basegui.cpp" line="2868"/>
        <source>&amp;None</source>
        <translation>&amp;Brak</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1663"/>
        <source>&amp;Lowpass5</source>
        <translation>&amp;Lowpass5</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1666"/>
        <source>Linear &amp;Blend</source>
        <translation>Liniowy &amp;Mieszany</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1627"/>
        <source>&amp;Deinterlace</source>
        <translation>&amp;Usuwanie przeplotu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1484"/>
        <source>&amp;Postprocessing</source>
        <translation>&amp;Przetwarzanie końcowe</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1485"/>
        <source>&amp;Autodetect phase</source>
        <translation>&amp;Autodetekcja fazy</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1486"/>
        <source>&amp;Deblock</source>
        <translation>&amp;Deblock</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1487"/>
        <source>De&amp;ring</source>
        <translation>De&amp;ring</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1488"/>
        <source>Add n&amp;oise</source>
        <translation>&amp;Dodaj szum</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1631"/>
        <source>F&amp;ilters</source>
        <translation>F&amp;iltry</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1473"/>
        <source>&amp;Equalizer</source>
        <translation>&amp;Korektor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1474"/>
        <source>&amp;Screenshot</source>
        <translation>&amp;Zrzut ekranu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1506"/>
        <source>&amp;Extrastereo</source>
        <translation>&amp;Extrastereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1507"/>
        <source>&amp;Karaoke</source>
        <translation>&amp;Karaoke</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1688"/>
        <source>&amp;Filters</source>
        <translation>&amp;Filtry</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1697"/>
        <source>&amp;Stereo</source>
        <translation>&amp;Stereo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1698"/>
        <source>&amp;4.0 Surround</source>
        <translation>&amp;4.0 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1699"/>
        <source>&amp;5.1 Surround</source>
        <translation>&amp;5.1 Surround</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1692"/>
        <source>&amp;Channels</source>
        <translation>&amp;Kanały</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1496"/>
        <source>&amp;Mute</source>
        <translation>&amp;Wycisz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1497"/>
        <source>Volume &amp;-</source>
        <translation>Ciszej &amp;-</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1498"/>
        <source>Volume &amp;+</source>
        <translation>Głośniej &amp;+</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1499"/>
        <source>&amp;Delay -</source>
        <translation>&amp;Opóźnij audio -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1500"/>
        <source>D&amp;elay +</source>
        <translation>P&amp;rzyśpiesz audio +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1702"/>
        <source>&amp;Select</source>
        <translation>&amp;Wybierz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1511"/>
        <source>&amp;Load...</source>
        <translation>&amp;Wczytaj...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1707"/>
        <source>&amp;Title</source>
        <translation>&amp;Tytuł</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1711"/>
        <source>&amp;Chapter</source>
        <translation>&amp;Rozdział</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1715"/>
        <source>&amp;Angle</source>
        <translation>&amp;Kąt widzenia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1525"/>
        <source>&amp;Playlist</source>
        <translation>&amp;Lista odtwarzania</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1660"/>
        <source>&amp;Disabled</source>
        <translation>&amp;Wyłączone</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2884"/>
        <location filename="../basegui.cpp" line="2904"/>
        <location filename="../basegui.cpp" line="2924"/>
        <location filename="../basegui.cpp" line="2943"/>
        <location filename="../basegui.cpp" line="2972"/>
        <location filename="../basegui.cpp" line="3004"/>
        <location filename="../basegui.cpp" line="3031"/>
        <location filename="../basegui.cpp" line="3074"/>
        <source>&lt;empty&gt;</source>
        <translation>&lt;brak&gt;</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3444"/>
        <source>Video</source>
        <translation>Wideo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3445"/>
        <location filename="../basegui.cpp" line="3674"/>
        <source>Audio</source>
        <translation>Audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3446"/>
        <source>Playlists</source>
        <translation>Listy odtwarzania</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3447"/>
        <location filename="../basegui.cpp" line="3652"/>
        <location filename="../basegui.cpp" line="3675"/>
        <source>All files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3442"/>
        <location filename="../basegui.cpp" line="3649"/>
        <location filename="../basegui.cpp" line="3672"/>
        <source>Choose a file</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3507"/>
        <source>The CDROM / DVD drives are not configured yet.
The configuration dialog will be shown now, so you can do it.</source>
        <translation>CDROM / DVD nie jest jeszcze skonfigurowany.
Zobaczysz zaraz dialog konfiguracji i możesz dokonać ustaweń.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3607"/>
        <source>Choose a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3651"/>
        <source>Subtitles</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4244"/>
        <source>Playing %1</source>
        <translation>Odtwarzanie %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4247"/>
        <source>Pause</source>
        <translation>Pauza</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4250"/>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1446"/>
        <source>Play / Pause</source>
        <translation>Odtwarzaj / Pauza</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1458"/>
        <source>Pause / Frame step</source>
        <translation>Pauza / Krok</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1503"/>
        <location filename="../basegui.cpp" line="1512"/>
        <source>U&amp;nload</source>
        <translation>W&amp;yładuj</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1416"/>
        <source>V&amp;CD</source>
        <translation>V&amp;CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="259"/>
        <source>Trim video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="260"/>
        <source>Extract audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1421"/>
        <source>C&amp;lose</source>
        <translation>Z&amp;amknij</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1452"/>
        <source>Show / Hide right panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1526"/>
        <source>View &amp;info and properties...</source>
        <translation>Pokaż &amp;informację i właściwości...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1527"/>
        <source>P&amp;references...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1530"/>
        <source>Help &amp;Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1552"/>
        <source>Dec volume (2)</source>
        <translation>Zmniejsz głośność (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1553"/>
        <source>Inc volume (2)</source>
        <translation>Zwiększ głośność (2)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1556"/>
        <source>Exit fullscreen</source>
        <translation>Wyjdź z pełnego ekranu</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1558"/>
        <source>OSD - Next level</source>
        <translation>OSD-następny poziom</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1559"/>
        <source>Dec contrast</source>
        <translation>Zmniejsz kontrast</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1560"/>
        <source>Inc contrast</source>
        <translation>Zwiększ kontrast</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1561"/>
        <source>Dec brightness</source>
        <translation>Zmniejsz jasność</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1562"/>
        <source>Inc brightness</source>
        <translation>Zwiększ jasność</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1563"/>
        <source>Dec hue</source>
        <translation>Zmniejsz odcień</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1564"/>
        <source>Inc hue</source>
        <translation>Zwiększ odcień</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1565"/>
        <source>Dec saturation</source>
        <translation>Zmniejsz saturację</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1567"/>
        <source>Dec gamma</source>
        <translation>Zmniejsz gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1570"/>
        <source>Next audio</source>
        <translation>Następne audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1571"/>
        <source>Next subtitle</source>
        <translation>Następne napisy</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1572"/>
        <source>Next chapter</source>
        <translation>Następny rozdział</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1573"/>
        <source>Previous chapter</source>
        <translation>Poprzedni rozdział</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="2213"/>
        <source>Capture desktop...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4834"/>
        <source>Video capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4835"/>
        <source>Screen capture is starting now. The player will be minimized to system tray at the time of video recording. Click on the red round icon in system tray to stop the recording.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4836"/>
        <source>Start capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4837"/>
        <source>Cancel</source>
        <translation type="unfinished">Anuluj</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1566"/>
        <source>Inc saturation</source>
        <translation>Zwiększ saturację</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1568"/>
        <source>Inc gamma</source>
        <translation>Zwiększ gamma</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1502"/>
        <source>&amp;Load external file...</source>
        <translation>&amp;Wczytaj zewnętrzny plik...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1667"/>
        <source>&amp;Kerndeint</source>
        <translation>&amp;Kerndeint</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1664"/>
        <source>&amp;Yadif (normal)</source>
        <translation>&amp;Yadif (normalny)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1665"/>
        <source>Y&amp;adif (double framerate)</source>
        <translation>Y&amp;adif (podwójna szybkość klatek)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1534"/>
        <source>&amp;Next</source>
        <translation>&amp;Następny</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1535"/>
        <source>Pre&amp;vious</source>
        <translation>Pop&amp;rzedni</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1508"/>
        <source>Volume &amp;normalization</source>
        <translation>Normalizacja &amp;głośności</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1417"/>
        <source>&amp;Audio CD</source>
        <translation>&amp;Audio CD</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1670"/>
        <source>Denoise nor&amp;mal</source>
        <translation>Normalne &amp;odszumianie</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1671"/>
        <source>Denoise &amp;soft</source>
        <translation>Programowe &amp;odszumianie</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1669"/>
        <source>Denoise o&amp;ff</source>
        <translation>Wyłączone &amp;odszumianie</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1515"/>
        <source>Use SSA/&amp;ASS library</source>
        <translation>Użyj biblioteki SSA/&amp;ASS</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1574"/>
        <source>&amp;Toggle double size</source>
        <translation>&amp;Przełącz na podwójny rozmiar</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1513"/>
        <source>S&amp;ize -</source>
        <translation>R&amp;ozmiar -</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1514"/>
        <source>Si&amp;ze +</source>
        <translation>R&amp;ozmiar +</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1489"/>
        <source>Add &amp;black borders</source>
        <translation>Dodaj &amp;czarne obramowanie</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1490"/>
        <source>Soft&amp;ware scaling</source>
        <translation>&amp;Programowe skalowanie</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1516"/>
        <source>Enable &amp;closed caption</source>
        <translation>Włącz funkcję &amp;napisów na ekranie</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1517"/>
        <source>&amp;Forced subtitles only</source>
        <translation>&amp;Tylko wymuszone napisy</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1575"/>
        <source>Reset video equalizer</source>
        <translation>Resetuj korektor wideo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1744"/>
        <source>ROSA Media Player - rosa-media-player log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4660"/>
        <source>MPlayer has finished unexpectedly.</source>
        <translation>MPlayer nieoczekiwanie zakończył pracę.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4661"/>
        <source>Exit code: %1</source>
        <translation>Kod wyjścia: %1</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4682"/>
        <source>MPlayer failed to start.</source>
        <translation>Błąd uruchomienia MPlayera.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4683"/>
        <source>Please check the MPlayer path in preferences.</source>
        <translation>Proszę sprawdź w ustawieniach ścieżkę do programu MPlayer.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4687"/>
        <source>MPlayer has crashed.</source>
        <translation>MPlayer uległ uszkodzeniu.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4688"/>
        <source>See the log for more info.</source>
        <translation>Więcej informacji-zobacz log.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1635"/>
        <source>&amp;Rotate</source>
        <translation>&amp;Obrót</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1673"/>
        <source>&amp;Off</source>
        <translation>&amp;Wyłączony</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1674"/>
        <source>&amp;Rotate by 90 degrees clockwise and flip</source>
        <translation>&amp;Obróć o 90 stopni w kierunku obrotu wskazówek zegara i odwróć obraz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1675"/>
        <source>Rotate by 90 degrees &amp;clockwise</source>
        <translation>&amp;Obróć o 90 stopni w kierunku obrotu wskazówek zegara</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1676"/>
        <source>Rotate by 90 degrees counterclock&amp;wise</source>
        <translation>Obróć o 90 stopni przeciwnie do kierunku obrotu wskazówek &amp;zegara</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1677"/>
        <source>Rotate by 90 degrees counterclockwise and &amp;flip</source>
        <translation>Obróć o 90 stopni przeciwnie do kierunku obrotu wskazówek &amp;zegara i odwróć obraz</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1577"/>
        <source>Show context menu</source>
        <translation>Pokaż menu kontekstowe</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3443"/>
        <source>Multimedia</source>
        <translation>Multimedia</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1493"/>
        <source>E&amp;qualizer</source>
        <translation>&amp;Korektor</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1576"/>
        <source>Reset audio equalizer</source>
        <translation>Resetuj korektor audio</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1521"/>
        <source>Find subtitles on &amp;OpenSubtitles.org...</source>
        <translation>Znajdź napisy w &amp;OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1522"/>
        <source>Upload su&amp;btitles to OpenSubtitles.org...</source>
        <translation>Wyślij &amp;napisy do OpenSubtitles.org...</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1650"/>
        <source>&amp;Auto</source>
        <translation>&amp;Auto</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1466"/>
        <source>Speed -&amp;4%</source>
        <translation>Prędkość -&amp;4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1467"/>
        <source>&amp;Speed +4%</source>
        <translation>&amp;Prędkość +4%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1468"/>
        <source>Speed -&amp;1%</source>
        <translation>Prędkość -&amp;1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1469"/>
        <source>S&amp;peed +1%</source>
        <translation>&amp;Prędkość +1%</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1640"/>
        <source>Scree&amp;n</source>
        <translation>Ekra&amp;n</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1680"/>
        <source>&amp;Default</source>
        <translation>&amp;Domyślne</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1569"/>
        <source>Next video</source>
        <translation>Następne wideo</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1614"/>
        <source>&amp;Track</source>
        <comment>video</comment>
        <translation>&amp;Ścieżka</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1684"/>
        <source>&amp;Track</source>
        <comment>audio</comment>
        <translation>&amp;Ścieżka</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1743"/>
        <source>ROSA Media Player - mplayer log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3506"/>
        <source>ROSA Media Player - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3728"/>
        <source>ROSA Media Player - Audio delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4033"/>
        <source>Warning - Using old MPlayer</source>
        <translation>Uwaga - Używasz starej wersji MPlayera</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4039"/>
        <source>Please, update your MPlayer.</source>
        <translation>Proszę zaktualizuj MPlayera.</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4041"/>
        <source>(This warning won&apos;t be displayed anymore)</source>
        <translation>(Ostrzeżenie to nie wyświetli się ponownie)</translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1578"/>
        <source>Next aspect ratio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1475"/>
        <source>Pre&amp;view...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1731"/>
        <source>DVD &amp;menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1733"/>
        <source>DVD &amp;previous menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1727"/>
        <source>DVD menu, move up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1728"/>
        <source>DVD menu, move down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1729"/>
        <source>DVD menu, move left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1730"/>
        <source>DVD menu, move right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1732"/>
        <source>DVD menu, select option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1734"/>
        <source>DVD menu, mouse click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1501"/>
        <source>Set dela&amp;y...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="3729"/>
        <source>Audio delay (in milliseconds):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4034"/>
        <source>The version of MPlayer (%1) installed on your system is obsolete. ROSA Media Player can&apos;t work well with it: some options won&apos;t work, subtitle selection may fail...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4253"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="4395"/>
        <source>Jump to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1519"/>
        <source>Subtitle &amp;visibility</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1579"/>
        <source>Next wheel function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1720"/>
        <source>P&amp;rogram</source>
        <comment>program</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1424"/>
        <location filename="../basegui.cpp" line="1425"/>
        <source>&amp;Edit...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1428"/>
        <source>Next TV channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1429"/>
        <source>Previous TV channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1430"/>
        <source>Next radio channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1431"/>
        <source>Previous radio channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1600"/>
        <source>&amp;TV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1604"/>
        <source>Radi&amp;o</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1426"/>
        <location filename="../basegui.cpp" line="1427"/>
        <source>&amp;Jump...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1366"/>
        <source>Video filters are disabled when using vdpau</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1476"/>
        <source>Fli&amp;p image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1581"/>
        <source>Show filename on OSD</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../basegui.cpp" line="1582"/>
        <source>Toggle deinterlacing</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BaseGuiPlus</name>
    <message>
        <location filename="../baseguiplus.cpp" line="67"/>
        <location filename="../baseguiplus.cpp" line="179"/>
        <source>ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="180"/>
        <source>ROSA Media Player is still running here</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="216"/>
        <source>&amp;Hide</source>
        <translation>&amp;Ukryj</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="218"/>
        <source>&amp;Restore</source>
        <translation>&amp;Przywróć</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="204"/>
        <source>&amp;Quit</source>
        <translation>&amp;Wyjdź</translation>
    </message>
    <message>
        <location filename="../baseguiplus.cpp" line="209"/>
        <source>Playlist</source>
        <translation>Lista odtwarzania</translation>
    </message>
</context>
<context>
    <name>ControlPanel</name>
    <message>
        <location filename="../controlpanel.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="34"/>
        <location filename="../controlpanel.ui" line="48"/>
        <source>00:00:00</source>
        <translation type="unfinished">00:00:00</translation>
    </message>
    <message>
        <location filename="../controlpanel.ui" line="57"/>
        <location filename="../controlpanel.ui" line="105"/>
        <location filename="../controlpanel.ui" line="127"/>
        <location filename="../controlpanel.ui" line="146"/>
        <location filename="../controlpanel.ui" line="165"/>
        <location filename="../controlpanel.ui" line="184"/>
        <location filename="../controlpanel.ui" line="223"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../controlpanel.cpp" line="76"/>
        <source>Volume</source>
        <translation type="unfinished">Głośność</translation>
    </message>
</context>
<context>
    <name>Core</name>
    <message>
        <location filename="../core.cpp" line="3078"/>
        <source>Brightness: %1</source>
        <translation>Jasność: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3095"/>
        <source>Contrast: %1</source>
        <translation>Kontrast: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3111"/>
        <source>Gamma: %1</source>
        <translation>Gamma: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3127"/>
        <source>Hue: %1</source>
        <translation>Odcień: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3143"/>
        <source>Saturation: %1</source>
        <translation>Nasycenie: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3295"/>
        <source>Volume: %1</source>
        <translation>Głośność: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4261"/>
        <source>Zoom: %1</source>
        <translation>Zoom: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3433"/>
        <location filename="../core.cpp" line="3451"/>
        <source>Font scale: %1</source>
        <translation>Skala czcionki: %1</translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4115"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4531"/>
        <source>Updating the font cache. This may take some seconds...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3344"/>
        <source>Subtitle delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3364"/>
        <source>Audio delay: %1 ms</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3208"/>
        <source>Speed: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3505"/>
        <source>Subtitles on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="3507"/>
        <source>Subtitles off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4166"/>
        <source>Mouse wheel seeks now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4169"/>
        <source>Mouse wheel changes volume now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4172"/>
        <source>Mouse wheel changes zoom level now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="4175"/>
        <source>Mouse wheel changes speed now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1149"/>
        <source>Screenshot NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="1165"/>
        <source>Screenshots NOT taken, folder not configured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2798"/>
        <source>&quot;A&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2817"/>
        <source>&quot;B&quot; marker set to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../core.cpp" line="2835"/>
        <source>A-B markers cleared</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CutAudio</name>
    <message>
        <location filename="../cutaudio.cpp" line="98"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="107"/>
        <source>The version of ffmpeg installed on your computer does not support the requested codec libmp3lame. To be able to extract audio streams please install ffmpeg with support for libmp3lame.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="276"/>
        <source>Cannot extract audio track ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="347"/>
        <source>Cannot extract audio track (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="358"/>
        <source>Information</source>
        <translation type="unfinished">Informacja</translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="359"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.cpp" line="360"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
</context>
<context>
    <name>CutAudioPanel</name>
    <message>
        <location filename="../cutaudio.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="38"/>
        <source>Output file format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="55"/>
        <source>mp3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="60"/>
        <source>ogg</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="161"/>
        <source>Cancel</source>
        <translation type="unfinished">Anuluj</translation>
    </message>
    <message>
        <location filename="../cutaudio.ui" line="168"/>
        <source>Extract</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DefaultGui</name>
    <message>
        <location filename="../defaultgui.cpp" line="362"/>
        <source>Welcome to ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="414"/>
        <source>A:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="419"/>
        <source>B:%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="389"/>
        <source>&amp;Video info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="390"/>
        <source>&amp;Frame counter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../defaultgui.cpp" line="429"/>
        <source>%1x%2 %3 fps</source>
        <comment>width + height + fps</comment>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EqSlider</name>
    <message>
        <location filename="../eqslider.ui" line="22"/>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
</context>
<context>
    <name>ErrorDialog</name>
    <message>
        <location filename="../errordialog.cpp" line="62"/>
        <source>Hide log</source>
        <translation>Ukryj log</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="87"/>
        <location filename="../errordialog.cpp" line="64"/>
        <source>Show log</source>
        <translation>Pokaż log</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="13"/>
        <source>MPlayer Error</source>
        <translation>Błąd programu MPlayer</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="41"/>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <location filename="../errordialog.ui" line="67"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
</context>
<context>
    <name>FavoriteEditor</name>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Name</source>
        <translation type="unfinished">Nazwa</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="36"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="46"/>
        <source>Favorite editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="34"/>
        <location filename="../favoriteeditor.cpp" line="48"/>
        <source>Favorite list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="49"/>
        <source>You can edit, delete, sort or add new items. Double click on a cell to edit its contents.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="245"/>
        <source>Select an icon file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.cpp" line="247"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="18"/>
        <source>icon</source>
        <translation type="unfinished">ikona</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="51"/>
        <source>&amp;New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="71"/>
        <source>D&amp;elete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="78"/>
        <source>Delete &amp;all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="98"/>
        <source>&amp;Up</source>
        <translation type="unfinished">&amp;Przesuń napisy w górę</translation>
    </message>
    <message>
        <location filename="../favoriteeditor.ui" line="105"/>
        <source>&amp;Down</source>
        <translation type="unfinished">&amp;Przesuń napisy w dół</translation>
    </message>
</context>
<context>
    <name>Favorites</name>
    <message>
        <location filename="../favorites.cpp" line="286"/>
        <source>Jump to item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../favorites.cpp" line="287"/>
        <source>Enter the number of the item in the list to jump:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileChooser</name>
    <message>
        <location filename="../filechooser.ui" line="26"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileDownloader</name>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="40"/>
        <source>Downloading...</source>
        <translation>Pobieranie...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/filedownloader/filedownloader.cpp" line="66"/>
        <source>Downloading %1</source>
        <translation>Pobieranie %1</translation>
    </message>
</context>
<context>
    <name>FilePropertiesDialog</name>
    <message>
        <location filename="../filepropertiesdialog.ui" line="15"/>
        <source>ROSA Media Player - File properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="34"/>
        <source>&amp;Information</source>
        <translation>&amp;Informacja</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="54"/>
        <source>&amp;Demuxer</source>
        <translation>&amp;Demuxer</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="66"/>
        <source>&amp;Select the demuxer that will be used for this file:</source>
        <translation>&amp;Wybierz demuxer, dla tego pliku:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="106"/>
        <location filename="../filepropertiesdialog.ui" line="168"/>
        <location filename="../filepropertiesdialog.ui" line="230"/>
        <source>&amp;Reset</source>
        <translation>&amp;Resetuj</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="116"/>
        <source>&amp;Video codec</source>
        <translation>&amp;Kodek Wideo</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="128"/>
        <source>&amp;Select the video codec:</source>
        <translation>&amp;Wybierz Kodek Wideo:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="178"/>
        <source>A&amp;udio codec</source>
        <translation>&amp;Kodek Audio</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="190"/>
        <source>&amp;Select the audio codec:</source>
        <translation>&amp;Wybierz Kodek Audio:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="240"/>
        <source>&amp;MPlayer options</source>
        <translation>&amp;Opcje MPlayera</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="252"/>
        <source>Additional Options for MPlayer</source>
        <translation>Dodatkowe opcje MPlayera</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="264"/>
        <source>Here you can pass extra options to MPlayer.
Write them separated by spaces.
Example: -flip -nosound</source>
        <translation>Tu możesz wpisać dodatkowe opcje MPlayera.
Wpisz oddzielając spacją. 
Przykład: -flip -nosound</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="287"/>
        <source>&amp;Options:</source>
        <translation>&amp;Opcje:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="324"/>
        <source>You can also pass additional video filters.
Separate them with &quot;,&quot;. Do not use spaces!
Example: scale=512:-2,eq2=1.1</source>
        <translation>Dodatkowe opcje filtrów wideo.
Wpisz oddzielając przecinkiem &quot;,&quot;. Nie używaj spacji!
Przykład: scale=512:-2,eq2=1.1</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="347"/>
        <source>V&amp;ideo filters:</source>
        <translation>F&amp;iltry Wideo:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="384"/>
        <source>And finally audio filters. Same rule as for video filters.
Example: resample=44100:0:0,volnorm</source>
        <translation>Opcje dla filtrów audio. Takie same zasady jak dla filtrów wideo.
Przykład: resample=44100:0:0,volnorm</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.ui" line="406"/>
        <source>Audio &amp;filters:</source>
        <translation>Filtry &amp;Audio:</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="137"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="138"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../filepropertiesdialog.cpp" line="139"/>
        <source>Apply</source>
        <translation>Zatwierdź</translation>
    </message>
</context>
<context>
    <name>Filters</name>
    <message>
        <location filename="../filters.cpp" line="34"/>
        <source>add noise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="35"/>
        <source>deblock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="36"/>
        <source>normal denoise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="37"/>
        <source>soft denoise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filters.cpp" line="40"/>
        <source>volume normalization</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindSubtitlesConfigDialog</name>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="28"/>
        <source>Http</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="29"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="31"/>
        <source>Enable/disable the use of the proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="32"/>
        <source>The host name of the proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="33"/>
        <source>The port of the proxy.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="34"/>
        <source>If the proxy requires authentication, this sets the username.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="36"/>
        <source>The password for the proxy. &lt;b&gt;Warning:&lt;/b&gt; the password will be saved as plain text in the configuration file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.cpp" line="38"/>
        <source>Select the proxy type to be used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="13"/>
        <source>Advanced options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="19"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="25"/>
        <source>&amp;Enable proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="38"/>
        <source>&amp;Host:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="51"/>
        <source>&amp;Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="71"/>
        <source>&amp;Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="84"/>
        <source>Pa&amp;ssword:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitlesconfigdialog.ui" line="101"/>
        <source>&amp;Type:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FindSubtitlesWindow</name>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="195"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Files</source>
        <translation>Pliki</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="196"/>
        <source>Uploaded by</source>
        <translation>Wysłane przez</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="212"/>
        <source>All</source>
        <translation>Wszystko</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="218"/>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="136"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="222"/>
        <source>&amp;Download</source>
        <translation>&amp;Pobieranie</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="223"/>
        <source>&amp;Copy link to clipboard</source>
        <translation>&amp;Kopiuj link do schowka</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="294"/>
        <source>Error</source>
        <translation>Błąd</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="295"/>
        <source>Download failed: %1.</source>
        <translation>Błąd pobierania: %1.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="300"/>
        <source>Connecting to %1...</source>
        <translation>Łączenie do %1...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="306"/>
        <source>Downloading...</source>
        <translation>Pobieranie...</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="314"/>
        <source>Done.</source>
        <translation>Wykonano.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="360"/>
        <source>%1 files available</source>
        <translation>%1 dostępnych plików</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="369"/>
        <source>Failed to parse the received data.</source>
        <translation>Błąd analizy przyjętych danych.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="13"/>
        <source>Find Subtitles</source>
        <translation>Znajdź napisy</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="51"/>
        <source>&amp;Subtitles for</source>
        <translation>&amp;Napisy dla</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="86"/>
        <source>&amp;Language:</source>
        <translation>&amp;Język:</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="126"/>
        <source>&amp;Refresh</source>
        <translation>&amp;Odśwież</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="514"/>
        <source>Subtitle saved as %1</source>
        <translation>Napisy zapisano jako %1</translation>
    </message>
    <message numerus="yes">
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="537"/>
        <source>%1 subtitle(s) extracted</source>
        <translation>
            <numerusform>%1 napisy(ów) wypakowano</numerusform>
            <numerusform>%1 napisy(ów) wypakowano</numerusform>
            <numerusform>%1 napisy(ów) wypakowano</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="551"/>
        <source>Overwrite?</source>
        <translation>Nadpisać?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="552"/>
        <source>The file %1 already exits, overwrite?</source>
        <translation>Plik %1 już istnieje, nadpisać go?</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="469"/>
        <source>Error saving file</source>
        <translation>Błąd zapisu pliku</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="470"/>
        <source>It wasn&apos;t possible to save the downloaded
file in folder %1
Please check the permissions of that folder.</source>
        <translation>Nie można było zapisać pobranego
pliku w folderze %1
Proszę sprawdź uprawnienia tego folderu.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="292"/>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="463"/>
        <source>Download failed</source>
        <translation>Błąd pobierania</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.cpp" line="447"/>
        <source>Temporary file %1</source>
        <translation>Plik tymczasowy %1</translation>
    </message>
    <message>
        <location filename="../findsubtitles/findsubtitleswindow.ui" line="116"/>
        <source>&amp;Options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InfoFile</name>
    <message>
        <location filename="../infofile.cpp" line="84"/>
        <source>General</source>
        <translation>Ogólne</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>Size</source>
        <translation>Rozmiar</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="89"/>
        <source>%1 KB (%2 MB)</source>
        <translation>%1 KB (%2 MB)</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="99"/>
        <source>URL</source>
        <translation>URL</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="101"/>
        <source>Length</source>
        <translation>Długość</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="102"/>
        <source>Demuxer</source>
        <translation>Demuxer</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="107"/>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="108"/>
        <source>Artist</source>
        <translation>Artysta</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="109"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="110"/>
        <source>Album</source>
        <translation>Album</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="111"/>
        <source>Genre</source>
        <translation>Gatunek</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="112"/>
        <source>Date</source>
        <translation>Data</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="113"/>
        <source>Track</source>
        <translation>Track</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="114"/>
        <source>Copyright</source>
        <translation>Copyright</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="115"/>
        <source>Comment</source>
        <translation>Komentarz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="116"/>
        <source>Software</source>
        <translation>Oprogramowanie</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="122"/>
        <source>Clip info</source>
        <translation>Info o klipie</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="130"/>
        <source>Video</source>
        <translation>Wideo</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="131"/>
        <source>Resolution</source>
        <translation>Rozdzielczość</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="132"/>
        <source>Aspect ratio</source>
        <translation>Współczynnik proporcji</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="133"/>
        <location filename="../infofile.cpp" line="142"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>Bitrate</source>
        <translation>Bitrate</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="134"/>
        <location filename="../infofile.cpp" line="143"/>
        <source>%1 kbps</source>
        <translation>%1 kbps</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="135"/>
        <source>Frames per second</source>
        <translation>Ramek na sekundę</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="136"/>
        <location filename="../infofile.cpp" line="146"/>
        <source>Selected codec</source>
        <translation>Użyty dekoder </translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="141"/>
        <source>Initial Audio Stream</source>
        <translation>Początkowy strumień audio</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>Rate</source>
        <translation>Tempo</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="144"/>
        <source>%1 Hz</source>
        <translation>%1 Hz</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="145"/>
        <source>Channels</source>
        <translation>Kanały</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="152"/>
        <source>Audio Streams</source>
        <translation>Strumienie audio</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="156"/>
        <location filename="../infofile.cpp" line="183"/>
        <source>Language</source>
        <translation>Język</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="164"/>
        <location filename="../infofile.cpp" line="166"/>
        <location filename="../infofile.cpp" line="203"/>
        <location filename="../infofile.cpp" line="205"/>
        <source>empty</source>
        <translation>brak</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="178"/>
        <source>Subtitles</source>
        <translation>Napisy</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="182"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="157"/>
        <location filename="../infofile.cpp" line="184"/>
        <source>ID</source>
        <comment>Info for translators: this is a identification code</comment>
        <translation>ID</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="155"/>
        <location filename="../infofile.cpp" line="181"/>
        <source>#</source>
        <comment>Info for translators: this is a abbreviation for number</comment>
        <translation>#</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="117"/>
        <source>Stream title</source>
        <translation>Nazwa strumienia</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="118"/>
        <source>Stream URL</source>
        <translation>URL strumienia</translation>
    </message>
    <message>
        <location filename="../infofile.cpp" line="88"/>
        <source>File</source>
        <translation>Plik</translation>
    </message>
</context>
<context>
    <name>InputDVDDirectory</name>
    <message>
        <location filename="../inputdvddirectory.cpp" line="52"/>
        <source>Choose a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="14"/>
        <source>ROSA Media Player - Play a DVD from a folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="35"/>
        <source>You can play a dvd from your hard disc. Just select the folder which contains the VIDEO_TS and AUDIO_TS directories.</source>
        <translation>Możesz odtwarzać DVD z dysku.
Wybierz katalog, w którym jest VIDEO_TS i AUDIO_TS.</translation>
    </message>
    <message>
        <location filename="../inputdvddirectory.ui" line="66"/>
        <source>Choose a directory...</source>
        <translation>Wybierz katalog ...</translation>
    </message>
</context>
<context>
    <name>InputMplayerVersion</name>
    <message>
        <location filename="../inputmplayerversion.ui" line="15"/>
        <source>ROSA Media Player - Enter the MPlayer version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="27"/>
        <source>ROSA Media Player couldn&apos;t identify the MPlayer version you&apos;re using.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="50"/>
        <source>Version reported by MPlayer:</source>
        <translation>Wersja zgłoszona przez MPlayer:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="85"/>
        <source>Please, &amp;select the correct version:</source>
        <translation>Proszę &amp;wybrać poprawną wersję:</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="96"/>
        <source>1.0rc1 or older</source>
        <translation>1.0rc1 lub starsza</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="101"/>
        <source>1.0rc2</source>
        <translation>1.0rc2</translation>
    </message>
    <message>
        <location filename="../inputmplayerversion.ui" line="106"/>
        <source>1.0rc3 or newer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputURL</name>
    <message>
        <location filename="../inputurl.ui" line="14"/>
        <source>ROSA Media Player - Enter URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="81"/>
        <source>&amp;URL:</source>
        <translation>&amp;URL:</translation>
    </message>
    <message>
        <location filename="../inputurl.ui" line="47"/>
        <source>It&apos;s a &amp;playlist</source>
        <translation>To jest &amp;lista odtwarzania</translation>
    </message>
    <message>
        <location filename="../inputurl.cpp" line="33"/>
        <source>If this option is checked, the URL will be treated as a playlist: it will be opened as text and will play the URLs in it.</source>
        <translation>Jeśli ta opcja jest zaznaczona, URL będzie traktowany jako lista odtwarzania: będzie otwarty jako tekst i z tego odtwarzany URL.</translation>
    </message>
</context>
<context>
    <name>Languages</name>
    <message>
        <location filename="../languages.cpp" line="27"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="28"/>
        <source>Abkhazian</source>
        <translation>Abkhazian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="30"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="32"/>
        <source>Amharic</source>
        <translation>Amharic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="34"/>
        <location filename="../languages.cpp" line="219"/>
        <location filename="../languages.cpp" line="271"/>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="35"/>
        <source>Assamese</source>
        <translation>Assamese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="37"/>
        <source>Aymara</source>
        <translation>Aymara</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="38"/>
        <source>Azerbaijani</source>
        <translation>Azerbaijani</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="39"/>
        <source>Bashkir</source>
        <translation>Bashkir</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="41"/>
        <location filename="../languages.cpp" line="220"/>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="42"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="43"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="45"/>
        <source>Bengali</source>
        <translation>Bengali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="46"/>
        <source>Tibetan</source>
        <translation>Tibetan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="47"/>
        <source>Breton</source>
        <translation>Breton</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="49"/>
        <location filename="../languages.cpp" line="221"/>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="51"/>
        <source>Corsican</source>
        <translation>Corsican</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="53"/>
        <location filename="../languages.cpp" line="222"/>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="56"/>
        <source>Welsh</source>
        <translation>Welsh</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="57"/>
        <source>Danish</source>
        <translation>Danish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="58"/>
        <location filename="../languages.cpp" line="223"/>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="62"/>
        <location filename="../languages.cpp" line="224"/>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="63"/>
        <location filename="../languages.cpp" line="225"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="64"/>
        <source>Esperanto</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="65"/>
        <location filename="../languages.cpp" line="226"/>
        <source>Spanish</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="66"/>
        <location filename="../languages.cpp" line="227"/>
        <source>Estonian</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="67"/>
        <location filename="../languages.cpp" line="228"/>
        <source>Basque</source>
        <translation>Basque</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="68"/>
        <source>Persian</source>
        <translation>Persian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="70"/>
        <location filename="../languages.cpp" line="229"/>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="72"/>
        <source>Faroese</source>
        <translation>Faroese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="73"/>
        <location filename="../languages.cpp" line="230"/>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="74"/>
        <source>Frisian</source>
        <translation>Frisian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="75"/>
        <source>Irish</source>
        <translation>Irish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="77"/>
        <location filename="../languages.cpp" line="231"/>
        <source>Galician</source>
        <translation>Galician</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="78"/>
        <source>Guarani</source>
        <translation>Guarani</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="79"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="81"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="82"/>
        <source>Hebrew</source>
        <translation>Hebrew</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="83"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="85"/>
        <source>Croatian</source>
        <translation>Croatian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="87"/>
        <location filename="../languages.cpp" line="232"/>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="88"/>
        <source>Armenian</source>
        <translation>Armenian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="91"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="92"/>
        <source>Indonesian</source>
        <translation>Indonesian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="93"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="98"/>
        <source>Icelandic</source>
        <translation>Icelandic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="99"/>
        <location filename="../languages.cpp" line="233"/>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="100"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="101"/>
        <location filename="../languages.cpp" line="234"/>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="102"/>
        <source>Javanese</source>
        <translation>Javanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="103"/>
        <location filename="../languages.cpp" line="235"/>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="107"/>
        <source>Kazakh</source>
        <translation>Kazakh</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="108"/>
        <source>Greenlandic</source>
        <translation>Greenlandic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="110"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="111"/>
        <location filename="../languages.cpp" line="236"/>
        <source>Korean</source>
        <translation>Korean</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="113"/>
        <source>Kashmiri</source>
        <translation>Kashmiri</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="114"/>
        <location filename="../languages.cpp" line="237"/>
        <source>Kurdish</source>
        <translation>Kurdish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="117"/>
        <source>Kirghiz</source>
        <translation>Kirghiz</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="118"/>
        <source>Latin</source>
        <translation>Latin</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="122"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="124"/>
        <location filename="../languages.cpp" line="238"/>
        <source>Lithuanian</source>
        <translation>Lithuanian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="126"/>
        <source>Latvian</source>
        <translation>Latvian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="127"/>
        <source>Malagasy</source>
        <translation>Malagasy</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="129"/>
        <source>Maori</source>
        <translation>Maori</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="130"/>
        <location filename="../languages.cpp" line="239"/>
        <source>Macedonian</source>
        <translation>Macedonian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="131"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="132"/>
        <source>Mongolian</source>
        <translation>Mongolian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="133"/>
        <source>Moldavian</source>
        <translation>Moldavian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="134"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="135"/>
        <source>Malay</source>
        <translation>Malay</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="136"/>
        <source>Maltese</source>
        <translation>Maltese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="137"/>
        <source>Burmese</source>
        <translation>Burmese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="138"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="141"/>
        <source>Nepali</source>
        <translation>Nepali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="143"/>
        <location filename="../languages.cpp" line="240"/>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="144"/>
        <location filename="../languages.cpp" line="145"/>
        <source>Norwegian</source>
        <translation>Norwegian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="149"/>
        <source>Occitan</source>
        <translation>Occitan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="152"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="156"/>
        <location filename="../languages.cpp" line="241"/>
        <source>Polish</source>
        <translation>Polish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="158"/>
        <source>Portuguese</source>
        <translation>Portuguese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="159"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="162"/>
        <location filename="../languages.cpp" line="244"/>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="163"/>
        <location filename="../languages.cpp" line="245"/>
        <location filename="../languages.cpp" line="277"/>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="164"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="165"/>
        <source>Sanskrit</source>
        <translation>Sanskrit</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="167"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="171"/>
        <location filename="../languages.cpp" line="246"/>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="172"/>
        <location filename="../languages.cpp" line="247"/>
        <source>Slovenian</source>
        <translation>Slovenian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="173"/>
        <source>Samoan</source>
        <translation>Samoan</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="174"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="175"/>
        <source>Somali</source>
        <translation>Somali</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="176"/>
        <source>Albanian</source>
        <translation>Albanian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="177"/>
        <location filename="../languages.cpp" line="248"/>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="180"/>
        <source>Sundanese</source>
        <translation>Sundanese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="181"/>
        <location filename="../languages.cpp" line="249"/>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="182"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="183"/>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="184"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="185"/>
        <source>Tajik</source>
        <translation>Tajik</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="186"/>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="187"/>
        <source>Tigrinya</source>
        <translation>Tigrinya</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="188"/>
        <source>Turkmen</source>
        <translation>Turkmen</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="189"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="191"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="192"/>
        <location filename="../languages.cpp" line="250"/>
        <location filename="../languages.cpp" line="273"/>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="193"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="194"/>
        <source>Tatar</source>
        <translation>Tatar</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="195"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="197"/>
        <source>Uighur</source>
        <translation>Uighur</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="198"/>
        <location filename="../languages.cpp" line="251"/>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="199"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="200"/>
        <source>Uzbek</source>
        <translation>Uzbek</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="202"/>
        <location filename="../languages.cpp" line="252"/>
        <source>Vietnamese</source>
        <translation>Vietnamese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="205"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="206"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="207"/>
        <source>Yiddish</source>
        <translation>Yiddish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="208"/>
        <source>Yoruba</source>
        <translation>Yoruba</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="209"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="210"/>
        <source>Chinese</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="211"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="242"/>
        <source>Portuguese - Brazil</source>
        <translation>Portuguese - Brazil</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="243"/>
        <source>Portuguese - Portugal</source>
        <translation>Portuguese - Portugal</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="253"/>
        <source>Simplified-Chinese</source>
        <translation>Simplified-Chinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="254"/>
        <source>Traditional Chinese</source>
        <translation>Traditional Chinese</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="263"/>
        <source>Unicode</source>
        <translation>Unicode</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="264"/>
        <source>UTF-8</source>
        <translation>UTF-8</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="265"/>
        <source>Western European Languages</source>
        <translation>Western European Languages</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="266"/>
        <source>Western European Languages with Euro</source>
        <translation>Western European Languages with Euro</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="267"/>
        <source>Slavic/Central European Languages</source>
        <translation>Slavic/Central European Languages</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="268"/>
        <source>Esperanto, Galician, Maltese, Turkish</source>
        <translation>Esperanto, Galician, Maltese, Turkish</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="269"/>
        <source>Old Baltic charset</source>
        <translation>Old Baltic charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="270"/>
        <source>Cyrillic</source>
        <translation>Cyrylica</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="272"/>
        <source>Modern Greek</source>
        <translation>Modern Greek</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="274"/>
        <source>Baltic</source>
        <translation>Baltic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="275"/>
        <source>Celtic</source>
        <translation>Celtic</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="276"/>
        <source>Hebrew charsets</source>
        <translation>Hebrew charsets</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="278"/>
        <source>Ukrainian, Belarusian</source>
        <translation>Ukrainian, Belarusian</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="279"/>
        <source>Simplified Chinese charset</source>
        <translation>Simplified Chinese charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="280"/>
        <source>Traditional Chinese charset</source>
        <translation>Traditional Chinese charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="281"/>
        <source>Japanese charsets</source>
        <translation>Japanese charsets</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="282"/>
        <source>Korean charset</source>
        <translation>Korean charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="283"/>
        <source>Thai charset</source>
        <translation>Thai charset</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="284"/>
        <source>Cyrillic Windows</source>
        <translation>Cyrillic Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="285"/>
        <source>Slavic/Central European Windows</source>
        <translation>Slavic/Central European Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="286"/>
        <source>Arabic Windows</source>
        <translation>Arabic Windows</translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="29"/>
        <source>Avestan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="31"/>
        <source>Akan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="33"/>
        <source>Aragonese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="36"/>
        <source>Avaric</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="40"/>
        <source>Belarusian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="44"/>
        <source>Bambara</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="48"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="50"/>
        <source>Chechen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="52"/>
        <source>Cree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="54"/>
        <source>Church</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="55"/>
        <source>Chuvash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="59"/>
        <source>Divehi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="60"/>
        <source>Dzongkha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="61"/>
        <source>Ewe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="69"/>
        <source>Fulah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="71"/>
        <source>Fijian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="76"/>
        <source>Gaelic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="80"/>
        <source>Manx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="84"/>
        <source>Hiri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="86"/>
        <source>Haitian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="89"/>
        <source>Herero</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="90"/>
        <source>Chamorro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="94"/>
        <source>Igbo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="95"/>
        <source>Sichuan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="96"/>
        <source>Inupiaq</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="97"/>
        <source>Ido</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="104"/>
        <source>Kongo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="105"/>
        <source>Kikuyu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="106"/>
        <source>Kuanyama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="109"/>
        <source>Khmer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="112"/>
        <source>Kanuri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="115"/>
        <source>Komi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="116"/>
        <source>Cornish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="119"/>
        <source>Luxembourgish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="120"/>
        <source>Ganda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="121"/>
        <source>Limburgan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="123"/>
        <source>Lao</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="125"/>
        <source>Luba-Katanga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="128"/>
        <source>Marshallese</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="139"/>
        <source>Bokmål</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="140"/>
        <location filename="../languages.cpp" line="146"/>
        <source>Ndebele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="142"/>
        <source>Ndonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="147"/>
        <source>Navajo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="148"/>
        <source>Chichewa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="150"/>
        <source>Ojibwa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="151"/>
        <source>Oromo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="153"/>
        <source>Ossetian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="154"/>
        <source>Panjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="155"/>
        <source>Pali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="157"/>
        <source>Pushto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="160"/>
        <source>Romansh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="161"/>
        <source>Rundi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="166"/>
        <source>Sardinian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="168"/>
        <source>Sami</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="169"/>
        <source>Sango</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="170"/>
        <source>Sinhala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="178"/>
        <source>Swati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="179"/>
        <source>Sotho</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="190"/>
        <source>Tswana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="196"/>
        <source>Tahitian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="201"/>
        <source>Venda</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="../languages.cpp" line="203"/>
        <source>Volapük</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="204"/>
        <source>Walloon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languages.cpp" line="287"/>
        <source>Modern Greek Windows</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LogWindow</name>
    <message>
        <location filename="../logwindow.cpp" line="112"/>
        <source>Choose a filename to save under</source>
        <translation>Wybierz plik do zapisania</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="120"/>
        <source>Confirm overwrite?</source>
        <translation>Zatwierdzić nadpisanie?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="121"/>
        <source>The file already exists.
Do you want to overwrite?</source>
        <translation>Plik już istnieje. 
Czy chcesz go nadpisać?</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="144"/>
        <source>Error saving file</source>
        <translation>Błąd zapisu pliku</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="145"/>
        <source>The log couldn&apos;t be saved</source>
        <translation>Log nie mógł zostać zapisany</translation>
    </message>
    <message>
        <location filename="../logwindow.cpp" line="113"/>
        <source>Logs</source>
        <translation>Logi</translation>
    </message>
</context>
<context>
    <name>LogWindowBase</name>
    <message>
        <location filename="../logwindowbase.ui" line="14"/>
        <source>Log Window</source>
        <translation>Okno logu</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="57"/>
        <location filename="../logwindowbase.ui" line="60"/>
        <source>Save</source>
        <translation>Zapisz</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="67"/>
        <location filename="../logwindowbase.ui" line="70"/>
        <source>Copy to clipboard</source>
        <translation>Kopiuj do schowka</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="77"/>
        <source>Close</source>
        <translation>Zamknij</translation>
    </message>
    <message>
        <location filename="../logwindowbase.ui" line="80"/>
        <source>&amp;Close</source>
        <translation>&amp;Zamknij</translation>
    </message>
</context>
<context>
    <name>Playlist</name>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Name</source>
        <translation>Nazwa</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="342"/>
        <source>Length</source>
        <translation>Długość</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="815"/>
        <source>Choose a file</source>
        <translation>Wybierz plik</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="835"/>
        <source>Choose a filename</source>
        <translation>Wybierz nazwę pliku</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="849"/>
        <source>Confirm overwrite?</source>
        <translation>Potwierdź nadpisanie?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1075"/>
        <source>Select one or more files to open</source>
        <translation>Wybierz jeden lub więcej plików do otwarcia</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1077"/>
        <source>Multimedia</source>
        <translation type="unfinished">Multimedia</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1139"/>
        <source>Choose a directory</source>
        <translation>Wybierz katalog</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="850"/>
        <source>The file %1 already exists.
Do you want to overwrite?</source>
        <translation>Plik %1 istnieje
Nadpisać go?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1364"/>
        <source>Edit name</source>
        <translation>Edytuj nazwę</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1365"/>
        <source>Type the name that will be displayed in the playlist for this file:</source>
        <translation>Wpisz nową nazwę dla tego pliku, która będzie wyświetlana w liście 
odtwarzania :</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="347"/>
        <source>&amp;Play</source>
        <translation>&amp;Odtwarzaj</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="383"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edytuj</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="393"/>
        <source>ROSA Media Player - Playlist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="817"/>
        <location filename="../playlist.cpp" line="837"/>
        <source>Playlists</source>
        <translation>Listy odtwarzania</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="1078"/>
        <source>All files</source>
        <translation>Wszystkie pliki</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="344"/>
        <source>&amp;Load</source>
        <translation>&amp;Wczytaj</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="345"/>
        <source>&amp;Save</source>
        <translation>&amp;Zapisz</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="349"/>
        <source>&amp;Next</source>
        <translation>&amp;Następny</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="350"/>
        <source>Pre&amp;vious</source>
        <translation>Pop&amp;rzedni</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="365"/>
        <source>Move &amp;up</source>
        <translation>Przesuń w &amp;górę</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="366"/>
        <source>Move &amp;down</source>
        <translation>Przesuń w &amp;dół</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="368"/>
        <source>&amp;Repeat</source>
        <translation>&amp;Powtarzaj</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="369"/>
        <source>S&amp;huffle</source>
        <translation>T&amp;asuj</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="374"/>
        <source>Add &amp;current file</source>
        <translation>Dodaj &amp;bieżący plik</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="375"/>
        <source>Add &amp;file(s)</source>
        <translation>Dodaj &amp;plik(i)</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="376"/>
        <source>Add &amp;directory</source>
        <translation>Dodaj &amp;katalog</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="379"/>
        <source>Remove &amp;selected</source>
        <translation>Usuń &amp;zaznaczony</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="380"/>
        <source>Remove &amp;all</source>
        <translation>Usuń &amp;wszystko</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="387"/>
        <source>Add...</source>
        <translation>Dodaj...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="389"/>
        <source>Remove...</source>
        <translation>Usuń...</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="879"/>
        <source>Playlist modified</source>
        <translation>Lista odtwarzania zmodyfikowana</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="880"/>
        <source>There are unsaved changes, do you want to save the playlist?</source>
        <translation>Tu są niezapisane zmiany, czy chcesz zapisać listę odtwarzania?</translation>
    </message>
    <message>
        <location filename="../playlist.cpp" line="371"/>
        <source>Preferences</source>
        <translation>Preferencje</translation>
    </message>
</context>
<context>
    <name>PlaylistPreferences</name>
    <message>
        <location filename="../playlistpreferences.ui" line="13"/>
        <source>Playlist - Preferences</source>
        <translation>Lista odtwarzania - Preferencje</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="32"/>
        <source>Check this option if you want that adding a directory will also add the files in subdirectories recursively. Otherwise only the files in the selected directory will be added.</source>
        <translation>Zaznacz tę opcję jeśli chcesz, żeby do dodawanych katalogów zostały także dodane rekursywnie pliki w podkatalogach. W innym wypadku zostaną dodane tylko pliki w zaznaczonych katalogach .</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="32"/>
        <source>&amp;Add files in directories recursively</source>
        <translation>&amp;Dodaj rekursywnie pliki i katalogi</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.cpp" line="37"/>
        <source>Check this option to inquire the files to be added to the playlist for some info. That allows to show the title name (if available) and length of the files. Otherwise this info won&apos;t be available until the file is actually played. Beware: this option can be slow, specially if you add many files.</source>
        <translation>Zaznacz tę opcję jeśli chcesz zasięgnąć informacji o plikach dodanych do listy odtwarzania, uwzględniając nazwę (jeśli dostępna) i długość plików. W przeciwnym razie informacje te nie będą dostępne dopóki plik jest odtwarzany. Uwaga: opcja ta jest bardzo wolna, zwłaszcza, gdy dodasz dużo plików.</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="39"/>
        <source>Automatically get &amp;info about files added</source>
        <translation>Automatycznie pobierz &amp;informację o dodanych plikach</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="46"/>
        <source>&amp;Save copy of playlist on exit</source>
        <translation>&amp;Zapisz przy wyjściu kopię listy odtwarzania</translation>
    </message>
    <message>
        <location filename="../playlistpreferences.ui" line="25"/>
        <source>&amp;Play files from start</source>
        <translation>&amp;Odtwarzaj pliki od początku</translation>
    </message>
</context>
<context>
    <name>PrefAssociations</name>
    <message>
        <location filename="../prefassociations.cpp" line="186"/>
        <source>Warning</source>
        <translation>Uwaga</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="187"/>
        <source>Not all files could be associated. Please check your security permissions and retry.</source>
        <translation>Nie wszystkie pliki mogą zostać skojarzone. Sprawdź swoje uprawnienia dostępu do systemu plików i spróbuj ponownie.</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="196"/>
        <source>File Types</source>
        <translation>Rodzaj plików</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="216"/>
        <source>Select all</source>
        <translation>Wybierz wszystko</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="217"/>
        <source>Check all file types in the list</source>
        <translation>Zaznacz wszystkie rodzaje plików z listy</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="220"/>
        <source>Uncheck all file types in the list</source>
        <translation>Odznacz wszystkie rodzaje plików z listy</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="222"/>
        <source>List of file types</source>
        <translation>Lista rodzaju plików</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="223"/>
        <source>Check the media file extensions you would like ROSA Media Player to handle. When you click Apply, the checked files will be associated with ROSA Media Player. If you uncheck a media type, the file association will be restored.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="27"/>
        <source>File types</source>
        <translation>Rodzaj plików</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="39"/>
        <source>Media files handled by ROSA Media Player:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="92"/>
        <source>Select All</source>
        <translation>Wybierz wszystko</translation>
    </message>
    <message>
        <location filename="../prefassociations.ui" line="99"/>
        <source>Select None</source>
        <translation>Nie wybieraj nic</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="219"/>
        <source>Select none</source>
        <translation>Nie wybieraj nic</translation>
    </message>
    <message>
        <location filename="../prefassociations.cpp" line="227"/>
        <source> &lt;b&gt;Note:&lt;/b&gt; (Restoration doesn&apos;t work on Windows Vista).</source>
        <translation> &lt;br&gt;Notka:&lt;/b&gt; (Przywrócenie nie działa w Windows Vista).</translation>
    </message>
</context>
<context>
    <name>PrefDrives</name>
    <message>
        <source>Drives</source>
        <translation type="obsolete">Napędy</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">ikona</translation>
    </message>
    <message>
        <source>CD device</source>
        <translation type="obsolete">Napęd CD</translation>
    </message>
    <message>
        <source>Choose your CDROM device. It will be used to play VCDs and Audio CDs.</source>
        <translation type="obsolete">Wybierz napęd CD. Będzie on użyty do odtwarzania płyt VCD oraz CD.</translation>
    </message>
    <message>
        <source>DVD device</source>
        <translation type="obsolete">Napęd DVD</translation>
    </message>
    <message>
        <source>Choose your DVD device. It will be used to play DVDs.</source>
        <translation type="obsolete">Wybierz napęd DVD. Będzie on użyty do odtwarzania DVD.</translation>
    </message>
    <message>
        <source>Select your &amp;CD device:</source>
        <translation type="obsolete">Wybierz napęd &amp;CD:</translation>
    </message>
    <message>
        <source>Select your &amp;DVD device:</source>
        <translation type="obsolete">Wybierz napęd &amp;DVD:</translation>
    </message>
</context>
<context>
    <name>PrefGeneral</name>
    <message>
        <location filename="../prefgeneral.cpp" line="76"/>
        <source>General</source>
        <translation>Główne</translation>
    </message>
    <message>
        <source>&amp;General</source>
        <translation type="obsolete">&amp;Główne</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="38"/>
        <location filename="../prefgeneral.cpp" line="318"/>
        <source>Media settings</source>
        <translation>Ustawienia mediów</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="65"/>
        <source>&amp;Disable screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="94"/>
        <source>Cha&amp;nnels by default:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="125"/>
        <location filename="../prefgeneral.cpp" line="375"/>
        <source>Main window</source>
        <translation type="unfinished">Główne okno</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="133"/>
        <source>A&amp;utoresize:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="193"/>
        <location filename="../prefgeneral.cpp" line="385"/>
        <source>Instances</source>
        <translation type="unfinished">Przypadki</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="202"/>
        <source>&amp;Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="221"/>
        <source>&amp;Volume normalization by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">Automatyczna &amp;zmiana rozmiaru:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="150"/>
        <source>Never</source>
        <translation type="unfinished">Nigdy</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="155"/>
        <source>Whenever it&apos;s needed</source>
        <translation type="unfinished">Jeżeli jest taka potrzeba</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="160"/>
        <source>Only after loading a new video</source>
        <translation type="unfinished">Tylko po załadowaniu nowego filmu</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="183"/>
        <source>R&amp;emember position and size</source>
        <translation type="unfinished">Z&amp;apamietaj pozycję i rozmiar</translation>
    </message>
    <message>
        <source>Preferred audio and subtitles</source>
        <translation type="obsolete">Preferowana ścieżka dźwiękowa i napisy</translation>
    </message>
    <message>
        <source>Video</source>
        <translation type="obsolete">Wideo</translation>
    </message>
    <message>
        <source>Start videos in fullscreen</source>
        <translation type="obsolete">Start odtwarzania na pełnym ekranie</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="354"/>
        <source>Disable screensaver</source>
        <translation>Zablokuj wygaszacz ekranu</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="212"/>
        <location filename="../prefgeneral.cpp" line="392"/>
        <source>Audio</source>
        <translation type="unfinished">Audio</translation>
    </message>
    <message>
        <source>AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">AC3/DTS pass-through S/PDIF</translation>
    </message>
    <message>
        <source>Select the mplayer executable</source>
        <translation type="obsolete">Wybierz plik wykonywalny mplayera</translation>
    </message>
    <message>
        <source>Executables</source>
        <translation type="obsolete">Wykonywalne</translation>
    </message>
    <message>
        <source>All files</source>
        <translation type="obsolete">Wszystkie pliki</translation>
    </message>
    <message>
        <source>Select a directory</source>
        <translation type="obsolete">Wybierz katalog</translation>
    </message>
    <message>
        <source>MPlayer executable</source>
        <translation type="obsolete">Plik wykonywalny MPlayera</translation>
    </message>
    <message>
        <source>Screenshots folder</source>
        <translation type="obsolete">Folder dla zrzutów ekranu</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="334"/>
        <source>Automatically add files to playlist</source>
        <translation type="unfinished">Automatycznie dodaj pliki do listy odtwarzania</translation>
    </message>
    <message>
        <source>Video output driver</source>
        <translation type="obsolete">Strerownik wyjściowy wideo</translation>
    </message>
    <message>
        <source>Audio output driver</source>
        <translation type="obsolete">Sterownik wyjściowy audio</translation>
    </message>
    <message>
        <source>Select the audio output driver.</source>
        <translation type="obsolete">Wybierz sterownik wyjściowy audio.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="320"/>
        <source>Remember settings</source>
        <translation>Zapamiętaj ustawienia</translation>
    </message>
    <message>
        <source>Software video equalizer</source>
        <translation type="obsolete">Programowy korektor wideo</translation>
    </message>
    <message>
        <source>You can check this option if video equalizer is not supported by your graphic card or the selected video output driver.&lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; this option can be incompatible with some video output drivers.</source>
        <translation type="obsolete">Zaznacz tę opcję jeśli korektor wideo nie jest obsługiwany przez twoją kartę graficzną lub wybrany sterownik wyjściowy wideo.&lt;br&gt;&lt;b&gt;Notka:&lt;/b&gt;ta opcja nie jest kompatybilna z niektórymi sterownikami wideo.</translation>
    </message>
    <message>
        <source>Postprocessing quality</source>
        <translation type="obsolete">Jakość przetwarzania końcowego</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="321"/>
        <source>Usually ROSA Media Player will remember the settings for each file you play (audio track selected, volume, filters...). Disable this option if you don&apos;t like this feature.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="335"/>
        <source>If this option is enabled, every time a file is opened, ROSA Media Player will first clear the playlist and then add the file to it. In case of DVDs, CDs and VCDs, all titles in the disc will be added to the playlist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Dynamically changes the level of postprocessing depending on the available spare CPU time. The number you specify will be the maximum level used. Usually you can use some big number.</source>
        <translation type="obsolete">Dynamiczne zmiany przetwarzania końcowego (postprocessing) zależne są od dostępnej wolnej mocy obliczeniowej procesora (CPU). Poziom który ustawisz będzie maksymalny w użyciu. Zwykle można ustawić trochę wyższą wartość.</translation>
    </message>
    <message>
        <source>If this option is checked, all videos will start to play in fullscreen mode.</source>
        <translation type="obsolete">Gdy ta opcja jest zaznaczona wszystkie pliki wideo będą odtwarzane w trybie pełnego ekranu.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="348"/>
        <source>When this option is checked, ROSA Media Player will try to prevent the screensaver to be shown when playing a video file. The screensaver will be allowed to be shown if playing an audio file or in pause mode. This option only works if the ROSA Media Player window is in the foreground.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Software volume control</source>
        <translation type="obsolete">Programowa kontrola głośności</translation>
    </message>
    <message>
        <source>Check this option to use the software mixer, instead of using the sound card mixer.</source>
        <translation type="obsolete">Zaznacz tę opcję aby użyć programowego miksera, zamiast miksera karty muzycznej.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="51"/>
        <source>&amp;Remember settings for all files (audio track, subtitles...)</source>
        <translation>&amp;Zapamiętaj ustawienia dla wszystkich plików (ścieżki audio, napisy...)</translation>
    </message>
    <message>
        <source>&amp;Quality:</source>
        <translation type="obsolete">&amp;Jakość:</translation>
    </message>
    <message>
        <source>Start videos in &amp;fullscreen</source>
        <translation type="obsolete">Start odtwarzania na &amp;pełnym ekranie</translation>
    </message>
    <message>
        <source>Disable &amp;screensaver</source>
        <translation type="obsolete">Zablokuj &amp;wygaszacz ekranu</translation>
    </message>
    <message>
        <source>Use s&amp;oftware volume control</source>
        <translation type="obsolete">Użyj &amp;programowej regulacji głośności</translation>
    </message>
    <message>
        <source>Ma&amp;x. Amplification:</source>
        <translation type="obsolete">Ma&amp;ksymalne wzmocnienie:</translation>
    </message>
    <message>
        <source>&amp;AC3/DTS pass-through S/PDIF</source>
        <translation type="obsolete">&amp;AC3/DTS pass-through S/PDIF</translation>
    </message>
    <message>
        <source>Direct rendering</source>
        <translation type="obsolete">Bezpośredni rendering</translation>
    </message>
    <message>
        <source>Double buffering</source>
        <translation type="obsolete">Podwójne buforowanie</translation>
    </message>
    <message>
        <source>D&amp;irect rendering</source>
        <translation type="obsolete">B&amp;ezpośredni rendering</translation>
    </message>
    <message>
        <source>Dou&amp;ble buffering</source>
        <translation type="obsolete">P&amp;odwójne buforowanie</translation>
    </message>
    <message>
        <source>Double buffering fixes flicker by storing two frames in memory, and displaying one while decoding another. If disabled it can affect OSD negatively, but often removes OSD flickering.</source>
        <translation type="obsolete">Podwójne buforowanie redukuje migotanie przez przechowywanie dwóch klatek w pamięci, i wyświetlanie jednej podczas dekodowania drugiej. Jeśli jest to wyłączone może oddziaływać negatywnie na OSD, ale często usuwa jego migotanie.</translation>
    </message>
    <message>
        <source>&amp;Enable postprocessing by default</source>
        <translation type="obsolete">&amp;Włącz domyślnie przetwarzanie końcowe</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Domyślna &amp;normalizacja głośności</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="325"/>
        <source>Close when finished</source>
        <translation>Zamknij program gdy zakończy odtwarzanie</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="326"/>
        <source>If this option is checked, the main window will be automatically closed when the current file/playlist finishes.</source>
        <translation>Jeśli ta opcja jest zaznaczona, okno główne automatycznie zamknie się po zakończeniu bieżącego pliku/listy odtwarzania.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="92"/>
        <source>2 (Stereo)</source>
        <translation>2 (Stereo)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="93"/>
        <source>4 (4.0 Surround)</source>
        <translation>4 (4.0 Surround)</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="94"/>
        <source>6 (5.1 Surround)</source>
        <translation>6 (5.1 Surround)</translation>
    </message>
    <message>
        <source>C&amp;hannels by default:</source>
        <translation type="obsolete">&amp;Standardowo kanały:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="79"/>
        <source>&amp;Pause when minimized</source>
        <translation>&amp;Pauza gdy minimalizujesz</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="329"/>
        <source>Pause when minimized</source>
        <translation>Pauza gdy minimalizujesz</translation>
    </message>
    <message>
        <source>Enable postprocessing by default</source>
        <translation type="obsolete">Włącz domyślne przetwarzanie końcowe</translation>
    </message>
    <message>
        <source>Max. Amplification</source>
        <translation type="obsolete">Maksymalne wzmocnienie</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="394"/>
        <source>Volume normalization by default</source>
        <translation type="unfinished">Domyślna normalizacja głośności</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="395"/>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="unfinished">Zwiększ głośność bez zniekształcenia dźwięku.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="364"/>
        <source>Channels by default</source>
        <translation>Domyślnie kanały</translation>
    </message>
    <message>
        <source>Sets the maximum amplification level in percent (default: 110). A value of 200 will allow you to adjust the volume up to a maximum of double the current level. With values below 100 the initial volume (which is 100%) will be above the maximum, which e.g. the OSD cannot display correctly.</source>
        <translation type="obsolete">Ustaw maksymalny poziom wzmocnienia w procentach (domyślnie: 110). Wartość 200 pozwoli wyregulować głośność do maksymalnie podwójnego bieżącego poziomu. Z wartościami poniżej 100 początkowa głośność (która wynosi 100%) będzie powyżej maksimum, której np. OSD nie wyświetli poprawnie. </translation>
    </message>
    <message>
        <source>Postprocessing will be used by default on new opened files.</source>
        <translation type="obsolete">Przetwarzanie końcowe będzie użyte domyślnie dla nowo otwartych plików.</translation>
    </message>
    <message>
        <source>High speed &amp;playback without altering pitch</source>
        <translation type="obsolete">Wysoka prędkość &amp;odtwarzania bez zmieniania skoku</translation>
    </message>
    <message>
        <source>High speed playback without altering pitch</source>
        <translation type="obsolete">Wysoka prędkość odtwarzania bez zmieniania skoku</translation>
    </message>
    <message>
        <source>Allows to change the playback speed without altering pitch. Requires at least MPlayer dev-SVN-r24924.</source>
        <translation type="obsolete">Pozwól na zmianę prędkości odtwarzania bez zmieniania skoku. Wymagany MPlayer dev-SVN-r24924.</translation>
    </message>
    <message>
        <source>&amp;Video</source>
        <translation type="obsolete">&amp;Wideo</translation>
    </message>
    <message>
        <source>Use s&amp;oftware video equalizer</source>
        <translation type="obsolete">Użyj &amp;programowego korektora wideo</translation>
    </message>
    <message>
        <source>A&amp;udio</source>
        <translation type="obsolete">A&amp;udio</translation>
    </message>
    <message>
        <source>Volume</source>
        <translation type="obsolete">Głośność</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nic</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">Lowpass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normalny)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (podwójna szybkość klatek)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Liniowy mieszany</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Kerndeint</translation>
    </message>
    <message>
        <source>Deinterlace by default</source>
        <translation type="obsolete">Domyślne usuwanie przeplotu</translation>
    </message>
    <message>
        <source>Select the deinterlace filter that you want to be used for new videos opened.</source>
        <translation type="obsolete">Wybierz filtr usuwania przeplotu dla nowo otwieranych plików wideo.</translation>
    </message>
    <message>
        <source>Remember time position</source>
        <translation type="obsolete">Zapamiętaj pozycję czasu</translation>
    </message>
    <message>
        <source>Remember &amp;time position</source>
        <translation type="obsolete">Zapamiętaj &amp;pozycję czasu</translation>
    </message>
    <message>
        <source>Enable the audio equalizer</source>
        <translation type="obsolete">Włącz korektor audio</translation>
    </message>
    <message>
        <source>Check this option if you want to use the audio equalizer.</source>
        <translation type="obsolete">Zaznacz tę opcję jeśli chcesz użyć korektora audio.</translation>
    </message>
    <message>
        <source>&amp;Enable the audio equalizer</source>
        <translation type="obsolete">&amp;Włącz korektor audio</translation>
    </message>
    <message>
        <source>Draw video using slices</source>
        <translation type="obsolete">Rysuj obraz wideo używając segmentów</translation>
    </message>
    <message>
        <source>Enable/disable drawing video by 16-pixel height slices/bands. If disabled, the whole frame is drawn in a single run. May be faster or slower, depending on video card and available cache. It has effect only with libmpeg2 and libavcodec codecs.</source>
        <translation type="obsolete">Włącz/wyłącz rysowanie obrazu wideo przez 16 pikselową wysokość segmentów/pasm. Jeśli wyłączone, cała ramka jest rysowana w pojedyńczym przebiegu. Może to być szybsze lub wolniejsze w zależności od karty wideo i dostępnej pamięci podręcznej. Ma to efekt tylko z kodekami libmpeg2 i libavcodecs.</translation>
    </message>
    <message>
        <source>Dra&amp;w video using slices</source>
        <translation type="obsolete">&amp;Rysuj obraz wideo używając segmentów</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="58"/>
        <source>&amp;Close when finished playback</source>
        <translation>&amp;Zamknij kiedy skończył odtwarzanie</translation>
    </message>
    <message>
        <source>fast</source>
        <translation type="obsolete">szybko</translation>
    </message>
    <message>
        <source>slow</source>
        <translation type="obsolete">powoli</translation>
    </message>
    <message>
        <source>fast - ATI cards</source>
        <translation type="obsolete">szybko - karty ATI</translation>
    </message>
    <message>
        <source>User defined...</source>
        <translation type="obsolete">Określone przez użytkownika...</translation>
    </message>
    <message>
        <source>Default zoom</source>
        <translation type="obsolete">Domyślny zoom</translation>
    </message>
    <message>
        <source>This option sets the default zoom which will be used for new videos.</source>
        <translation type="obsolete">Opcja ta ustawia domyślnie zoom dla nowych plików wideo.</translation>
    </message>
    <message>
        <source>Default &amp;zoom:</source>
        <translation type="obsolete">Domyślny &amp;zoom:</translation>
    </message>
    <message>
        <source>Select the video output driver. %1 provides the best performance.</source>
        <translation type="obsolete">Wybierz sterownik wyjściowy wideo. %1 dają najlepszą wydajność.</translation>
    </message>
    <message>
        <source>%1 is the recommended one. Try to avoid %2 and %3, they are slow and can have an impact on performance.</source>
        <translation type="obsolete">%1 jest rekomendowany. Spróbuj ominąć %2 i %3, są one wolne i mają wpływ na wydajność.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="330"/>
        <source>If this option is enabled, the file will be paused when the main window is hidden. When the window is restored, playback will be resumed.</source>
        <translation>Jeśli opcja ta jest włączona i okno główne jest ukryte, plik zostanie zapauzowany. Gdy okno główne zostanie przywrócone, nastąpi wznowienie odtwarzania.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="377"/>
        <source>Autoresize</source>
        <translation type="unfinished">Automatyczna zmiana rozmiaru</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="378"/>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="unfinished">Okno główne może być zmieniane automatycznie. Wybierz opcję, którą preferujesz.</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="381"/>
        <source>Remember position and size</source>
        <translation type="unfinished">Zapamiętaj pozycję i rozmiar</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="382"/>
        <source>If you check this option, the position and size of the main window will be saved and restored when you run ROSA Media Player again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="388"/>
        <source>Use only one running instance of ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="389"/>
        <source>Check this option if you want to use an already running instance of ROSA Media Player when opening other files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="355"/>
        <source>Check this option to disable the screensaver while playing.&lt;br&gt;The screensaver will enabled again when play finishes.</source>
        <translation>Zaznacz tę opcję aby wyłączyć wygaszacz ekranu podczas odtwarzania.&lt;br&gt;Wygaszacz ekranu będzie uruchomiony ponownie po zakończonym odtwarzaniu.</translation>
    </message>
    <message>
        <source>Ou&amp;tput driver:</source>
        <translation type="obsolete">&amp;Sterownik wyjściowy:</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="365"/>
        <source>Requests the number of playback channels. MPlayer asks the decoder to decode the audio into as many channels as specified. Then it is up to the decoder to fulfill the requirement. This is usually only important when playing videos with AC3 audio (like DVDs). In that case liba52 does the decoding by default and correctly downmixes the audio into the requested number of channels. &lt;b&gt;Note&lt;/b&gt;: This option is honored by codecs (AC3 only), filters (surround) and audio output drivers (OSS at least).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="341"/>
        <source>Switch screensaver off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="342"/>
        <source>This option switches the screensaver off just before starting to play a file and switches it on when playback finishes. If this option is enabled, the screensaver won&apos;t appear even if playing audio files or when a file is paused.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="347"/>
        <source>Avoid screensaver</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="360"/>
        <source>Audio/video auto synchronization</source>
        <translation type="unfinished">Automatyczna synchronizacja Audio/Wideo</translation>
    </message>
    <message>
        <location filename="../prefgeneral.cpp" line="361"/>
        <source>Gradually adjusts the A/V sync based on audio delay measurements.</source>
        <translation type="unfinished">Stopniowa regulacja synchronizacji A/V bazująca na pomiarach opóźnień.</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Lista odtwarzania</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="72"/>
        <source>&amp;Automatically add files to playlist</source>
        <translation type="unfinished">&amp;Automatycznie dodaj pliki do listy odtwarzania</translation>
    </message>
    <message>
        <source>Synchronization</source>
        <translation type="obsolete">Synchronizacja</translation>
    </message>
    <message>
        <location filename="../prefgeneral.ui" line="44"/>
        <source>Audio/video auto &amp;synchronization</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefInput</name>
    <message>
        <source>Keyboard and mouse</source>
        <translation type="obsolete">Klawiatura i myszka</translation>
    </message>
    <message>
        <source>&amp;Keyboard</source>
        <translation type="obsolete">&amp;Klawiatura</translation>
    </message>
    <message>
        <source>icon</source>
        <translation type="obsolete">ikona</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or start typing over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Tutaj możesz zmienić każdy klawisz skrótu. Aby to zrobić kliknij dwa razy w polu klawisza skrótu i przyporządkuj mu klawisz klawiatury. Dodatkowo możesz także zapisać listę, aby podzielić się nią z innymi lub wykorzystać na innym komputerze.</translation>
    </message>
    <message>
        <source>&amp;Mouse</source>
        <translation type="obsolete">&amp;Myszka</translation>
    </message>
    <message>
        <source>Button functions:</source>
        <translation type="obsolete">Funkcje przycisku:</translation>
    </message>
    <message>
        <source>Media seeking</source>
        <translation type="obsolete">Pasek postępu odtwarzania</translation>
    </message>
    <message>
        <source>Volume control</source>
        <translation type="obsolete">Kontrola głośności</translation>
    </message>
    <message>
        <source>Zoom video</source>
        <translation type="obsolete">Zoom wideo</translation>
    </message>
    <message>
        <source>None</source>
        <translation type="obsolete">Nic</translation>
    </message>
    <message>
        <source>Here you can change any key shortcut. To do it double click or press enter over a shortcut cell. Optionally you can also save the list to share it with other people or load it in another computer.</source>
        <translation type="obsolete">Tutaj możesz zmienić każdy klawisz skrótu. Aby to zrobić kliknij dwa razy w polu klawisza skrótu i przyporządkuj mu klawisz klawiatury. Dodatkowo możesz także zapisać listę aby podzielić się nią z innymi lub wykorzystać na innym komputerze.</translation>
    </message>
    <message>
        <source>&amp;Left click</source>
        <translation type="obsolete">&amp;Lewy przycisk</translation>
    </message>
    <message>
        <source>&amp;Double click</source>
        <translation type="obsolete">&amp;Dwuklik lewego przycisku</translation>
    </message>
    <message>
        <source>&amp;Wheel function:</source>
        <translation type="obsolete">&amp;Funkcje kółka:</translation>
    </message>
    <message>
        <source>Shortcut editor</source>
        <translation type="obsolete">Edytor skrótów klawiszowych</translation>
    </message>
    <message>
        <source>This table allows you to change the key shortcuts of most available actions. Double click or press enter on a item, or press the &lt;b&gt;Change shortcut&lt;/b&gt; button to enter in the &lt;i&gt;Modify shortcut&lt;/i&gt; dialog. There are two ways to change a shortcut: if the &lt;b&gt;Capture&lt;/b&gt; button is on then just press the new key or combination of keys that you want to assign for the action (unfortunately this doesn&apos;t work for all keys). If the &lt;b&gt;Capture&lt;/b&gt; button is off then you could enter the full name of the key.</source>
        <translation type="obsolete">Tabela ta pozwala zmienić klawisz skrótu dla każdej dostępnej funkcji. Kliknij dwa razu lub wciśnij enter na pozycję, lub wybierz &lt;b&gt;Zmień klawisz skrótu&lt;/b&gt; w dialogu &lt;i&gt;Modyfikuj klawisz skrótu&lt;/i&gt;. Istnieją dwie metody zmiany klawisza skrótu: przez funkcję &lt;b&gt;Przechwycenie&lt;/b&gt; po prostu naciśnij nowy klawisz lub ich kombinację, której chcesz przypisać odpowiednią funkcję (niestety nie działa to z wszystkimi klawiszami). Jeśli przycisk &lt;b&gt;Przechwycenie&lt;/b&gt; jest wyłączony wtedy możesz wpisać pełną nazwę klawisza.</translation>
    </message>
    <message>
        <source>Left click</source>
        <translation type="obsolete">Lewy przycisk</translation>
    </message>
    <message>
        <source>Select the action for left click on the mouse.</source>
        <translation type="obsolete">Wybierz funkcję dla lewego przycisku myszki.</translation>
    </message>
    <message>
        <source>Double click</source>
        <translation type="obsolete">Dwuklik lewego przycisku</translation>
    </message>
    <message>
        <source>Select the action for double click on the mouse.</source>
        <translation type="obsolete">Wybierz funkcję dla dwukliku lewego przycisku.</translation>
    </message>
    <message>
        <source>Wheel function</source>
        <translation type="obsolete">Funkcje kółka</translation>
    </message>
    <message>
        <source>Select the action for the mouse wheel.</source>
        <translation type="obsolete">Wybierz funkcję dla kółka myszki.</translation>
    </message>
    <message>
        <source>Play</source>
        <translation type="obsolete">Odtwarzaj</translation>
    </message>
    <message>
        <source>Pause</source>
        <translation type="obsolete">Pauza</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation type="obsolete">Stop</translation>
    </message>
    <message>
        <source>Fullscreen</source>
        <translation type="obsolete">Pełny ekran</translation>
    </message>
    <message>
        <source>Compact</source>
        <translation type="obsolete">Ukryj menu i przyciski</translation>
    </message>
    <message>
        <source>Screenshot</source>
        <translation type="obsolete">Zrzut ekranu</translation>
    </message>
    <message>
        <source>Mute</source>
        <translation type="obsolete">Wycisz</translation>
    </message>
    <message>
        <source>Frame counter</source>
        <translation type="obsolete">Licznik klatek</translation>
    </message>
    <message>
        <source>Reset zoom</source>
        <translation type="obsolete">Resetuj zoom</translation>
    </message>
    <message>
        <source>Exit fullscreen</source>
        <translation type="obsolete">Wyjdź z pełnego ekranu</translation>
    </message>
    <message>
        <source>Double size</source>
        <translation type="obsolete">Podwójny rozmiar</translation>
    </message>
    <message>
        <source>Play / Pause</source>
        <translation type="obsolete">Odtwarzaj / Pauza</translation>
    </message>
    <message>
        <source>Pause / Frame step</source>
        <translation type="obsolete">Pauza / Krok</translation>
    </message>
    <message>
        <source>Playlist</source>
        <translation type="obsolete">Lista odtwarzania</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="obsolete">Preferencje</translation>
    </message>
    <message>
        <source>No function</source>
        <translation type="obsolete">Bez funkcji</translation>
    </message>
    <message>
        <source>Change speed</source>
        <translation type="obsolete">Zmień prędkość</translation>
    </message>
    <message>
        <source>Normal speed</source>
        <translation type="obsolete">Normalna prędkość</translation>
    </message>
    <message>
        <source>Keyboard</source>
        <translation type="obsolete">Klawiatura</translation>
    </message>
    <message>
        <source>Mouse</source>
        <translation type="obsolete">Myszka</translation>
    </message>
    <message>
        <source>Middle click</source>
        <translation type="obsolete">Środkowy przycisk</translation>
    </message>
    <message>
        <source>Select the action for middle click on the mouse.</source>
        <translation type="obsolete">Wybierz funkcję dla środkowego przycisku myszki.</translation>
    </message>
    <message>
        <source>M&amp;iddle click</source>
        <translation type="obsolete">&amp;Środkowy przycisk</translation>
    </message>
    <message>
        <source>X Button &amp;1</source>
        <translation type="obsolete">X Button &amp;1</translation>
    </message>
    <message>
        <source>X Button &amp;2</source>
        <translation type="obsolete">X Button &amp;2</translation>
    </message>
    <message>
        <source>Go backward (short)</source>
        <translation type="obsolete">Do tyłu (mało)</translation>
    </message>
    <message>
        <source>Go backward (medium)</source>
        <translation type="obsolete">Do tyłu (średnio)</translation>
    </message>
    <message>
        <source>Go backward (long)</source>
        <translation type="obsolete">Do tyłu (dużo)</translation>
    </message>
    <message>
        <source>Go forward (short)</source>
        <translation type="obsolete">Do przodu (mało)</translation>
    </message>
    <message>
        <source>Go forward (medium)</source>
        <translation type="obsolete">Do przodu (średnio)</translation>
    </message>
    <message>
        <source>Go forward (long)</source>
        <translation type="obsolete">Do przodu (dużo)</translation>
    </message>
    <message>
        <source>OSD - Next level</source>
        <translation type="obsolete">OSD-następny poziom</translation>
    </message>
    <message>
        <source>Show context menu</source>
        <translation type="obsolete">Pokaż menu kontekstowe</translation>
    </message>
    <message>
        <source>&amp;Right click</source>
        <translation type="obsolete">&amp;Prawy przycisk</translation>
    </message>
    <message>
        <source>Increase volume</source>
        <translation type="obsolete">Zwiększ głośność</translation>
    </message>
    <message>
        <source>Decrease volume</source>
        <translation type="obsolete">Zmniejsz głośność</translation>
    </message>
    <message>
        <source>X Button 1</source>
        <translation type="obsolete">Przycisk X 1</translation>
    </message>
    <message>
        <source>Select the action for the X button 1.</source>
        <translation type="obsolete">Wybierz funkcję dla przycisku X 1.</translation>
    </message>
    <message>
        <source>X Button 2</source>
        <translation type="obsolete">Przycisk X 2</translation>
    </message>
    <message>
        <source>Select the action for the X button 2.</source>
        <translation type="obsolete">Wybierz funkcję dla przycisku X 2.</translation>
    </message>
    <message>
        <source>Show video equalizer</source>
        <translation type="obsolete">Pokaż korektor wideo</translation>
    </message>
    <message>
        <source>Show audio equalizer</source>
        <translation type="obsolete">Pokaż korektor audio</translation>
    </message>
</context>
<context>
    <name>PrefInterface</name>
    <message>
        <source>Interface</source>
        <translation type="obsolete">Interfejs</translation>
    </message>
    <message>
        <source>Volume normalization by default</source>
        <translation type="obsolete">Domyślna normalizacja głośności</translation>
    </message>
    <message>
        <source>Maximizes the volume without distorting the sound.</source>
        <translation type="obsolete">Zwiększ głośność bez zniekształcenia dźwięku.</translation>
    </message>
    <message>
        <source>Default subtitle encoding</source>
        <translation type="obsolete">Domyślne kodowanie napisów</translation>
    </message>
    <message>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="obsolete">Wybierz kodowanie, które zostanie użyte jako domyślne dla plików napisów.</translation>
    </message>
    <message>
        <source>Autoload</source>
        <translation type="obsolete">Autoładowanie</translation>
    </message>
    <message>
        <source>Select the subtitle autoload method.</source>
        <translation type="obsolete">Wybierz napisy metodą autoładowania.</translation>
    </message>
    <message>
        <source>&lt;Autodetect&gt;</source>
        <translation type="obsolete">&lt;Autodetekcja&gt;</translation>
    </message>
    <message>
        <source>Default</source>
        <translation type="obsolete">Domyślne</translation>
    </message>
    <message>
        <source>&amp;Interface</source>
        <translation type="obsolete">&amp;Interfejs</translation>
    </message>
    <message>
        <source>Recent files</source>
        <translation type="obsolete">Ostanio otwarte pliki</translation>
    </message>
    <message>
        <source>Never</source>
        <translation type="obsolete">Nigdy</translation>
    </message>
    <message>
        <source>Whenever it&apos;s needed</source>
        <translation type="obsolete">Jeżeli jest taka potrzeba</translation>
    </message>
    <message>
        <source>Only after loading a new video</source>
        <translation type="obsolete">Tylko po załadowaniu nowego filmu</translation>
    </message>
    <message>
        <source>Language</source>
        <translation type="obsolete">Język</translation>
    </message>
    <message>
        <source>Here you can change the language of the application.</source>
        <translation type="obsolete">Tutaj można zmienić język programu.</translation>
    </message>
    <message>
        <source>Instances</source>
        <translation type="obsolete">Przypadki</translation>
    </message>
    <message>
        <source>Ma&amp;x. items</source>
        <translation type="obsolete">Ma&amp;x. pozycji</translation>
    </message>
    <message>
        <source>St&amp;yle:</source>
        <translation type="obsolete">St&amp;yle:</translation>
    </message>
    <message>
        <source>L&amp;anguage:</source>
        <translation type="obsolete">J&amp;ęzyk:</translation>
    </message>
    <message>
        <source>Main window</source>
        <translation type="obsolete">Główne okno</translation>
    </message>
    <message>
        <source>Auto&amp;resize:</source>
        <translation type="obsolete">Automatyczna &amp;zmiana rozmiaru:</translation>
    </message>
    <message>
        <source>R&amp;emember position and size</source>
        <translation type="obsolete">Z&amp;apamietaj pozycję i rozmiar</translation>
    </message>
    <message>
        <source>Default font:</source>
        <translation type="obsolete">Domyślna czcionka:</translation>
    </message>
    <message>
        <source>&amp;Change...</source>
        <translation type="obsolete">&amp;Zmień...</translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="obsolete">TextLabel</translation>
    </message>
    <message>
        <source>Ins&amp;tances</source>
        <translation type="obsolete">&amp;Przypadki</translation>
    </message>
    <message>
        <source>Autoresize</source>
        <translation type="obsolete">Automatyczna zmiana rozmiaru</translation>
    </message>
    <message>
        <source>The main window can be resized automatically. Select the option you prefer.</source>
        <translation type="obsolete">Okno główne może być zmieniane automatycznie. Wybierz opcję, którą preferujesz.</translation>
    </message>
    <message>
        <source>Remember position and size</source>
        <translation type="obsolete">Zapamiętaj pozycję i rozmiar</translation>
    </message>
    <message>
        <source>Select the maximum number of items that will be shown in the &lt;b&gt;Open-&gt;Recent files&lt;/b&gt; submenu. If you set it to 0 that menu won&apos;t be shown at all.</source>
        <translation type="obsolete">Wybierz maksymalną ilość pozycji, które zostaną pokazane w podmenu &lt;b&gt;Otwórz-&gt;Ostatnio otwierane pliki&lt;/b&gt;. Jeśli ustawisz 0, menu nie pokaże nic.</translation>
    </message>
    <message>
        <source>Style</source>
        <translation type="obsolete">Styl</translation>
    </message>
    <message>
        <source>Select the style you prefer for the application.</source>
        <translation type="obsolete">Wybierz styl dla programu.</translation>
    </message>
    <message>
        <source>Default font</source>
        <translation type="obsolete">Domyślna czcionka</translation>
    </message>
    <message>
        <source>You can change here the application&apos;s font.</source>
        <translation type="obsolete">Tutaj możesz zmienić czcionkę programu.</translation>
    </message>
    <message>
        <source>Default GUI</source>
        <translation type="obsolete">Domyślne GUI</translation>
    </message>
    <message>
        <source>Automatic port</source>
        <translation type="obsolete">Port automatycznie</translation>
    </message>
    <message>
        <source>Manual port</source>
        <translation type="obsolete">Port ręcznie</translation>
    </message>
    <message>
        <source>Port to listen</source>
        <translation type="obsolete">Port nasłuchu</translation>
    </message>
    <message>
        <source>&amp;Automatic</source>
        <translation type="obsolete">&amp;Automatycznie</translation>
    </message>
    <message>
        <source>&amp;Manual</source>
        <translation type="obsolete">&amp;Ręcznie</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Subtitles</source>
        <translation type="obsolete">Napisy</translation>
    </message>
    <message>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="obsolete">Au&amp;tomatycznie ładuj napisy (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>Same name as movie</source>
        <translation type="obsolete">Taka sama nazwa jak film</translation>
    </message>
    <message>
        <source>All subs containing movie name</source>
        <translation type="obsolete">Wszystkie napisy zawierające nazwę filmu</translation>
    </message>
    <message>
        <source>All subs in directory</source>
        <translation type="obsolete">Wszystkie napisy w katalogu</translation>
    </message>
    <message>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="obsolete">&amp;Domyślne kodowanie napisów:</translation>
    </message>
    <message>
        <source>Audio</source>
        <translation type="obsolete">Audio</translation>
    </message>
    <message>
        <source>Volume &amp;normalization by default</source>
        <translation type="obsolete">Domyślna &amp;normalizacja głośności</translation>
    </message>
</context>
<context>
    <name>PrefPerformance</name>
    <message>
        <source>Performance</source>
        <translation type="obsolete">Wydajność</translation>
    </message>
    <message>
        <source>&amp;Performance</source>
        <translation type="obsolete">&amp;Wydajność</translation>
    </message>
    <message>
        <source>Priority</source>
        <translation type="obsolete">Priorytet</translation>
    </message>
    <message>
        <source>Select the priority for the MPlayer process.</source>
        <translation type="obsolete">Wybierz priorytet dla MPlayera.</translation>
    </message>
    <message>
        <source>realtime</source>
        <translation type="obsolete">realtime</translation>
    </message>
    <message>
        <source>high</source>
        <translation type="obsolete">wysoki</translation>
    </message>
    <message>
        <source>abovenormal</source>
        <translation type="obsolete">poniżej normalego</translation>
    </message>
    <message>
        <source>normal</source>
        <translation type="obsolete">normalny</translation>
    </message>
    <message>
        <source>belownormal</source>
        <translation type="obsolete">powyżej normalnego</translation>
    </message>
    <message>
        <source>idle</source>
        <translation type="obsolete">bezczynny</translation>
    </message>
    <message>
        <source>Cache</source>
        <translation type="obsolete">Bufor</translation>
    </message>
    <message>
        <source>KB</source>
        <translation type="obsolete">KB</translation>
    </message>
    <message>
        <source>Setting a cache may improve performance on slow media</source>
        <translation type="obsolete">Ustawienie bufora może polepszyć odtwarzanie na wolnych napędach</translation>
    </message>
    <message>
        <source>Allow frame drop</source>
        <translation type="obsolete">Pozwól na pomijanie klatek</translation>
    </message>
    <message>
        <source>Fast audio track switching</source>
        <translation type="obsolete">Szybkie przełączanie ścieżek audio</translation>
    </message>
    <message>
        <source>Fast seek to chapters in dvds</source>
        <translation type="obsolete">Szybkie szukanie rozdziałów w dvd</translation>
    </message>
    <message>
        <source>Skip displaying some frames to maintain A/V sync on slow systems.</source>
        <translation type="obsolete">Wybranie tej opcji powoduje pomijanie wyświetlania niektórych klatek aby utrzymać synchronizację A/V na słabszym sprzęcie.</translation>
    </message>
    <message>
        <source>Allow hard frame drop</source>
        <translation type="obsolete">Mocne pomijanie klatek</translation>
    </message>
    <message>
        <source>More intense frame dropping (breaks decoding). Leads to image distortion!</source>
        <translation type="obsolete">Wybranie tej opcji powoduje mocne pomijanie klatek (błędy w dekodowaniu obrazu). Może to powodować zniekształcenia obrazu!</translation>
    </message>
    <message>
        <source>Priorit&amp;y:</source>
        <translation type="obsolete">P&amp;riorytet:</translation>
    </message>
    <message>
        <source>&amp;Allow frame drop</source>
        <translation type="obsolete">&amp;Pozwól na pomijanie klatek</translation>
    </message>
    <message>
        <source>Allow &amp;hard frame drop (can lead to image distortion)</source>
        <translation type="obsolete">Mocne &amp;pomijanie klatek (może spowodować niestabilność wyświetlania)</translation>
    </message>
    <message>
        <source>&amp;Fast audio track switching</source>
        <translation type="obsolete">&amp;Szybkie przełączanie ścieżek audio</translation>
    </message>
    <message>
        <source>Fast &amp;seek to chapters in dvds</source>
        <translation type="obsolete">Szybkie &amp;szukanie rozdziałów w dvd</translation>
    </message>
    <message>
        <source>If checked, it will try the fastest method to seek to chapters but it might not work with some discs.</source>
        <translation type="obsolete">Jeśli jest zaznaczone to spróbuje użyć szybszej metody wyszukiwania rozdziałów, jednak może to nie działać z niektórymi dyskami.</translation>
    </message>
    <message>
        <source>Skip loop filter</source>
        <translation type="obsolete">Pomiń filtr loop</translation>
    </message>
    <message>
        <source>H.264</source>
        <translation type="obsolete">H.264</translation>
    </message>
    <message>
        <source>Cache for files</source>
        <translation type="obsolete">Bufor dla plików</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a file.</source>
        <translation type="obsolete">Ta opcja określa ile pamięci (w KB) należy użyć dla buforowania pliku.</translation>
    </message>
    <message>
        <source>Cache for streams</source>
        <translation type="obsolete">Bufor dla strumieni</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a URL.</source>
        <translation type="obsolete">Ta opcja określa ile pamięci (w KB) należy użyć dla buforowania URL.</translation>
    </message>
    <message>
        <source>Cache for DVDs</source>
        <translation type="obsolete">Bufor dla DVD</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a DVD.&lt;br&gt;&lt;b&gt;Warning:&lt;/b&gt; Seeking might not work properly (including chapter switching) when using a cache for DVDs.</source>
        <translation type="obsolete">Ta opcja określa ile pamięci (w KB) należy użyć dla buforowania DVD.&lt;br&gt;&lt;b&gt;Uwaga:&lt;/b&gt; Przewijanie może nie działać poprawnie (włączając przełączanie rozdziałów) podczas używania bufora dla DVD.</translation>
    </message>
    <message>
        <source>&amp;Cache</source>
        <translation type="obsolete">&amp;Bufor</translation>
    </message>
    <message>
        <source>Cache for &amp;DVDs:</source>
        <translation type="obsolete">Bufor dla &amp;DVD:</translation>
    </message>
    <message>
        <source>Cache for &amp;local files:</source>
        <translation type="obsolete">Bufor dla &amp;lokalnych plików:</translation>
    </message>
    <message>
        <source>Cache for &amp;streams:</source>
        <translation type="obsolete">Bufor dla &amp;strumieni:</translation>
    </message>
    <message>
        <source>Enabled</source>
        <translation type="obsolete">Włączone</translation>
    </message>
    <message>
        <source>Skip (always)</source>
        <translation type="obsolete">Pomiń (zawsze)</translation>
    </message>
    <message>
        <source>Skip only on HD videos</source>
        <translation type="obsolete">Pomiń tylko przy wideo DVD</translation>
    </message>
    <message>
        <source>Loop &amp;filter</source>
        <translation type="obsolete">Filtr &amp;loop</translation>
    </message>
    <message>
        <source>This option allows to skips the loop filter (AKA deblocking) during H.264 decoding. Since the filtered frame is supposed to be used as reference for decoding dependent frames this has a worse effect on quality than not doing deblocking on e.g. MPEG-2 video. But at least for high bitrate HDTV this provides a big speedup with no visible quality loss.</source>
        <translation type="obsolete">Ta opcja pozwala pominąć filtr loop (AKA debloking) przy dekodowaniu h264. Ponieważ odfiltrowanie klatek przypuszczalnie używa się do dekodowania zależnych klatek ma to gorszy efekt na jakość niż brak funkcji deblocking np. na wideo MPEG-2. Ale przynajmniej dla wysokiego bitrate HDTV zapewnia to duże przyspieszenie bez żadnej widocznej utratu jakości.</translation>
    </message>
    <message>
        <source>Possible values:</source>
        <translation type="obsolete">Dopuszczalne wartości:</translation>
    </message>
    <message>
        <source>&lt;b&gt;Enabled&lt;/b&gt;: the loop filter is not skipped</source>
        <translation type="obsolete">&lt;b&gt;Włączone&lt;/b&gt;: filtr loop nie jest pominięty</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip (always)&lt;/b&gt;: the loop filter is skipped no matter the resolution of the video</source>
        <translation type="obsolete">&lt;b&gt;Pomiń (zawsze)&lt;/b&gt;: filtr loop jest pominięty w kwestii rozdzielczości wideo</translation>
    </message>
    <message>
        <source>&lt;b&gt;Skip only on HD videos&lt;/b&gt;: the loop filter will be skipped only on videos which height is %1 or greater.</source>
        <translation type="obsolete">&lt;b&gt;Pomiń tylko przy wideo HD&lt;/b&gt;: filtr loop będzie pominięty tylko przy wideo, których wysokość jest większa niż %1.</translation>
    </message>
    <message>
        <source>Cache for audio CDs</source>
        <translation type="obsolete">Bufor dla audio CD</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching an audio CD.</source>
        <translation type="obsolete">Opcja ta precyzuje ile pamięci (w kb) należy użyć dla buforowania audio CD.</translation>
    </message>
    <message>
        <source>Cache for &amp;audio CDs:</source>
        <translation type="obsolete">Bufor dla &amp;audio CD:</translation>
    </message>
    <message>
        <source>Cache for VCDs</source>
        <translation type="obsolete">Bufor dla VCD</translation>
    </message>
    <message>
        <source>This option specifies how much memory (in kBytes) to use when precaching a VCD.</source>
        <translation type="obsolete">Opcja ta precyzuje ile pamięci (w kb) należy użyć dla buforowania VCD.</translation>
    </message>
    <message>
        <source>Cache for &amp;VCDs:</source>
        <translation type="obsolete">Bufor dla &amp;VCD:</translation>
    </message>
    <message>
        <source>Threads for decoding</source>
        <translation type="obsolete">Wątki dekodowania</translation>
    </message>
    <message>
        <source>Sets the number of threads to use for decoding. Only for MPEG-1/2 and H.264</source>
        <translation type="obsolete">Ustaw ilość wątków dekodowania. Tylko dla MPEG-1/2 i H.264</translation>
    </message>
    <message>
        <source>&amp;Threads for decoding (MPEG-1/2 and H.264 only):</source>
        <translation type="obsolete">&amp;Wątki dekodowania (tylko dla MPEG-1/2 i H.264):</translation>
    </message>
</context>
<context>
    <name>PrefSubtitles</name>
    <message>
        <location filename="../prefsubtitles.cpp" line="46"/>
        <source>Subtitles</source>
        <translation type="unfinished">Napisy</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="26"/>
        <location filename="../prefsubtitles.cpp" line="168"/>
        <source>Preferred audio and subtitles</source>
        <translation type="unfinished">Preferowana ścieżka dźwiękowa i napisy</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="170"/>
        <source>Preferred audio language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="180"/>
        <source>Preferred subtitle language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="171"/>
        <source>Here you can type your preferred language for the audio streams. When a media with multiple audio streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the audio streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the audio track if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="181"/>
        <source>Here you can type your preferred language for the subtitle stream. When a media with multiple subtitle streams is found, ROSA Media Player will try to use your preferred language.&lt;br&gt;This only will work with media that offer info about the language of the subtitle streams, like DVDs or mkv files.&lt;br&gt;This field accepts regular expressions. Example: &lt;b&gt;es|esp|spa&lt;/b&gt; will select the subtitle stream if it matches with &lt;i&gt;es&lt;/i&gt;, &lt;i&gt;esp&lt;/i&gt; or &lt;i&gt;spa&lt;/i&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="190"/>
        <source>Audio track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="191"/>
        <source>Specifies the default audio track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred audio language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="196"/>
        <source>Subtitle track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="197"/>
        <source>Specifies the default subtitle track which will be used when playing new files. If the track doesn&apos;t exist, the first one will be used. &lt;br&gt;&lt;b&gt;Note:&lt;/b&gt; the &lt;i&gt;&quot;preferred subtitle language&quot;&lt;/i&gt; has preference over this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose a ttf file</source>
        <translation type="obsolete">Wybierz TTF - plik</translation>
    </message>
    <message>
        <source>Truetype Fonts</source>
        <translation type="obsolete">Czcionki truetyp</translation>
    </message>
    <message>
        <source>&amp;Subtitles</source>
        <translation type="obsolete">&amp;Napisy</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="205"/>
        <location filename="../prefsubtitles.cpp" line="202"/>
        <location filename="../prefsubtitles.cpp" line="204"/>
        <source>Autoload</source>
        <translation type="unfinished">Autoładowanie</translation>
    </message>
    <message>
        <source>Select first available subtitle</source>
        <translation type="obsolete">Wybierz pierwsze dostępne napisy</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="72"/>
        <source>&amp;Audio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="91"/>
        <source>Su&amp;btitles:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="107"/>
        <source>Preferred language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="131"/>
        <source>Audi&amp;o:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="144"/>
        <source>&amp;Subtitle:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="193"/>
        <source>Or choose a track number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="218"/>
        <source>Same name as movie</source>
        <translation type="unfinished">Taka sama nazwa jak film</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="223"/>
        <source>All subs containing movie name</source>
        <translation type="unfinished">Wszystkie napisy zawierające nazwę filmu</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="228"/>
        <source>All subs in directory</source>
        <translation type="unfinished">Wszystkie napisy w katalogu</translation>
    </message>
    <message>
        <source>Position</source>
        <translation type="obsolete">Pozycja</translation>
    </message>
    <message>
        <source>0</source>
        <translation type="obsolete">0</translation>
    </message>
    <message>
        <source>Top</source>
        <translation type="obsolete">Góra</translation>
    </message>
    <message>
        <source>Bottom</source>
        <translation type="obsolete">Dół</translation>
    </message>
    <message>
        <source>Include subtitles on screenshots</source>
        <translation type="obsolete">Dołącz napisy w zrzucie ekranu</translation>
    </message>
    <message>
        <source>Font</source>
        <translation type="obsolete">Czcionka</translation>
    </message>
    <message>
        <source>Select the font which will be used for subtitles (and OSD):</source>
        <translation type="obsolete">Wybierz czcionkę dla napisów (oraz OSD):</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="obsolete">Rozmiar</translation>
    </message>
    <message>
        <source>No autoscale</source>
        <translation type="obsolete">Bez autoskalowania</translation>
    </message>
    <message>
        <source>Proportional to movie height</source>
        <translation type="obsolete">Proporcjonalnie do wysokości</translation>
    </message>
    <message>
        <source>Proportional to movie width</source>
        <translation type="obsolete">Proporcjonalnie do szerokości</translation>
    </message>
    <message>
        <source>Proportional to movie diagonal</source>
        <translation type="obsolete">Proporcjonalnie do przekątnej filmu</translation>
    </message>
    <message>
        <source>Subtitle position</source>
        <translation type="obsolete">Pozycja napisów</translation>
    </message>
    <message>
        <source>This option specifies the position of the subtitles over the video window. &lt;i&gt;100&lt;/i&gt; means the bottom, while &lt;i&gt;0&lt;/i&gt; means the top.</source>
        <translation type="obsolete">Ta opcja określa pozycję napisów w wyświetlanym filmie. &lt;i&gt;100&lt;/i&gt; napisy na dole filmu, a &lt;i&gt;0&lt;/i&gt; napisy na górze.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="252"/>
        <source>Au&amp;toload subtitles files (*.srt, *.sub...):</source>
        <translation type="unfinished">Au&amp;tomatycznie ładuj napisy (*.srt, *.sub...):</translation>
    </message>
    <message>
        <source>S&amp;elect first available subtitle</source>
        <translation type="obsolete">W&amp;ybierz piewsze dostępne napisy</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="294"/>
        <source>&amp;Default subtitle encoding:</source>
        <translation type="unfinished">&amp;Domyślne kodowanie napisów:</translation>
    </message>
    <message>
        <source>Default &amp;position of the subtitles on screen</source>
        <translation type="obsolete">Domyślna &amp;pozycja napisów na ekranie</translation>
    </message>
    <message>
        <source>&amp;Include subtitles on screenshots</source>
        <translation type="obsolete">&amp;Dołącz napisy w zrzucie ekranu</translation>
    </message>
    <message>
        <source>&amp;TTF font:</source>
        <translation type="obsolete">&amp;Czcionka TTF:</translation>
    </message>
    <message>
        <source>S&amp;ystem font:</source>
        <translation type="obsolete">Cz&amp;cionka systemowa:</translation>
    </message>
    <message>
        <source>A&amp;utoscale:</source>
        <translation type="obsolete">A&amp;utoskalowanie:</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="209"/>
        <source>Default subtitle encoding</source>
        <translation type="unfinished">Domyślne kodowanie napisów</translation>
    </message>
    <message>
        <source>TTF font</source>
        <translation type="obsolete">Czcionka TTF</translation>
    </message>
    <message>
        <source>System font</source>
        <translation type="obsolete">Czcionka systemowa</translation>
    </message>
    <message>
        <source>Here you can select a system font to be used for the subtitles and OSD. &lt;b&gt;Note:&lt;/b&gt; requires a MPlayer with fontconfig support.</source>
        <translation type="obsolete">Tutaj możesz wybrać czcionkę systemową dla napisów i OSD. &lt;b&gt;Notka:&lt;/b&gt; wymaga MPlayera z obsługą ustawień czcionki.</translation>
    </message>
    <message>
        <source>Autoscale</source>
        <translation type="obsolete">Autoskalowanie</translation>
    </message>
    <message>
        <source>Text color</source>
        <translation type="obsolete">Kolor tekstu</translation>
    </message>
    <message>
        <source>Select the color for the text of the subtitles.</source>
        <translation type="obsolete">Wybierz kolor tekstu napisów.</translation>
    </message>
    <message>
        <source>Border color</source>
        <translation type="obsolete">Kolor obwódki</translation>
    </message>
    <message>
        <source>Select the color for the border of the subtitles.</source>
        <translation type="obsolete">Wybierz kolor obwódki napisów.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="205"/>
        <source>Select the subtitle autoload method.</source>
        <translation type="unfinished">Wybierz napisy metodą autoładowania.</translation>
    </message>
    <message>
        <source>If there are one or more subtitle tracks available, one of them will be automatically selected, usually the first one, although if one of them matches the user&apos;s preferred language that one will be used instead.</source>
        <translation type="obsolete">Jeśli dostępne jest kilka ścieżek napisów, jedna z nich zostanie wybrana automatycznie, zwykle pierwsza. Jednak, gdy jedna z nich odpowiada preferowanemu językowi użytkownika, wtedy to ona zostanie użyta. </translation>
    </message>
    <message>
        <source>Select the subtitle autoscaling method.</source>
        <translation type="obsolete">Wybierz napisy metodą autoskalowania.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.cpp" line="210"/>
        <source>Select the encoding which will be used for subtitle files by default.</source>
        <translation type="unfinished">Wybierz kodowanie, które zostanie użyte jako domyślne dla plików napisów.</translation>
    </message>
    <message>
        <source>Try to autodetect for this language</source>
        <translation type="obsolete">Spróbuj autodetekcji dla tego języka</translation>
    </message>
    <message>
        <source>When this option is on, the encoding of the subtitles will be tried to be autodetected for the given language. It will fall back to the default encoding if the autodetection fails. This option requires a MPlayer compiled with ENCA support.</source>
        <translation type="obsolete">Jeśli opcja ta jest zaznaczona, kodowanie dla ustalonych napisów zostanie wykryte automatycznie. Gdy autodetekcja nie powiedzie się, kodowanie powróci do domyślnego. Opcja ta wymaga MPlayera kompilowanego z obsługą ENCA.</translation>
    </message>
    <message>
        <source>Subtitle language</source>
        <translation type="obsolete">Język napisów</translation>
    </message>
    <message>
        <source>Select the language for which you want the encoding to be guessed automatically.</source>
        <translation type="obsolete">Wybierz język, dla którego chcesz aby kodowanie zostało wykryte automatycznie.</translation>
    </message>
    <message>
        <location filename="../prefsubtitles.ui" line="265"/>
        <location filename="../prefsubtitles.cpp" line="207"/>
        <source>Encoding</source>
        <translation type="unfinished">Kodowanie</translation>
    </message>
    <message>
        <source>Try to a&amp;utodetect for this language:</source>
        <translation type="obsolete">Spróbuj &amp;autodetekcji dla tego języka:</translation>
    </message>
    <message>
        <source>Here you can select a ttf font to be used for the subtitles. Usually you&apos;ll find a lot of ttf fonts in %1</source>
        <translation type="obsolete">Tutaj możesz wybrać czcionkę ttf dla napisów. Dużą ilość czcionek ttf znajdziesz w &lt;i&gt;%1&lt;/i&gt;</translation>
    </message>
    <message>
        <source>Bottom</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">Dół</translation>
    </message>
    <message>
        <source>Top</source>
        <comment>vertical alignment</comment>
        <translation type="obsolete">Góra</translation>
    </message>
</context>
<context>
    <name>PrefTV</name>
    <message>
        <source>None</source>
        <translation type="obsolete">Nic</translation>
    </message>
    <message>
        <source>Lowpass5</source>
        <translation type="obsolete">Lowpass5</translation>
    </message>
    <message>
        <source>Yadif (normal)</source>
        <translation type="obsolete">Yadif (normalny)</translation>
    </message>
    <message>
        <source>Yadif (double framerate)</source>
        <translation type="obsolete">Yadif (podwójna szybkość klatek)</translation>
    </message>
    <message>
        <source>Linear Blend</source>
        <translation type="obsolete">Liniowy mieszany</translation>
    </message>
    <message>
        <source>Kerndeint</source>
        <translation type="obsolete">Kerndeint</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="97"/>
        <location filename="../preferencesdialog.cpp" line="172"/>
        <source>ROSA Media Player - Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="176"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="177"/>
        <source>Close</source>
        <translation type="unfinished">Zamknij</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="obsolete">Anuluj</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="178"/>
        <source>Apply</source>
        <translation>Zatwierdź</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="179"/>
        <source>Help</source>
        <translation>Pomoc</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.ui" line="14"/>
        <source>ROSA Media Player - Preferences</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../clhelp.cpp" line="170"/>
        <source>will show this message and then will exit.</source>
        <translation>pokaże się ta wiadomość a następnie zostanie zamknięty.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="149"/>
        <source>the main window will be closed when the file/playlist finishes.</source>
        <translation>okno główne zostanie zamknięte, gdy zakończy się plik/lista odtwarzania.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="134"/>
        <source>tries to make a connection to another running instance and send to it the specified action. Example: -send-action pause The rest of options (if any) will be ignored and the application will exit. It will return 0 on success or -1 on failure.</source>
        <translation>próby wykonania połączenia z inną uruchomioną kopią programu i wysłania do niej określonej operacji. Na przykład: -action pause. Reszta opcji (jeśli są) będą ignorowane i program zostanie zamknięty. Będzie zwracać 0 w przypadku powodzenia lub -1 przy niepowodzeniu.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="141"/>
        <source>action_list is a list of actions separated by spaces. The actions will be executed just after loading the file (if any) in the same order you entered. For checkable actions you can pass true or false as parameter. Example: -actions &quot;fullscreen compact true&quot;. Quotes are necessary in case you pass more than one action.</source>
        <translation>action_list to lista poleceń oddzielonych spacją. Polecenia będą po prostu wykonywane po załadowaniu pliku (jeśli jest), we wpisanej wcześniej kolejności. Dla skontrolowanych poleceń możesz pominąć prawdę lub fałsz jako parametr. Na przykład: -actions &quot;fullscreen compact true&quot;. Cudzysłowy są niezbędne w przypadku pominięcia więcej niż jednego polecenia.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="108"/>
        <location filename="../clhelp.cpp" line="179"/>
        <source>media</source>
        <translation>media</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="173"/>
        <source>if there&apos;s another instance running, the media will be added to that instance&apos;s playlist. If there&apos;s no other instance, this option will be ignored and the files will be opened in a new instance.</source>
        <translation>jeśli uruchomiona jest inna kopia programu, media zostaną dodane do jej listy odtwarzania. Jeśli nie ma innej kopii programu, opcja ta jest ignorowana i pliki zostaną otwarte w nowej kopii programu.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="152"/>
        <source>the main window won&apos;t be closed when the file/playlist finishes.</source>
        <translation>gdy zakończy się plik/lista odtwarzania okno główne nie zostanie zamknięte.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="155"/>
        <source>the video will be played in fullscreen mode.</source>
        <translation>wideo będzie odtwarzane w trybie pełnego ekranu.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="158"/>
        <source>the video will be played in window mode.</source>
        <translation>wideo będzie odtwarzane w trybie wyświetlania obrazu w oknie.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="179"/>
        <source>&apos;media&apos; is any kind of file that ROSA Media Player can open. It can be a local file, a DVD (e.g. dvd://1), an Internet stream (e.g. mms://....) or a local playlist in format m3u or pls. If the -playlist option is used, that means that ROSA Media Player will pass the -playlist option to MPlayer, so MPlayer will handle the playlist, not ROSA Media Player.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="124"/>
        <source>Restores the old associations and cleans up the registry.</source>
        <translation>Przywróć poprzednie skojarzenia i wyczyść rejestr.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="114"/>
        <location filename="../clhelp.cpp" line="119"/>
        <source>Usage:</source>
        <translation>Użycie:</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="103"/>
        <source>directory</source>
        <translation>katalog</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="104"/>
        <source>action_name</source>
        <translation>nazwa_działania</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="105"/>
        <source>action_list</source>
        <translation>lista_działań</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="127"/>
        <source>opens the default gui.</source>
        <translation>otwórz domyślne gui.</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="106"/>
        <source>subtitle_file</source>
        <translation>plik_napisów</translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="161"/>
        <source>specifies the subtitle file to be loaded for the first video.</source>
        <translation>określ plik napisów, które zostaną wczytane dla pierwszego plku wideo.</translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="88"/>
        <location filename="../helper.cpp" line="97"/>
        <source>%1 second(s)</source>
        <translation>
            <numerusform>%1 sekund (a,y)</numerusform>
            <numerusform>%1 sekund (a,y)</numerusform>
            <numerusform>%1 sekund (a,y)</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../helper.cpp" line="93"/>
        <location filename="../helper.cpp" line="96"/>
        <source>%1 minute(s)</source>
        <translation>
            <numerusform>%1 minut (a,y)</numerusform>
            <numerusform>%1 minut (a,y)</numerusform>
            <numerusform>%1 minut (a,y)</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../helper.cpp" line="98"/>
        <source>%1 and %2</source>
        <translation>%1 i %2</translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="187"/>
        <source>disabled</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="217"/>
        <source>auto</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediasettings.cpp" line="220"/>
        <source>unknown</source>
        <comment>aspect_ratio</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="107"/>
        <source>height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="130"/>
        <source>specifies the directory where rosa-media-player will store its configuration files (rosamp.ini, rosamp_files.ini...)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="164"/>
        <source>specifies the coordinates where the main window will be displayed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clhelp.cpp" line="167"/>
        <source>specifies the size of the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../smplayer.cpp" line="444"/>
        <source>This is ROSA Media Player running on %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../winfileassoc.cpp" line="304"/>
        <source>Enqueue in ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QuaZipFile</name>
    <message>
        <location filename="../findsubtitles/quazip/quazipfile.cpp" line="141"/>
        <source>ZIP/UNZIP API error %1</source>
        <translation>ZIP/UNZIP API błąd %1</translation>
    </message>
</context>
<context>
    <name>Recorder</name>
    <message>
        <location filename="../recorder.cpp" line="94"/>
        <source>Failed to start recording. Please check that ffmpeg is installed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="97"/>
        <source>Unknown error in recording occured</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../recorder.cpp" line="100"/>
        <source>Sorry, recording crashed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScreenCapture</name>
    <message>
        <location filename="../screencapture.cpp" line="49"/>
        <source>/Screencast - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Information</source>
        <translation type="unfinished">Informacja</translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="68"/>
        <source>Screen capture was successfully saved to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screencapture.cpp" line="86"/>
        <source>Length: %1
Size: %2
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SeekWidget</name>
    <message>
        <location filename="../seekwidget.ui" line="22"/>
        <source>icon</source>
        <translation>ikona</translation>
    </message>
    <message>
        <location filename="../seekwidget.ui" line="40"/>
        <source>label</source>
        <translation>etykieta</translation>
    </message>
</context>
<context>
    <name>ShortcutGetter</name>
    <message>
        <location filename="../shortcutgetter.cpp" line="268"/>
        <source>Modify shortcut</source>
        <translation>Modyfikuj klawisz skrótu</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="291"/>
        <source>Clear</source>
        <translation>Wyczyść</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="276"/>
        <source>Press the key combination you want to assign</source>
        <translation>Naciśnij kombinację klawiszy, które chcesz wyznaczyć</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="293"/>
        <source>Capture</source>
        <translation>Przechwycenie</translation>
    </message>
    <message>
        <location filename="../shortcutgetter.cpp" line="294"/>
        <source>Capture keystrokes</source>
        <translation>Przechwycenie naciśnięć klawiszy</translation>
    </message>
</context>
<context>
    <name>SplitVideo</name>
    <message>
        <location filename="../splitvideo.cpp" line="103"/>
        <source>Start time must be before than the end time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="270"/>
        <source>/Movie_</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="300"/>
        <source>Cannot trim video ( maybe you have no enough disk space? )</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="407"/>
        <source>Cannot trim video (code: %1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="420"/>
        <source>Information</source>
        <translation type="unfinished">Informacja</translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="421"/>
        <source>New file &quot;%1&quot; saved in the folder %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.cpp" line="422"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
</context>
<context>
    <name>SplitVideoPanel</name>
    <message>
        <location filename="../splitvideo.ui" line="20"/>
        <source>Split Video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="42"/>
        <source>Specify the time interval:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="51"/>
        <source>From:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="58"/>
        <location filename="../splitvideo.ui" line="95"/>
        <source>HH:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="65"/>
        <location filename="../splitvideo.ui" line="102"/>
        <source>Set a current playback time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="68"/>
        <location filename="../splitvideo.ui" line="105"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="88"/>
        <source>To:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="221"/>
        <source>Cancel</source>
        <translation type="unfinished">Anuluj</translation>
    </message>
    <message>
        <location filename="../splitvideo.ui" line="228"/>
        <source>Trim</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SubChooserDialog</name>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="13"/>
        <source>Subtitle selection</source>
        <translation>Wybór napisów</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="19"/>
        <source>This archive contains more than one subtitle file. Please choose the ones you want to extract.</source>
        <translation>To archiwum zawiera wimecej niż jeden plik napisów. Proszę wybrać jeden, który chcesz wypakować.</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="68"/>
        <source>Select All</source>
        <translation>Wybierz wszystko</translation>
    </message>
    <message>
        <location filename="../findsubtitles/subchooserdialog.ui" line="75"/>
        <source>Select None</source>
        <translation>Nie wybieraj nic</translation>
    </message>
</context>
<context>
    <name>TVList</name>
    <message>
        <location filename="../tvlist.cpp" line="97"/>
        <source>Channel editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tvlist.cpp" line="98"/>
        <source>TV/Radio list</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TimeDialog</name>
    <message>
        <location filename="../timedialog.ui" line="54"/>
        <source>&amp;Jump to:</source>
        <translation>&amp;Skocz do:</translation>
    </message>
</context>
<context>
    <name>TristateCombo</name>
    <message>
        <location filename="../tristatecombo.cpp" line="36"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="37"/>
        <source>Yes</source>
        <translation>Tak</translation>
    </message>
    <message>
        <location filename="../tristatecombo.cpp" line="38"/>
        <source>No</source>
        <translation>Nie</translation>
    </message>
</context>
<context>
    <name>VideoEqualizer</name>
    <message>
        <location filename="../videoequalizer.cpp" line="74"/>
        <location filename="../videoequalizer.cpp" line="75"/>
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="78"/>
        <location filename="../videoequalizer.cpp" line="79"/>
        <source>Brightness</source>
        <translation>Jasność</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="82"/>
        <location filename="../videoequalizer.cpp" line="83"/>
        <source>Hue</source>
        <translation>Odcień</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="86"/>
        <location filename="../videoequalizer.cpp" line="87"/>
        <source>Saturation</source>
        <translation>Nasycenie</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="90"/>
        <location filename="../videoequalizer.cpp" line="91"/>
        <source>Gamma</source>
        <translation>Gamma</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="94"/>
        <source>&amp;Reset</source>
        <translation>&amp;Wyzeruj</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="95"/>
        <source>&amp;Set as default values</source>
        <translation>&amp;Ustaw wartości jako domyślne</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="99"/>
        <source>Use the current values as default values for new videos.</source>
        <translation>Użyj aktualnych wartości jako domyślnych dla nowych plików wideo.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="101"/>
        <source>Set all controls to zero.</source>
        <translation>Ustaw wszystkie suwaki na zero.</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="71"/>
        <source>Video Equalizer</source>
        <translation>Korektor wideo</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="122"/>
        <source>Information</source>
        <translation>Informacja</translation>
    </message>
    <message>
        <location filename="../videoequalizer.cpp" line="123"/>
        <source>The current values have been stored to be used as default.</source>
        <translation>Aktualne wartości zostaną przechowane aby mogły być użyte jako domyślne.</translation>
    </message>
</context>
<context>
    <name>VideoPreview</name>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="137"/>
        <location filename="../videopreview/videopreview.cpp" line="398"/>
        <source>Video preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="138"/>
        <source>Cancel</source>
        <translation type="unfinished">Anuluj</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="140"/>
        <source>Generated by ROSA Media Player</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="229"/>
        <source>Creating thumbnails...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="382"/>
        <source>Size: %1 MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="384"/>
        <source>Length: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="526"/>
        <source>Save file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="534"/>
        <source>Error saving file</source>
        <translation type="unfinished">Błąd zapisu pliku</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="535"/>
        <source>The file couldn&apos;t be saved</source>
        <translation type="unfinished">Plik nie może zostać zapisany</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="185"/>
        <source>Error</source>
        <translation type="unfinished">Błąd</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="186"/>
        <source>The following error has occurred while creating the thumbnails:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="212"/>
        <source>The temporary directory (%1) can&apos;t be created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="307"/>
        <source>The mplayer process didn&apos;t run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="383"/>
        <source>Resolution: %1x%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="387"/>
        <source>Video format: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="388"/>
        <source>Frames per second: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="389"/>
        <source>Aspect ratio: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="325"/>
        <source>The file %1 can&apos;t be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="424"/>
        <source>No filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="484"/>
        <source>The mplayer process didn&apos;t start while trying to get info about the video</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="203"/>
        <source>The length of the video is 0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="247"/>
        <source>The file %1 doesn&apos;t exist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="527"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="371"/>
        <source>No info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="374"/>
        <location filename="../videopreview/videopreview.cpp" line="375"/>
        <source>%1 kbps</source>
        <translation type="unfinished">%1 kbps</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="376"/>
        <source>%1 Hz</source>
        <translation type="unfinished">%1 Hz</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="392"/>
        <source>Video bitrate: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="393"/>
        <source>Audio bitrate: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreview.cpp" line="394"/>
        <source>Audio rate: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VideoPreviewConfigDialog</name>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="34"/>
        <source>Default</source>
        <translation type="unfinished">Domyślne</translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="13"/>
        <source>Video Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="21"/>
        <source>&amp;File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="55"/>
        <source>&amp;Columns:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="91"/>
        <source>&amp;Rows:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="135"/>
        <source>&amp;Aspect ratio:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="165"/>
        <source>&amp;Seconds to skip at the beginnning:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="199"/>
        <source>&amp;Maximum width:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="44"/>
        <source>The preview will be created for the video you specify here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>The thumbnails will be arranged on a table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="46"/>
        <source>This option specifies the number of columns of the table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="47"/>
        <source>This option specifies the number of rows of the table.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="48"/>
        <source>If you check this option, the playing time will be displayed at the bottom of each thumbnail.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="49"/>
        <source>If the aspect ratio of the video is wrong, you can specify a different one here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="50"/>
        <source>Usually the first frames are black, so it&apos;s a good idea to skip some seconds at the beginning of the video. This option allows to specify how many seconds will be skipped.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="52"/>
        <source>This option specifies the maximum width in pixels that the generated preview image will have.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="53"/>
        <source>Some frames will be extracted from the video in order to create the preview. Here you can choose the image format for the extracted frames. PNG may give better quality.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="113"/>
        <source>Add playing &amp;time to thumbnails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="249"/>
        <source>&amp;Extract frames as</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.cpp" line="45"/>
        <source>Enter here the DVD device or a folder with a DVD image.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="38"/>
        <source>&amp;DVD device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videopreview/videopreviewconfigdialog.ui" line="290"/>
        <source>Remember folder used to &amp;save the preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VolumeSliderAction</name>
    <message>
        <location filename="../widgetactions.cpp" line="208"/>
        <source>Volume</source>
        <translation>Głośność</translation>
    </message>
</context>
</TS>
